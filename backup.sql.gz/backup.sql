--
-- PostgreSQL database dump
--

\restrict 1fzgmxtUx6qh4wImpdpYr98kboS1NPfEv3hAhZO0qOAOWCL3H53GTIaMgY5h7yW

-- Dumped from database version 18.1 (Debian 18.1-1.pgdg13+2)
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: enum_estoque_insumo_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_estoque_insumo_status AS ENUM (
    'active',
    'suspended'
);


ALTER TYPE public.enum_estoque_insumo_status OWNER TO postgres;

--
-- Name: enum_estoque_medicamento_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_estoque_medicamento_status AS ENUM (
    'active',
    'suspended'
);


ALTER TYPE public.enum_estoque_medicamento_status OWNER TO postgres;

--
-- Name: enum_notificacao_destino; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_notificacao_destino AS ENUM (
    'sus',
    'familia',
    'farmacia'
);


ALTER TYPE public.enum_notificacao_destino OWNER TO postgres;

--
-- Name: enum_notificacao_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_notificacao_status AS ENUM (
    'pending',
    'sent',
    'cancelled'
);


ALTER TYPE public.enum_notificacao_status OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."SequelizeMeta" OWNER TO postgres;

--
-- Name: armario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.armario (
    num_armario integer NOT NULL,
    categoria_id integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.armario OWNER TO postgres;

--
-- Name: categoria_armario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categoria_armario (
    id integer NOT NULL,
    nome character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.categoria_armario OWNER TO postgres;

--
-- Name: categoria_armario_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categoria_armario_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categoria_armario_id_seq OWNER TO postgres;

--
-- Name: categoria_armario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categoria_armario_id_seq OWNED BY public.categoria_armario.id;


--
-- Name: categoria_gaveta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categoria_gaveta (
    id integer NOT NULL,
    nome character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.categoria_gaveta OWNER TO postgres;

--
-- Name: categoria_gaveta_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categoria_gaveta_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categoria_gaveta_id_seq OWNER TO postgres;

--
-- Name: categoria_gaveta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categoria_gaveta_id_seq OWNED BY public.categoria_gaveta.id;


--
-- Name: estoque_insumo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estoque_insumo (
    id integer NOT NULL,
    insumo_id integer NOT NULL,
    casela_id integer,
    armario_id integer,
    gaveta_id integer,
    quantidade integer NOT NULL,
    validade timestamp with time zone NOT NULL,
    tipo text NOT NULL,
    setor text NOT NULL,
    lote character varying(255),
    status public.enum_estoque_insumo_status DEFAULT 'active'::public.enum_estoque_insumo_status NOT NULL,
    suspended_at timestamp with time zone,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    destino character varying(75),
    observacao character varying(75)
);


ALTER TABLE public.estoque_insumo OWNER TO postgres;

--
-- Name: estoque_insumo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estoque_insumo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.estoque_insumo_id_seq OWNER TO postgres;

--
-- Name: estoque_insumo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estoque_insumo_id_seq OWNED BY public.estoque_insumo.id;


--
-- Name: estoque_medicamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estoque_medicamento (
    id integer NOT NULL,
    medicamento_id integer NOT NULL,
    casela_id integer,
    armario_id integer,
    gaveta_id integer,
    validade date NOT NULL,
    quantidade integer NOT NULL,
    origem character varying(255) NOT NULL,
    tipo character varying(255) NOT NULL,
    status public.enum_estoque_medicamento_status DEFAULT 'active'::public.enum_estoque_medicamento_status NOT NULL,
    lote character varying(255),
    setor text NOT NULL,
    suspended_at timestamp with time zone,
    observacao text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.estoque_medicamento OWNER TO postgres;

--
-- Name: estoque_medicamento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estoque_medicamento_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.estoque_medicamento_id_seq OWNER TO postgres;

--
-- Name: estoque_medicamento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estoque_medicamento_id_seq OWNED BY public.estoque_medicamento.id;


--
-- Name: gaveta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gaveta (
    num_gaveta integer NOT NULL,
    categoria_id integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.gaveta OWNER TO postgres;

--
-- Name: insumo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.insumo (
    id integer NOT NULL,
    nome character varying(255) NOT NULL,
    descricao character varying(255),
    estoque_minimo integer,
    preco numeric(10,2),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.insumo OWNER TO postgres;

--
-- Name: insumo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.insumo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.insumo_id_seq OWNER TO postgres;

--
-- Name: insumo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.insumo_id_seq OWNED BY public.insumo.id;


--
-- Name: login; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login (
    id integer NOT NULL,
    login character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    refresh_token character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    first_name character varying(45),
    last_name character varying(45)
);


ALTER TABLE public.login OWNER TO postgres;

--
-- Name: login_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.login_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.login_id_seq OWNER TO postgres;

--
-- Name: login_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.login_id_seq OWNED BY public.login.id;


--
-- Name: medicamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medicamento (
    id integer NOT NULL,
    nome character varying(255) NOT NULL,
    dosagem character varying(255) NOT NULL,
    unidade_medida character varying(255) NOT NULL,
    principio_ativo character varying(255) NOT NULL,
    estoque_minimo integer,
    preco numeric(10,2),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.medicamento OWNER TO postgres;

--
-- Name: medicamento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.medicamento_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.medicamento_id_seq OWNER TO postgres;

--
-- Name: medicamento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.medicamento_id_seq OWNED BY public.medicamento.id;


--
-- Name: movimentacao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.movimentacao (
    id integer NOT NULL,
    tipo character varying(255) NOT NULL,
    data timestamp with time zone NOT NULL,
    login_id integer NOT NULL,
    insumo_id integer,
    medicamento_id integer,
    armario_id integer,
    gaveta_id integer,
    quantidade integer NOT NULL,
    casela_id integer,
    setor character varying(255) NOT NULL,
    lote character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    destino character varying(75)
);


ALTER TABLE public.movimentacao OWNER TO postgres;

--
-- Name: movimentacao_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.movimentacao_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.movimentacao_id_seq OWNER TO postgres;

--
-- Name: movimentacao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.movimentacao_id_seq OWNED BY public.movimentacao.id;


--
-- Name: notificacao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notificacao (
    id integer NOT NULL,
    medicamento_id integer NOT NULL,
    residente_id integer NOT NULL,
    destino public.enum_notificacao_destino NOT NULL,
    data_prevista date NOT NULL,
    criado_por integer NOT NULL,
    status public.enum_notificacao_status DEFAULT 'pending'::public.enum_notificacao_status NOT NULL,
    visto boolean DEFAULT false NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.notificacao OWNER TO postgres;

--
-- Name: notificacao_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notificacao_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notificacao_id_seq OWNER TO postgres;

--
-- Name: notificacao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notificacao_id_seq OWNED BY public.notificacao.id;


--
-- Name: residente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.residente (
    num_casela integer NOT NULL,
    nome character varying(255) NOT NULL
);


ALTER TABLE public.residente OWNER TO postgres;

--
-- Name: categoria_armario id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria_armario ALTER COLUMN id SET DEFAULT nextval('public.categoria_armario_id_seq'::regclass);


--
-- Name: categoria_gaveta id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria_gaveta ALTER COLUMN id SET DEFAULT nextval('public.categoria_gaveta_id_seq'::regclass);


--
-- Name: estoque_insumo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque_insumo ALTER COLUMN id SET DEFAULT nextval('public.estoque_insumo_id_seq'::regclass);


--
-- Name: estoque_medicamento id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque_medicamento ALTER COLUMN id SET DEFAULT nextval('public.estoque_medicamento_id_seq'::regclass);


--
-- Name: insumo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.insumo ALTER COLUMN id SET DEFAULT nextval('public.insumo_id_seq'::regclass);


--
-- Name: login id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login ALTER COLUMN id SET DEFAULT nextval('public.login_id_seq'::regclass);


--
-- Name: medicamento id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicamento ALTER COLUMN id SET DEFAULT nextval('public.medicamento_id_seq'::regclass);


--
-- Name: movimentacao id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movimentacao ALTER COLUMN id SET DEFAULT nextval('public.movimentacao_id_seq'::regclass);


--
-- Name: notificacao id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notificacao ALTER COLUMN id SET DEFAULT nextval('public.notificacao_id_seq'::regclass);


--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SequelizeMeta" (name) FROM stdin;
20260118010727-user-name-field.js
20260121023545-destination-fields.js
\.


--
-- Data for Name: armario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.armario (num_armario, categoria_id, "createdAt", "updatedAt") FROM stdin;
6	6	2025-12-24 15:15:18.463+00	2025-12-24 15:15:18.463+00
1	1	2025-12-24 17:21:07.938+00	2025-12-24 17:21:07.938+00
2	3	2025-12-24 17:21:23.295+00	2025-12-24 17:21:23.295+00
3	2	2025-12-24 17:21:37.196+00	2025-12-24 17:21:37.196+00
4	4	2025-12-24 17:22:03.291+00	2025-12-24 17:22:03.291+00
5	5	2025-12-24 17:22:18.982+00	2025-12-24 17:22:18.982+00
7	7	2025-12-24 17:22:41.218+00	2025-12-24 17:22:41.218+00
8	8	2026-01-26 18:25:18.853+00	2026-01-26 18:25:18.853+00
9	9	2026-01-26 18:25:46.184+00	2026-01-26 18:25:46.184+00
\.


--
-- Data for Name: categoria_armario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categoria_armario (id, nome, "createdAt", "updatedAt") FROM stdin;
1	Medicação geral	2025-12-15 12:44:25.479+00	2025-12-15 12:44:25.479+00
2	Psicotrópicos e injeções	2025-12-15 12:44:25.479+00	2025-12-15 12:44:25.479+00
3	Medicamentos doados / Fitas / Dersane / Clorexidina	2025-12-15 12:44:25.479+00	2025-12-15 12:44:25.479+00
4	Lactulose / Hipratrópio / Pomadas / Domperidona / Materiais de glicemia	2025-12-15 12:44:25.479+00	2025-12-15 12:44:25.479+00
5	Insumos Geral	2025-12-15 14:33:13.588+00	2025-12-15 14:33:13.588+00
6	Medicamentos reserva	2025-12-15 21:07:27.37+00	2025-12-15 21:07:27.37+00
7	Caixa Antibióticos	2025-12-15 21:09:54.612+00	2025-12-15 21:09:54.612+00
8	Caixa de vitaminas	2026-01-26 18:25:18.835+00	2026-01-26 18:25:18.835+00
9	Psicotrópicos reservas	2026-01-26 18:25:46.167+00	2026-01-26 18:25:46.167+00
\.


--
-- Data for Name: categoria_gaveta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categoria_gaveta (id, nome, "createdAt", "updatedAt") FROM stdin;
3	Medicamentos	2026-01-15 20:29:22.327894+00	2026-01-15 20:29:22.327894+00
4	Punção e Exame Físico	2026-01-15 20:29:22.327894+00	2026-01-15 20:29:22.327894+00
5	Soluções Cristalóides	2026-01-15 20:29:22.327894+00	2026-01-15 20:29:22.327894+00
6	Oxigênio, Terapia e Bolsa Coletora	2026-01-15 20:29:22.327894+00	2026-01-15 20:29:22.327894+00
7	Sondagem	2026-01-15 20:29:22.327894+00	2026-01-15 20:29:22.327894+00
8	Ambu	2026-01-15 20:29:22.327894+00	2026-01-15 20:29:22.327894+00
\.


--
-- Data for Name: estoque_insumo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estoque_insumo (id, insumo_id, casela_id, armario_id, gaveta_id, quantidade, validade, tipo, setor, lote, status, suspended_at, "createdAt", "updatedAt", destino, observacao) FROM stdin;
11	12	\N	5	\N	2	2029-12-31 03:00:00+00	geral	farmacia	\N	active	\N	2026-01-15 16:50:23.260457+00	2026-01-15 16:50:23.260457+00	\N	\N
13	13	\N	5	\N	0	2026-08-27 03:00:00+00	geral	farmacia	\N	active	\N	2026-01-15 16:50:23.260457+00	2026-01-15 16:50:23.260457+00	\N	\N
14	14	\N	5	\N	400	2029-09-26 03:00:00+00	geral	farmacia	\N	active	\N	2026-01-15 16:50:23.260457+00	2026-01-15 16:50:23.260457+00	\N	\N
16	14	\N	5	\N	200	2030-01-15 03:00:00+00	geral	farmacia	\N	active	\N	2026-01-15 16:50:23.260457+00	2026-01-15 16:50:23.260457+00	\N	\N
17	16	\N	5	\N	12	2030-07-30 03:00:00+00	geral	farmacia	\N	active	\N	2026-01-15 16:50:23.260457+00	2026-01-15 16:50:23.260457+00	\N	\N
18	17	\N	5	\N	6	2027-05-30 03:00:00+00	geral	farmacia	\N	active	\N	2026-01-15 16:50:23.260457+00	2026-01-15 16:50:23.260457+00	\N	\N
19	14	35	5	\N	100	2030-01-15 03:00:00+00	individual	farmacia	532401	active	\N	2026-01-16 18:40:09.039+00	2026-01-16 18:40:09.039+00	\N	\N
20	13	35	1	\N	100	2026-11-23 03:00:00+00	individual	farmacia	29527132	active	\N	2026-01-16 18:41:38.448+00	2026-01-16 18:41:38.448+00	\N	\N
21	16	\N	6	\N	6	2030-07-30 03:00:00+00	geral	farmacia	862822	active	\N	2026-01-17 15:52:57.695+00	2026-01-17 15:52:57.695+00	\N	\N
23	18	2	5	\N	12	2030-07-30 03:00:00+00	individual	enfermagem	2508010025	active	\N	2026-01-19 20:25:45.96+00	2026-01-19 20:25:45.96+00	\N	\N
24	11	38	5	\N	2	2027-05-31 00:00:00+00	individual	enfermagem	884625	active	\N	2026-01-21 19:56:16.813+00	2026-01-21 19:56:16.813+00	\N	\N
15	13	\N	4	\N	50	2026-11-23 03:00:00+00	geral	farmacia	\N	active	\N	2026-01-15 16:50:23.260457+00	2026-01-21 21:10:57.455+00	\N	\N
31	21	\N	5	\N	1	2026-11-30 03:00:00+00	geral	enfermagem	0538	active	\N	2026-01-23 14:44:29.506+00	2026-01-23 14:44:29.506+00	Enfermagem	\N
32	21	\N	5	\N	1	2027-03-30 03:00:00+00	geral	enfermagem	1097	active	\N	2026-01-23 14:44:42.161+00	2026-01-23 14:44:42.161+00	Enfermagem	\N
29	21	\N	5	\N	30	2027-03-30 03:00:00+00	geral	farmacia	1097	active	\N	2026-01-23 14:43:28.391+00	2026-01-23 14:44:42.169+00	\N	\N
33	14	\N	5	\N	25	2028-10-31 03:00:00+00	geral	farmacia	10824181	active	\N	2026-01-26 19:59:51.312+00	2026-01-26 19:59:51.312+00	\N	\N
34	18	\N	5	\N	4	2030-07-30 03:00:00+00	geral	enfermagem	2508010025	active	\N	2026-01-26 21:29:42.933+00	2026-01-26 21:29:42.933+00	Enfermagem	\N
35	22	\N	6	\N	7	2030-10-24 03:00:00+00	geral	farmacia	D43-1	active	\N	2026-01-27 17:34:10.301+00	2026-01-27 17:34:10.301+00	\N	\N
37	24	\N	6	\N	4	2027-09-30 03:00:00+00	geral	farmacia	2532245	active	\N	2026-01-27 17:53:43.011+00	2026-01-27 17:53:43.011+00	\N	\N
38	23	11	6	\N	2	2028-12-27 03:00:00+00	individual	enfermagem		active	\N	2026-01-27 17:56:08.578+00	2026-01-27 17:56:08.578+00	\N	para uso do morador Miguel
39	25	\N	5	\N	2	2028-03-29 03:00:00+00	geral	farmacia	20230030	active	\N	2026-01-27 18:13:40.775+00	2026-01-27 18:13:40.775+00	\N	\N
40	26	\N	5	\N	1	2028-09-30 03:00:00+00	geral	farmacia	25385422B1	active	\N	2026-01-27 18:16:46.937+00	2026-01-27 18:16:46.937+00	\N	\N
42	27	\N	5	\N	1	2028-08-14 03:00:00+00	geral	enfermagem	72043	active	\N	2026-01-27 18:21:52.693+00	2026-01-27 18:21:52.693+00	enfermagem	Uso geral
41	27	\N	5	\N	2	2028-08-14 03:00:00+00	geral	farmacia	72043	active	\N	2026-01-27 18:20:13.502+00	2026-01-27 18:21:52.698+00	\N	\N
43	28	\N	6	\N	32	2028-04-30 03:00:00+00	geral	farmacia	23020475	active	\N	2026-01-27 18:38:04.742+00	2026-01-27 18:38:04.742+00	\N	\N
45	29	\N	5	\N	4	2028-04-30 03:00:00+00	geral	enfermagem	15E23	active	\N	2026-01-27 19:57:00.294+00	2026-01-27 19:57:00.294+00	enfermagem	Uso na Carola
44	29	\N	5	\N	11	2028-04-30 03:00:00+00	geral	farmacia	15E23	active	\N	2026-01-27 19:55:26.707+00	2026-01-27 19:57:00.306+00	\N	\N
25	13	\N	4	\N	0	2026-11-23 03:00:00+00	geral	farmacia	\N	active	\N	2026-01-21 21:10:57.442+00	2026-01-27 20:15:24.024+00	\N	\N
47	15	21	6	\N	120	2026-02-27 03:00:00+00	individual	enfermagem		active	\N	2026-01-28 14:48:04.031+00	2026-01-28 14:48:04.031+00	\N	entregue na enfermagem dia 27/01/26
46	15	21	6	\N	0	2026-02-27 03:00:00+00	individual	farmacia		active	\N	2026-01-28 14:47:17.511+00	2026-01-28 14:48:04.041+00	\N	\N
48	30	\N	5	\N	2	2027-07-30 03:00:00+00	geral	farmacia	2503457	active	\N	2026-01-28 19:07:27.162+00	2026-01-28 19:07:27.162+00	\N	\N
49	31	\N	2	\N	1	2027-11-11 03:00:00+00	geral	farmacia	107414	active	\N	2026-01-28 19:09:32.603+00	2026-01-28 19:09:32.603+00	\N	\N
50	20	\N	5	\N	200	2028-09-11 03:00:00+00	geral	enfermagem	AUX3780	active	\N	2026-01-28 22:12:31.663+00	2026-01-28 22:12:31.663+00	enfermagem	\N
27	20	\N	5	\N	2100	2028-09-11 03:00:00+00	geral	farmacia	AUX3780	active	\N	2026-01-23 14:24:19.609+00	2026-01-28 22:12:31.67+00	\N	\N
51	18	\N	5	\N	4	2030-07-30 03:00:00+00	geral	enfermagem	2508010025	active	\N	2026-01-28 22:19:08.11+00	2026-01-28 22:19:08.11+00	enfermagem	uso geral
26	18	\N	5	\N	4	2030-07-30 03:00:00+00	geral	farmacia	2508010025	active	\N	2026-01-21 21:11:35.189+00	2026-01-28 22:19:08.119+00	\N	\N
\.


--
-- Data for Name: estoque_medicamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estoque_medicamento (id, medicamento_id, casela_id, armario_id, gaveta_id, validade, quantidade, origem, tipo, status, lote, setor, suspended_at, observacao, "createdAt", "updatedAt") FROM stdin;
19	16	\N	6	\N	2027-09-30	45	Compra/Doação	geral	active	\N	farmacia	\N	\N	2025-12-24 15:18:07.043+00	2025-12-24 15:18:07.043+00
21	17	\N	6	\N	2027-01-31	60	Compra/Doação	geral	active	\N	farmacia	\N	\N	2025-12-24 17:06:06.283+00	2025-12-24 17:06:06.283+00
20	16	\N	6	\N	2027-02-28	45	Compra/Doação	geral	active	\N	farmacia	\N	\N	2025-12-24 15:19:02.037+00	2025-12-24 17:06:54.106+00
22	16	\N	6	\N	2027-04-30	30	Compra/Doação	geral	active	\N	farmacia	\N	\N	2025-12-24 17:08:20.702+00	2025-12-24 17:08:20.702+00
23	16	\N	6	\N	2026-05-30	30	Compra/Doação	geral	active	\N	farmacia	\N	\N	2025-12-24 17:08:59.664+00	2025-12-24 17:08:59.664+00
24	18	\N	6	\N	2027-03-31	17	Compra/Doação	geral	active	\N	farmacia	\N	\N	2025-12-24 17:11:03.615+00	2025-12-24 17:11:03.615+00
25	19	\N	6	\N	2026-02-28	12	Compra/Doação	geral	active	\N	farmacia	\N	\N	2025-12-24 17:12:59.597+00	2025-12-24 17:12:59.597+00
26	20	\N	6	\N	2026-12-31	15	Compra/Doação	geral	active	\N	farmacia	\N	\N	2025-12-24 17:14:46.508+00	2025-12-24 17:14:46.508+00
27	21	\N	6	\N	2027-03-31	25	Compra/Doação	geral	active	\N	farmacia	\N	\N	2025-12-24 17:17:03.885+00	2025-12-24 17:17:03.885+00
29	22	\N	2	\N	2027-06-30	2	Farmácia Popular	geral	active	\N	farmacia	\N	\N	2025-12-24 17:26:39.354+00	2025-12-24 17:26:39.354+00
30	23	\N	2	\N	2027-04-30	4	Farmácia Popular	geral	active	\N	farmacia	\N	\N	2025-12-24 17:28:58.252+00	2025-12-24 17:28:58.252+00
31	24	42	1	\N	2027-09-30	60	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2025-12-24 17:35:44.558+00	2025-12-24 17:36:45.387+00
32	25	42	1	\N	2027-08-31	30	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2025-12-24 17:37:43.26+00	2025-12-24 17:37:43.26+00
33	26	42	1	\N	2027-07-31	4	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2025-12-24 17:38:38.14+00	2025-12-24 17:38:38.14+00
34	27	\N	6	\N	2028-06-30	105	Farmácia Popular	geral	active	\N	farmacia	\N	\N	2025-12-24 17:45:02.784+00	2025-12-24 17:45:02.784+00
35	28	\N	6	\N	2027-08-31	30	Farmácia Popular	geral	active	\N	farmacia	\N	\N	2025-12-24 17:46:08.279+00	2025-12-24 17:46:08.279+00
36	29	\N	6	\N	2027-05-31	60	Farmácia Popular	geral	active	\N	farmacia	\N	\N	2025-12-24 17:47:11.935+00	2025-12-24 17:47:11.935+00
37	30	29	2	\N	2028-04-30	30	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2025-12-24 17:48:17.939+00	2025-12-24 17:48:17.939+00
38	31	24	1	\N	2027-09-30	1	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2025-12-24 17:56:33.754+00	2025-12-24 17:56:33.754+00
40	33	24	1	\N	2027-10-31	30	Família	individual	active	\N	farmacia	\N	\N	2025-12-24 18:24:02.898+00	2025-12-24 18:24:02.898+00
43	24	9	1	\N	2027-09-30	30	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2025-12-24 18:31:19.178+00	2025-12-24 18:31:19.178+00
44	29	9	1	\N	2027-05-30	30	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2025-12-24 18:32:07.253+00	2025-12-24 18:32:07.253+00
47	34	6	1	\N	2027-06-30	1	Família	individual	active	\N	farmacia	\N	\N	2025-12-24 18:45:16.979+00	2025-12-24 18:45:16.979+00
48	35	6	1	\N	2027-09-30	56	Família	individual	active	\N	farmacia	\N	\N	2025-12-24 18:54:06.901+00	2025-12-24 18:54:06.901+00
49	35	6	1	\N	2027-01-31	20	Família	individual	active	\N	farmacia	\N	\N	2025-12-24 18:55:04.644+00	2025-12-24 18:55:04.644+00
51	27	3	1	\N	2028-05-30	30	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-06 11:46:04.712+00	2026-01-06 11:46:04.712+00
53	43	23	1	\N	2028-03-30	15	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 13:18:43.324+00	2026-01-07 13:18:43.324+00
56	39	23	1	\N	2027-09-30	28	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 13:26:25.067+00	2026-01-07 13:26:25.067+00
60	42	23	1	\N	2027-06-30	1	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 13:31:49.017+00	2026-01-07 13:31:49.017+00
59	41	23	1	\N	2027-05-30	20	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 13:30:23.322+00	2026-01-07 13:35:47.237+00
99	52	\N	4	\N	2026-02-28	1	UBS	geral	active	\N	farmacia	\N	\N	2026-01-09 13:21:46.726+00	2026-01-13 20:24:16.991+00
62	47	3	1	\N	2026-11-30	30	UBS	individual	active	\N	farmacia	\N	\N	2026-01-07 13:53:08.294+00	2026-01-07 13:53:08.294+00
64	49	4	1	\N	2027-05-30	30	UBS	individual	active	\N	farmacia	\N	\N	2026-01-07 15:09:38.74+00	2026-01-07 15:09:38.74+00
68	63	\N	7	\N	2027-05-30	7	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-07 17:18:11.5+00	2026-01-07 17:18:11.5+00
69	64	\N	3	\N	2028-05-30	45	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-07 17:25:15.216+00	2026-01-07 17:25:15.216+00
70	65	\N	3	\N	2026-03-30	1	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-07 17:43:05.348+00	2026-01-07 17:43:05.348+00
71	65	\N	3	\N	2026-09-30	1	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-07 17:43:57.1+00	2026-01-07 17:43:57.1+00
72	66	\N	3	\N	2027-04-30	1		geral	active	\N	farmacia	\N	\N	2026-01-07 17:45:06.754+00	2026-01-07 17:45:06.754+00
73	67	\N	3	\N	2026-06-30	1	Compra/Doação		active	\N	farmacia	\N	\N	2026-01-07 17:46:24.573+00	2026-01-07 17:46:24.573+00
74	67	\N	3	\N	2026-04-30	1	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-07 17:47:26.979+00	2026-01-07 17:47:26.979+00
187	107	\N	2	\N	2026-03-30	1	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-14 14:42:27.903+00	2026-01-14 14:42:27.903+00
188	133	\N	2	\N	2026-06-30	2	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-14 14:57:21.916+00	2026-01-14 14:57:21.916+00
189	132	\N	2	\N	2026-04-30	1	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-14 14:58:15.497+00	2026-01-14 14:58:15.497+00
191	129	\N	6	\N	2026-03-30	30	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-14 15:02:51.889+00	2026-01-14 15:02:51.889+00
192	131	\N	2	\N	2026-01-30	1	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-14 15:05:09.829+00	2026-01-14 15:05:09.829+00
75	67	\N	3	\N	2026-05-30	2	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-07 17:48:26.085+00	2026-01-07 17:48:26.085+00
76	68	\N	3	\N	2026-03-30	1	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-07 17:52:02.464+00	2026-01-07 17:52:02.464+00
77	69	\N	3	\N	2027-07-30	2	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-07 17:52:55.067+00	2026-01-07 17:52:55.067+00
78	64	\N	3	\N	2028-03-30	60	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-07 19:11:12.715+00	2026-01-07 19:11:12.715+00
79	41	18	1	\N	2027-08-30	30	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 19:12:41.025+00	2026-01-07 19:12:41.025+00
82	36	35	1	\N	2027-06-30	60	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 21:16:22.926+00	2026-01-07 21:16:22.926+00
83	70	35	1	\N	2027-06-30	30	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 21:20:48.76+00	2026-01-07 21:20:48.76+00
81	41	35	1	\N	2026-11-30	20	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 21:14:31.127+00	2026-01-07 21:22:25.625+00
52	37	6	1	\N	2027-03-30	0	Família	individual	active	\N	farmacia	\N	\N	2026-01-06 11:50:02.2+00	2026-01-21 15:08:16.876+00
63	48	4	2	\N	2026-11-20	98	UBS	individual	active	\N	farmacia	\N	\N	2026-01-07 15:06:33.642+00	2026-01-21 21:06:26.156+00
57	38	23	1	\N	2027-02-21	0	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 13:27:54.102+00	2026-01-22 13:23:53.122+00
66	45	12	1	\N	2026-09-30	40	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 16:28:53.344+00	2026-01-23 11:48:47.666+00
45	22	26	1	\N	2027-06-30	1	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2025-12-24 18:34:19.634+00	2026-01-23 16:58:14.378+00
55	40	23	1	\N	2027-02-28	5	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 13:22:05.23+00	2026-01-26 11:51:23.623+00
42	23	39	1	\N	2027-06-30	1	Farmácia Popular	individual	active	1220728A	farmacia	\N	\N	2025-12-24 18:29:56.145+00	2026-01-26 19:06:17.017+00
41	22	39	1	\N	2027-06-30	1	Farmácia Popular	individual	active	07643327	farmacia	\N	\N	2025-12-24 18:28:49.785+00	2026-01-26 19:12:04.514+00
28	22	4	1	\N	2027-06-30	3	Farmácia Popular	individual	active	07643252	farmacia	\N	\N	2025-12-24 17:24:51.854+00	2026-01-26 19:47:35.724+00
103	35	\N	1	\N	2027-05-30	30	UBS	geral	active	\N	farmacia	\N	\N	2026-01-09 13:33:05.511+00	2026-01-27 20:15:38.206+00
50	36	4	1	\N	2027-05-31	2	UBS	individual	active	2515609	farmacia	\N	\N	2025-12-24 19:52:18.128+00	2026-01-27 20:26:11.707+00
39	32	24	3	\N	2027-07-31	60	Família	individual	active	\N	farmacia	\N	\N	2025-12-24 18:11:45.321+00	2026-01-28 21:41:12.279+00
54	45	23	1	\N	2027-03-30	30	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 13:20:57.2+00	2026-01-29 11:58:43.74+00
85	24	22	1	\N	2027-09-30	60	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 21:46:57.475+00	2026-01-07 21:46:57.475+00
86	16	22	1	\N	2027-09-30	30	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 21:48:07.235+00	2026-01-07 21:48:07.235+00
88	72	35	1	\N	2027-04-30	60	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 22:02:58.926+00	2026-01-07 22:02:58.926+00
89	73	1	1	\N	2026-10-30	36	Família	individual	active	\N	farmacia	\N	\N	2026-01-08 14:21:25.066+00	2026-01-08 14:21:25.066+00
91	16	1	1	\N	2026-08-30	30	Família	individual	active	\N	farmacia	\N	\N	2026-01-08 14:23:15.094+00	2026-01-08 14:23:15.094+00
61	46	26	2	\N	2027-09-30	0	UBS	individual	active	\N	farmacia	\N	\N	2026-01-07 13:45:58.205+00	2026-01-12 21:39:03.37+00
97	77	10	1	\N	2026-08-30	20	Família	individual	active	\N	farmacia	\N	\N	2026-01-08 17:01:58.419+00	2026-01-08 17:07:24.343+00
96	76	10	1	\N	2026-02-28	0	Família	individual	active	\N	farmacia	\N	\N	2026-01-08 17:01:10.632+00	2026-01-08 17:10:00.431+00
98	78	\N	2	\N	2026-01-30	14	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-08 17:23:00.818+00	2026-01-08 17:23:00.818+00
18	16	\N	6	\N	2026-08-31	45	Compra/Doação	geral	active	\N	farmacia	\N	\N	2025-12-24 15:16:14.169+00	2026-01-15 12:19:29.192+00
105	54	26	1	\N	2026-10-30	60	UBS	individual	active	\N	farmacia	\N	\N	2026-01-09 13:39:46.514+00	2026-01-09 13:39:46.514+00
108	25	38	1	\N	2027-10-30	30	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2026-01-09 14:00:29.597+00	2026-01-09 14:00:29.597+00
112	29	13	1	\N	2027-05-30	30	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2026-01-09 14:09:26.404+00	2026-01-09 14:09:26.404+00
104	35	26	1	\N	2027-05-30	60	UBS	individual	active	\N	farmacia	\N	\N	2026-01-09 13:38:50.832+00	2026-01-09 14:14:19.75+00
113	81	26	1	\N	2027-07-30	1	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2026-01-09 14:18:55.787+00	2026-01-09 14:18:55.787+00
114	83	35	1	\N	2027-09-30	45	Família	individual	active	\N	farmacia	\N	\N	2026-01-09 15:11:47.211+00	2026-01-09 15:21:58.289+00
117	28	19	1	\N	2027-07-30	30	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2026-01-12 16:48:18.438+00	2026-01-12 16:48:18.438+00
119	45	19	1	\N	2027-07-30	30	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2026-01-12 16:51:27.255+00	2026-01-12 16:51:27.255+00
95	75	10	1	\N	2027-06-30	10	Família	individual	active	\N	farmacia	\N	\N	2026-01-08 16:56:58.585+00	2026-01-12 18:11:19.044+00
121	84	15	1	\N	2028-02-28	15	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 18:13:17.443+00	2026-01-12 18:13:17.443+00
122	86	15	1	\N	2027-10-30	30	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 18:14:50.956+00	2026-01-12 18:14:50.956+00
125	88	28	1	\N	2027-05-30	20	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 18:35:54.31+00	2026-01-12 18:35:54.31+00
129	94	42	1	\N	2027-04-30	0	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 18:57:42.103+00	2026-01-12 18:58:30.279+00
139	40	29	1	\N	2027-07-30	30	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 22:31:58.014+00	2026-01-12 22:31:58.014+00
141	96	8	1	\N	2027-07-30	4	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 22:41:06.762+00	2026-01-12 22:41:06.762+00
142	97	8	2	\N	2027-03-30	16	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 22:44:23.857+00	2026-01-12 22:44:23.857+00
143	98	34	1	\N	2027-08-30	60	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 22:49:02.838+00	2026-01-12 22:49:02.838+00
144	99	34	1	\N	2026-10-30	60	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 22:54:52.452+00	2026-01-12 22:54:52.452+00
145	88	34	1	\N	2027-05-30	40	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 22:55:54.038+00	2026-01-12 22:55:54.038+00
147	72	38	1	\N	2027-01-30	60	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 23:07:27.003+00	2026-01-12 23:07:27.003+00
150	103	11	3	\N	2028-08-30	36	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 23:15:55.459+00	2026-01-12 23:15:55.459+00
151	39	33	1	\N	2027-07-30	7	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 23:19:03.081+00	2026-01-20 12:35:49.5+00
140	87	8	3	\N	2027-02-28	8	Compra/Doação	individual	active	MPA250158	farmacia	\N	\N	2026-01-12 22:34:40.913+00	2026-01-29 12:34:25.614+00
102	16	\N	1	\N	2026-08-30	30	UBS	geral	active	\N	farmacia	\N	\N	2026-01-09 13:32:12.012+00	2026-01-27 20:15:28.934+00
84	71	40	3	\N	2027-05-30	6	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 21:39:52.819+00	2026-01-16 22:05:26.375+00
67	50	28	6	\N	2026-01-30	16	Compra/Doação	individual	active	900356	farmacia	\N	\N	2026-01-07 17:06:51.734+00	2026-01-27 20:31:36.343+00
127	92	42	1	\N	2027-02-28	15	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 18:43:27.586+00	2026-01-19 13:52:14.136+00
92	74	1	1	\N	2026-12-30	10	Família	individual	active	\N	farmacia	\N	\N	2026-01-08 14:24:24.226+00	2026-01-19 13:54:38.946+00
110	27	3	1	\N	2028-06-30	45	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2026-01-09 14:03:59.56+00	2026-01-19 15:17:47.461+00
93	26	1	1	\N	2028-05-30	4	Família	individual	active	\N	farmacia	\N	\N	2026-01-08 14:25:26.358+00	2026-01-19 14:57:34.534+00
138	33	29	3	\N	2027-10-30	20	Compra/Doação	individual	active	50306956	farmacia	\N	\N	2026-01-12 22:29:40.896+00	2026-01-26 12:02:59.993+00
111	24	13	1	\N	2027-09-30	10	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2026-01-09 14:08:40.791+00	2026-01-19 16:20:20.476+00
135	91	26	3	\N	2027-03-30	10	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 22:12:47.333+00	2026-01-20 18:22:04.222+00
134	90	26	3	\N	2027-04-30	12	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 22:12:01.08+00	2026-01-20 18:21:38.785+00
124	87	15	3	\N	2027-02-28	37	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 18:30:32.693+00	2026-01-20 20:14:33.809+00
136	64	29	3	\N	2027-08-30	16	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 22:20:47.964+00	2026-01-20 21:15:14.57+00
146	100	34	3	\N	2027-10-30	10	Compra/Doação	individual	active	561616	farmacia	\N	\N	2026-01-12 22:56:36.101+00	2026-01-28 22:04:29.799+00
132	56	\N	1	\N	2027-03-30	15	Compra/Doação	geral	suspended	\N	farmacia	2026-01-21 13:17:19.295+00	\N	2026-01-12 21:55:47.635+00	2026-01-21 13:17:53.474+00
109	16	3	1	\N	2027-08-30	30	Farmácia Popular	individual	active	4Y7708	farmacia	\N	\N	2026-01-09 14:03:04.612+00	2026-01-29 12:05:36.918+00
115	83	18	1	\N	2027-08-30	30	Família	individual	active	\N	farmacia	\N	\N	2026-01-09 18:19:19.083+00	2026-01-22 13:23:26.198+00
118	24	19	1	\N	2027-09-30	20	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2026-01-12 16:49:30.393+00	2026-01-22 18:08:09.643+00
106	55	26	1	\N	2027-01-30	50	UBS	individual	active	\N	farmacia	\N	\N	2026-01-09 13:40:57.944+00	2026-01-22 18:10:07.19+00
133	95	26	1	\N	2026-11-30	20	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 22:05:28.083+00	2026-01-22 18:12:50.205+00
87	28	22	1	\N	2027-07-30	15	Família	individual	active	\N	farmacia	\N	\N	2026-01-07 21:50:54.624+00	2026-01-22 18:24:13.572+00
149	101	38	3	\N	2027-07-30	1	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 23:08:55.939+00	2026-01-23 13:26:21.292+00
126	89	19	3	\N	2027-08-30	15	Compra/Doação	individual	active	50300038	farmacia	\N	\N	2026-01-12 18:40:03.014+00	2026-01-23 14:01:11.577+00
120	85	15	1	\N	2026-12-30	15	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 18:04:42.107+00	2026-01-26 11:50:31.231+00
131	58	28	1	\N	2027-09-30	20	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 21:47:03.598+00	2026-01-26 11:52:33.455+00
137	71	29	3	\N	2027-11-30	1	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 22:21:44.422+00	2026-01-27 11:52:48.823+00
100	34	\N	1	\N	2027-06-30	0	UBS	geral	active	\N	farmacia	\N	\N	2026-01-09 13:30:19.258+00	2026-01-27 20:15:33.765+00
101	61	\N	1	\N	2026-06-30	0	UBS	geral	active	\N	farmacia	\N	\N	2026-01-09 13:31:05.178+00	2026-01-27 20:15:46.458+00
161	102	11	1	\N	2027-07-30	15	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-13 19:26:57.887+00	2026-01-13 19:29:24.838+00
153	106	19	1	\N	2027-03-30	0	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 23:40:04.197+00	2026-01-12 23:41:12.512+00
154	107	27	1	\N	2026-03-30	0	Família	individual	active	\N	farmacia	\N	\N	2026-01-12 23:45:53.53+00	2026-01-12 23:46:56.946+00
107	80	29	1	\N	2028-03-30	15	Farmácia Popular	individual	active	\N	farmacia	\N	\N	2026-01-09 13:56:37.905+00	2026-01-13 13:27:34.286+00
155	109	27	2	\N	2026-03-09	0	Família	individual	active	\N	farmacia	\N	\N	2026-01-13 16:37:10.271+00	2026-01-13 16:38:04.392+00
156	108	27	1	\N	2026-02-24	0	Família	individual	active	\N	farmacia	\N	\N	2026-01-13 16:39:21.253+00	2026-01-13 16:40:54.565+00
160	102	38	1	\N	2027-07-30	15	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-13 19:25:57.976+00	2026-01-13 19:25:57.976+00
163	65	14	3	\N	2027-07-30	1	UBS	individual	active	\N	farmacia	\N	\N	2026-01-13 19:35:48.812+00	2026-01-13 19:35:48.812+00
167	52	7	1	\N	2026-04-30	2	UBS	individual	active	\N	farmacia	\N	\N	2026-01-13 19:46:52.451+00	2026-01-13 19:46:52.451+00
165	114	7	1	\N	2026-10-30	2	UBS	individual	active	\N	farmacia	\N	\N	2026-01-13 19:44:21.536+00	2026-01-13 20:22:38.104+00
168	116	42	1	\N	2027-06-30	8	UBS	individual	active	\N	farmacia	\N	\N	2026-01-13 20:28:34.49+00	2026-01-13 20:28:34.49+00
169	114	26	1	\N	2026-10-30	1	UBS	individual	active	\N	farmacia	\N	\N	2026-01-13 20:46:36.701+00	2026-01-13 20:51:49.382+00
170	114	11	1	\N	2026-10-30	2	UBS	individual	active	\N	farmacia	\N	\N	2026-01-13 20:49:15.741+00	2026-01-13 20:54:02.296+00
171	115	11	1	\N	2027-01-30	2	UBS	individual	active	\N	farmacia	\N	\N	2026-01-13 20:50:16.272+00	2026-01-13 20:55:13.008+00
173	114	8	1	\N	2026-10-30	2	UBS	individual	active	\N	farmacia	\N	\N	2026-01-13 20:58:12.806+00	2026-01-13 21:00:01.898+00
157	110	\N	4	\N	2027-02-28	1	UBS	individual	active	\N	farmacia	\N	\N	2026-01-13 19:06:43.685+00	2026-01-13 21:37:40.072+00
177	118	\N	6	\N	2027-06-30	60	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-13 21:40:32.504+00	2026-01-13 21:40:32.504+00
159	59	2	1	\N	2026-09-30	8	UBS	individual	active	\N	farmacia	\N	\N	2026-01-13 19:11:16.315+00	2026-01-13 21:43:22.197+00
182	27	25	1	\N	2028-09-30	30	Família	individual	active	\N	farmacia	\N	\N	2026-01-14 14:02:37.128+00	2026-01-14 14:02:37.128+00
181	121	25	1	\N	2027-06-30	0	Família	individual	active	\N	farmacia	\N	\N	2026-01-14 13:20:22.378+00	2026-01-14 13:21:42.356+00
184	71	25	3	\N	2028-04-30	30		individual	active	\N	farmacia	\N	\N	2026-01-14 14:06:49.548+00	2026-01-14 14:06:49.548+00
186	125	25	3	\N	2026-06-30	110	Autocusto	individual	active	\N	farmacia	\N	\N	2026-01-14 14:13:49.939+00	2026-01-14 14:13:49.939+00
196	35	\N	6	\N	2026-12-30	0	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-15 11:57:50.179+00	2026-01-15 11:59:21.013+00
197	35	2	1	\N	2026-12-30	0	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-15 12:00:21.212+00	2026-01-15 12:01:33.248+00
193	134	18	3	\N	2027-05-30	0	Família	individual	active	\N	farmacia	\N	\N	2026-01-15 11:50:34.53+00	2026-01-15 12:06:20.055+00
195	111	34	3	\N	2027-03-30	0	UBS	individual	active	\N	farmacia	\N	\N	2026-01-15 11:56:35.622+00	2026-01-15 12:10:17.822+00
198	35	13	1	\N	2027-05-30	0	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-15 12:02:25.001+00	2026-01-15 12:11:57.303+00
199	135	18	1	\N	2026-10-30	0	Família	individual	active	\N	farmacia	\N	\N	2026-01-15 12:05:00.45+00	2026-01-15 12:13:28.354+00
200	16	39	1	\N	2026-08-30	30	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-15 12:20:48.953+00	2026-01-15 12:22:19.101+00
176	117	35	1	\N	2026-07-12	0	Família	individual	active	\N	farmacia	\N	\N	2026-01-13 21:35:44.52+00	2026-01-15 12:23:55.617+00
208	111	40	3	\N	2027-03-30	0	Família	individual	active	25045P	farmacia	\N	Psicotrópico	2026-01-16 14:27:18.337+00	2026-01-16 14:36:15.699+00
201	43	27	1	\N	2028-05-30	36	Família	individual	suspended	L22803	farmacia	2026-01-15 20:57:32.83+00	\N	2026-01-15 20:55:33+00	2026-01-15 20:57:32.83+00
172	115	8	1	\N	2027-01-30	0	UBS	individual	active	\N	farmacia	\N	\N	2026-01-13 20:57:20.1+00	2026-01-21 16:30:51.937+00
206	138	29	3	\N	2027-01-30	30	Altocusto	individual	active	25010044	farmacia	\N	Psicotrópico	2026-01-16 14:19:21.103+00	2026-01-16 14:19:21.103+00
204	139	22	3	\N	2027-04-30	0	Compra/Doação	individual	active	LERA0451	farmacia	\N	Psicotrópico	2026-01-16 14:16:17.513+00	2026-01-16 14:28:20.747+00
194	126	19	3	\N	2027-01-30	140	Altocusto	individual	active	50023326A	farmacia	\N	\N	2026-01-15 11:55:14.198+00	2026-01-27 21:22:11.222+00
207	64	29	3	\N	2027-08-30	15	Altocusto	individual	active	40511276	farmacia	\N	Psicotrópico	2026-01-16 14:21:25.912+00	2026-01-16 14:30:59.501+00
210	143	40	1	\N	2027-06-30	30	Família	individual	active	4W4964	farmacia	\N		2026-01-16 15:22:51.582+00	2026-01-16 15:22:51.582+00
211	142	40	1	\N	2027-01-30	30	Família	individual	active	BR177565	farmacia	\N		2026-01-16 15:25:09.74+00	2026-01-16 15:25:09.74+00
212	16	40	1	\N	2026-12-30	30	Família	individual	active	PH8301	farmacia	\N		2026-01-16 15:26:03.287+00	2026-01-16 15:26:03.287+00
213	29	40	1	\N	2026-08-30	30	Família	individual	active	L933297	farmacia	\N		2026-01-16 16:41:07.386+00	2026-01-16 16:41:07.386+00
214	144	40	1	\N	2026-07-30	10	Família	individual	active	L24H326	farmacia	\N		2026-01-16 17:04:02.395+00	2026-01-16 17:04:02.395+00
217	58	1	1	\N	2027-09-30	80	Família	individual	active	1034378	farmacia	\N		2026-01-16 17:10:40.858+00	2026-01-16 17:10:40.858+00
219	146	16	1	\N	2027-07-30	4	Família	individual	active	557295	farmacia	\N		2026-01-16 17:19:48.106+00	2026-01-16 17:19:48.106+00
220	16	16	1	\N	2027-01-30	30	Família	individual	active	PL4709	farmacia	\N	Uso contínuo	2026-01-16 17:20:55.994+00	2026-01-16 17:20:55.994+00
221	145	16	1	\N	2027-09-30	1	Família	individual	active	2539558	farmacia	\N	Uso contínuo	2026-01-16 17:21:56.85+00	2026-01-16 17:21:56.85+00
222	73	16	1	\N	2027-02-28	12	Família	individual	active	2504982	farmacia	\N		2026-01-16 17:23:11.278+00	2026-01-16 17:23:11.278+00
162	111	13	3	\N	2027-06-30	45	UBS	individual	active	\N	farmacia	\N	\N	2026-01-13 19:32:56.792+00	2026-01-23 13:53:20.093+00
183	122	25	1	\N	2028-04-30	20	Família	individual	active	\N	farmacia	\N	\N	2026-01-14 14:05:56.601+00	2026-01-19 12:49:48.486+00
180	71	\N	6	\N	2027-10-30	50	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-14 13:12:28.575+00	2026-01-19 13:02:47.698+00
94	44	1	1	\N	2027-01-30	7	Família	individual	active	\N	farmacia	\N	\N	2026-01-08 14:26:49.24+00	2026-01-19 14:59:57.396+00
166	115	7	1	\N	2027-01-30	1	UBS	individual	active	\N	farmacia	\N	\N	2026-01-13 19:46:12.372+00	2026-01-19 15:32:49.037+00
175	76	\N	1	\N	2026-07-30	1	UBS	geral	active	\N	farmacia	\N	\N	2026-01-13 21:04:47.951+00	2026-01-20 13:42:55.606+00
174	52	8	4	\N	2026-04-30	1	UBS	individual	active	\N	farmacia	\N	\N	2026-01-13 21:01:50.063+00	2026-01-21 21:00:58.124+00
218	95	16	1	\N	2027-10-30	45	Família	individual	active	2510845	farmacia	\N		2026-01-16 17:17:04.565+00	2026-01-22 13:20:40.224+00
178	102	25	1	\N	2027-08-30	30	Família	individual	active	\N	farmacia	\N	\N	2026-01-14 13:09:09.778+00	2026-01-22 18:23:10.27+00
148	102	38	1	\N	2027-05-30	30	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 23:08:10.471+00	2026-01-22 20:33:31.637+00
215	17	40	1	\N	2027-01-30	20	Família	individual	active	17135Y	farmacia	\N		2026-01-16 17:05:17.41+00	2026-01-22 20:35:19.042+00
164	113	2	3	\N	2026-11-30	20	UBS	individual	active	\N	farmacia	\N	\N	2026-01-13 19:39:57.144+00	2026-01-23 11:50:33.464+00
209	141	40	3	\N	2027-06-30	10	Família	individual	active	LFKP07577	farmacia	\N	Psicotrópico	2026-01-16 15:21:13.306+00	2026-01-23 13:31:06.665+00
185	123	25	3	\N	2026-04-30	50	Altocusto	individual	active	50022743	farmacia	\N	\N	2026-01-14 14:12:53.637+00	2026-01-23 16:51:47.509+00
158	110	13	4	\N	2027-08-30	2	UBS	individual	active	\N	farmacia	\N	\N	2026-01-13 19:09:55.092+00	2026-01-23 18:27:23.517+00
223	147	10	1	\N	2027-04-30	30	Família	individual	active	42900961	farmacia	\N	Uso contínuo	2026-01-16 17:34:58.293+00	2026-01-16 17:34:58.293+00
224	148	10	2	\N	2026-04-30	1	Família	individual	active	5640912	farmacia	\N	\N	2026-01-16 17:35:57.213+00	2026-01-16 17:35:57.213+00
225	26	18	1	\N	2027-01-30	4	Família	individual	active	4Q3825	farmacia	\N	Uso contínuo	2026-01-16 17:38:24.542+00	2026-01-16 17:38:24.542+00
226	26	18	1	\N	2028-05-30	4	Família	individual	active	25086	farmacia	\N	Uso contínuo	2026-01-16 17:41:21.608+00	2026-01-16 17:41:21.608+00
228	27	18	1	\N	2028-03-30	30	Família	individual	active	BR177625	farmacia	\N	contínuo	2026-01-16 17:45:47.399+00	2026-01-16 17:45:47.399+00
229	27	18	1	\N	2028-07-30	30	Família	individual	active	BR181483	farmacia	\N		2026-01-16 17:46:48.322+00	2026-01-16 17:46:48.322+00
231	149	18	1	\N	2026-09-30	30	Família	individual	active	PE0324	farmacia	\N		2026-01-16 17:53:19.055+00	2026-01-16 17:53:19.055+00
232	149	18	1	\N	2026-12-30	60	Família	individual	active	PJ7090	farmacia	\N		2026-01-16 17:54:32.971+00	2026-01-16 17:55:51.327+00
233	149	18	1	\N	2027-09-30	30	Família	individual	active	PR7116	farmacia	\N		2026-01-16 17:56:57.231+00	2026-01-16 17:56:57.231+00
237	28	18	1	\N	2027-03-30	30	Família	individual	active	LFRA01481	farmacia	\N		2026-01-16 18:09:18.331+00	2026-01-16 18:09:18.331+00
238	16	18	1	\N	2026-10-30	30	Família	individual	active	PF7036	farmacia	\N		2026-01-16 18:10:13.354+00	2026-01-16 18:10:13.354+00
239	16	18	1	\N	2027-04-30	30	Família	individual	active	PP5177	farmacia	\N		2026-01-16 18:11:07.771+00	2026-01-16 18:11:07.771+00
227	83	18	1	\N	2027-04-30	60	Família	individual	active	3025426	farmacia	\N		2026-01-16 17:44:13.498+00	2026-01-16 18:13:39.039+00
241	152	18	1	\N	2027-04-30	30	Família	individual	active	987108	farmacia	\N		2026-01-16 18:19:25.126+00	2026-01-16 18:19:25.126+00
242	154	35	1	\N	2027-04-09	0	Família	individual	active	ER325040332	farmacia	\N		2026-01-16 18:47:24.186+00	2026-01-16 18:51:48.134+00
244	154	35	1	\N	2027-04-09	1	Família	individual	active	EN325040332	enfermagem	\N		2026-01-16 18:53:23.232+00	2026-01-16 18:53:23.232+00
243	153	35	1	\N	2027-04-30	0	Família	individual	active	ER325050072	farmacia	\N		2026-01-16 18:50:41.327+00	2026-01-16 18:54:09.685+00
245	153	35	1	\N	2027-04-30	1	Família	individual	active		enfermagem	\N		2026-01-16 18:56:33.265+00	2026-01-16 18:56:33.265+00
250	16	18	1	\N	2026-08-30	30	Família	individual	active	PD0504	farmacia	\N		2026-01-16 19:17:35.148+00	2026-01-16 19:17:35.148+00
251	135	18	1	\N	2026-10-30	100	Família	individual	active	242048	farmacia	\N		2026-01-16 19:19:13.578+00	2026-01-16 19:19:13.578+00
253	103	18	1	\N	2028-09-30	36	Família	individual	active	50508074	farmacia	\N		2026-01-16 19:22:31.885+00	2026-01-16 19:22:31.885+00
254	155	18	1	\N	2026-05-30	1	Família	individual	active	24F286	farmacia	\N		2026-01-16 19:33:24.52+00	2026-01-16 19:34:03.731+00
249	55	18	1	\N	2027-01-30	10	Família	individual	active	258798	farmacia	\N		2026-01-16 19:14:27.551+00	2026-01-21 21:08:12.331+00
271	64	9	3	\N	2028-08-30	30	Compra/Doação	individual	active	\N	enfermagem	\N	\N	2026-01-16 21:16:21.351+00	2026-01-23 13:45:08.485+00
267	64	20	3	\N	2026-05-30	18	Família	individual	active	50400733	enfermagem	\N	Psicotrópico - uso contínuo	2026-01-16 21:09:03.691+00	2026-01-16 21:09:03.691+00
260	91	36	3	\N	2026-03-30	10	Família	individual	active	912528	enfermagem	\N	Psicotrópico - uso contínuo	2026-01-16 20:12:28.985+00	2026-01-16 20:12:28.985+00
257	91	36	3	\N	2026-03-30	0	Família	individual	active	912528	farmacia	\N	Psicotrópico - uso contínuo	2026-01-16 19:54:33.395+00	2026-01-16 20:12:28.99+00
261	119	20	3	\N	2027-07-30	1	Família	individual	active	50030073	enfermagem	\N		2026-01-16 20:45:08.296+00	2026-01-16 20:45:08.296+00
246	119	20	3	\N	2027-07-30	0	Família	individual	active	50030073	farmacia	\N		2026-01-16 19:07:14.952+00	2026-01-16 20:45:08.303+00
263	123	30	3	\N	2026-04-30	23	Altocusto	individual	active	50013432	enfermagem	\N	Psicotrópico - uso contínuo	2026-01-16 20:51:06.617+00	2026-01-16 20:51:06.617+00
262	123	30	3	\N	2026-04-30	0	Altocusto	individual	active	50013432	farmacia	\N	Psicotrópico - uso contínuo	2026-01-16 20:48:51.399+00	2026-01-16 20:51:06.623+00
264	64	20	3	\N	2026-05-30	0	Família	individual	active	50400733	farmacia	\N	Psicotrópico - uso contínuo	2026-01-16 20:58:54.767+00	2026-01-16 21:09:03.697+00
268	125	20	3	\N	2027-09-30	25	Família	individual	active	5A7170	enfermagem	\N		2026-01-16 21:09:57.744+00	2026-01-23 14:14:26.644+00
269	123	20	3	\N	2027-07-30	31	Família	individual	active	50308023	enfermagem	\N	Psicotrópico - uso contínuo	2026-01-16 21:11:38.84+00	2026-01-23 14:07:31.348+00
270	87	8	3	\N	2027-02-28	12	Compra/Doação	individual	active	\N	enfermagem	\N	\N	2026-01-16 21:14:17.343+00	2026-01-16 21:14:17.343+00
240	134	18	1	\N	2027-03-30	20	Família	individual	active	LFK06420	farmacia	\N		2026-01-16 18:14:46.824+00	2026-01-23 13:58:03.283+00
266	125	20	3	\N	2027-09-30	20	Família	individual	active	5A7170	farmacia	\N		2026-01-16 21:06:32.671+00	2026-01-23 14:14:26.647+00
275	123	9	3	\N	2026-03-30	45	Altocusto	individual	active	50011722	enfermagem	\N	Psicotrópico - uso contínuo	2026-01-16 21:25:38.801+00	2026-01-23 13:48:58.542+00
278	123	23	3	\N	2027-07-30	30	Família	individual	active	5B7085	enfermagem	\N	Psicotrópico - uso contínuo	2026-01-16 21:41:06.631+00	2026-01-16 21:41:06.631+00
277	123	23	3	\N	2027-07-30	0	Família	individual	active	5B7085	farmacia	\N	Psicotrópico - uso contínuo	2026-01-16 21:37:13.231+00	2026-01-16 21:41:06.637+00
279	144	23	3	\N	2028-08-30	10	Família	individual	active	51411334	farmacia	\N		2026-01-16 21:43:30.018+00	2026-01-16 21:43:30.018+00
282	156	22	3	\N	2027-02-28	15	Família	individual	active	41107863	enfermagem	\N	Psicotrópico - uso contínuo	2026-01-16 21:55:20.346+00	2026-01-16 21:55:20.346+00
276	71	29	3	\N	2027-11-30	20	Compra/Doação	individual	active	\N	enfermagem	\N	\N	2026-01-16 21:28:30.405+00	2026-01-20 21:17:44.975+00
272	123	9	3	\N	2026-03-30	20	Altocusto	individual	active	50011722	farmacia	\N	Psicotrópico - uso contínuo	2026-01-16 21:19:17.808+00	2026-01-23 13:48:58.556+00
281	64	40	1	\N	2027-05-30	14	Família	individual	active	\N	enfermagem	\N		2026-01-16 21:54:23.052+00	2026-01-20 21:48:31.709+00
234	151	18	1	\N	2027-01-30	15	Família	individual	active	BR180114	farmacia	\N		2026-01-16 18:03:59.518+00	2026-01-22 18:01:56.524+00
230	43	18	1	\N	2028-11-30	45	Família	individual	active	505827	farmacia	\N		2026-01-16 17:47:41.687+00	2026-01-22 18:06:36.806+00
248	80	35	1	\N	2027-09-30	20	Família	individual	active	120835	farmacia	\N		2026-01-16 19:11:32.778+00	2026-01-22 20:28:56.478+00
247	27	35	1	\N	2028-09-30	15	Família	individual	active	BR183391	farmacia	\N		2026-01-16 19:10:17.11+00	2026-01-22 20:29:57.582+00
259	89	36	3	\N	2027-08-30	30	Família	individual	active	25H2B8	enfermagem	\N	Psiccotrópico - uso contínuo	2026-01-16 20:09:55.693+00	2026-01-23 13:15:41.661+00
258	89	36	3	\N	2027-08-30	80	Família	individual	active	25H2B8	farmacia	\N	Psiccotrópico - uso contínuo	2026-01-16 20:04:44.394+00	2026-01-23 13:15:41.666+00
274	51	9	3	\N	2027-07-30	105	UBS	individual	active	25070534	enfermagem	\N	Psicotrópico - uso contínuo	2026-01-16 21:24:16.011+00	2026-01-28 15:20:53.547+00
235	29	18	1	\N	2027-05-30	30	Família	individual	active	B25E042	farmacia	\N		2026-01-16 18:06:47.551+00	2026-01-29 12:01:50.856+00
280	156	22	3	\N	2027-02-28	0	Família	individual	active	41107863	farmacia	\N	Psicotrópico - uso contínuo	2026-01-16 21:51:23.115+00	2026-01-16 21:55:20.352+00
285	71	40	3	\N	2027-05-30	14	Família	individual	active	\N	enfermagem	\N	\N	2026-01-16 22:05:26.369+00	2026-01-16 22:05:26.369+00
286	158	35	3	\N	2028-04-30	14	Família	individual	active	240689	farmacia	\N	Psicotrópico - uso contínuo	2026-01-16 22:16:21.384+00	2026-01-16 22:16:21.384+00
287	157	36	3	\N	2026-09-30	14	Família	individual	active	240669	farmacia	\N	Psicotrópico - uso contínuo	2026-01-16 22:18:15.572+00	2026-01-16 22:18:15.572+00
289	149	\N	1	\N	2027-08-30	60	UBS	geral	active		farmacia	\N	Uso contínuo	2026-01-17 13:21:04.731+00	2026-01-17 13:21:04.731+00
290	159	39	1	\N	2027-01-30	60	UBS	individual	active		farmacia	\N	Uso contínuo	2026-01-17 13:24:40.87+00	2026-01-17 13:24:40.87+00
291	29	39	1	\N	2027-06-30	60	UBS	individual	active		farmacia	\N	Uso contínuo	2026-01-17 13:25:43.652+00	2026-01-17 13:25:43.652+00
292	28	39	1	\N	2027-07-30	30	UBS	individual	active		farmacia	\N	Uso contínuo	2026-01-17 13:26:58.888+00	2026-01-17 13:26:58.888+00
299	30	29	2	\N	2028-05-30	2	Altocusto	individual	active		farmacia	\N	Uso contínuo	2026-01-17 14:06:31.565+00	2026-01-17 14:06:31.565+00
300	35	14	1	\N	2027-05-30	28	UBS	individual	active		farmacia	\N		2026-01-17 14:10:05.961+00	2026-01-17 14:10:05.961+00
301	160	14	1	\N	2027-10-30	30	UBS	individual	active		farmacia	\N		2026-01-17 14:12:26.207+00	2026-01-17 14:12:26.207+00
302	54	14	1	\N	2026-10-30	20	UBS	individual	active		farmacia	\N		2026-01-17 14:13:40.442+00	2026-01-17 14:13:40.442+00
304	26	26	1	\N	2028-05-30	4	UBS	individual	active		farmacia	\N	L:25086	2026-01-17 14:35:45.793+00	2026-01-17 14:35:45.793+00
305	143	26	1	\N	2027-06-30	30	UBS	individual	active		farmacia	\N	L:4W4964	2026-01-17 14:38:32.003+00	2026-01-17 14:38:32.003+00
306	55	19	1	\N	2027-01-30	30	UBS	individual	active		farmacia	\N	L:258798	2026-01-17 14:42:43.186+00	2026-01-17 14:42:43.186+00
309	61	\N	1	\N	2026-11-30	2	UBS	geral	active	114326	farmacia	\N		2026-01-17 14:49:43.06+00	2026-01-17 14:49:43.06+00
311	34	7	2	\N	2027-06-30	4	UBS	individual	active	0784/25	enfermagem	\N		2026-01-17 14:56:45.295+00	2026-01-17 14:56:45.295+00
324	64	25	3	\N	2027-05-30	0	Altocusto	individual	active	25E935	farmacia	\N	Uso contínuo	2026-01-19 13:25:52.095+00	2026-01-28 21:43:33.491+00
312	18	24	1	\N	2027-09-30	30	UBS	individual	active	25J065	farmacia	\N		2026-01-17 15:00:41.608+00	2026-01-17 15:00:41.608+00
314	143	28	1	\N	2027-06-30	30	UBS	individual	active	\N	farmacia	\N	L:4W4964	2026-01-17 15:05:33.648+00	2026-01-17 15:05:33.648+00
317	35	3	1	\N	2027-05-30	20	UBS	individual	active		enfermagem	\N	L:0670/25	2026-01-17 15:14:41.117+00	2026-01-17 15:14:41.117+00
316	35	3	1	\N	2027-05-30	0	UBS	individual	active		farmacia	\N	L:0670/25	2026-01-17 15:12:49.695+00	2026-01-17 15:14:41.124+00
318	35	4	1	\N	2027-05-30	28	UBS	individual	active	L:0670/25	enfermagem	\N		2026-01-17 15:15:00.651+00	2026-01-17 15:15:00.651+00
315	35	4	1	\N	2027-05-30	0	UBS	individual	active	L:0670/25	farmacia	\N		2026-01-17 15:10:51.616+00	2026-01-17 15:15:00.656+00
320	122	25	3	\N	2026-08-30	10	Compra/Doação	individual	active	2114489	farmacia	\N		2026-01-19 12:47:30.471+00	2026-01-19 12:47:30.471+00
321	122	25	1	\N	2028-04-30	10	Família	individual	active	\N	enfermagem	\N	\N	2026-01-19 12:49:48.479+00	2026-01-19 12:49:48.479+00
323	130	23	2	\N	2027-04-30	1	Compra/Doação	individual	active	\N	enfermagem	\N	\N	2026-01-19 13:05:14.563+00	2026-01-19 13:05:14.563+00
190	130	\N	2	\N	2027-04-30	1	Compra/Doação	geral	active	\N	farmacia	\N	\N	2026-01-14 15:01:54.769+00	2026-01-19 13:05:14.568+00
310	61	\N	1	\N	2026-06-30	2	UBS	geral	active	\N	farmacia	\N	\N	2026-01-17 14:51:07.691+00	2026-01-27 20:15:42.478+00
330	26	1	1	\N	2028-05-30	5	Família	individual	active	\N	enfermagem	\N	\N	2026-01-19 14:57:34.528+00	2026-01-19 14:57:34.528+00
308	34	\N	2	\N	2027-06-30	2	UBS	geral	active	0784/25	farmacia	\N		2026-01-17 14:48:05.584+00	2026-01-28 13:45:09.694+00
128	93	42	1	\N	2027-06-30	15	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 18:44:03.747+00	2026-01-19 13:48:23.978+00
326	92	42	1	\N	2027-02-28	15	Compra/Doação	individual	active	\N	enfermagem	\N	\N	2026-01-19 13:52:14.129+00	2026-01-19 13:52:14.129+00
328	162	30	3	\N	2027-07-30	20	Compra/Doação	individual	active	104790	enfermagem	\N		2026-01-19 14:32:25.756+00	2026-01-27 21:44:42.606+00
331	44	1	1	\N	2027-01-30	23	Família	individual	active	\N	enfermagem	\N	\N	2026-01-19 14:59:57.387+00	2026-01-19 14:59:57.387+00
333	44	2	1	\N	2027-01-30	25	UBS	individual	active	17192	enfermagem	\N		2026-01-19 15:04:24.612+00	2026-01-19 15:04:24.612+00
332	44	2	1	\N	2027-01-30	5	UBS	individual	active	17192	farmacia	\N		2026-01-19 15:03:53.296+00	2026-01-19 15:04:24.616+00
336	27	2	1	\N	2028-06-30	30	Compra/Doação	individual	active	BR181039	enfermagem	\N	Uso contínuo	2026-01-19 15:16:39.92+00	2026-01-27 20:23:42.699+00
337	27	3	1	\N	2028-06-30	15	Farmácia Popular	individual	active	\N	enfermagem	\N	\N	2026-01-19 15:17:47.456+00	2026-01-19 15:17:47.456+00
339	24	6	1	\N	2027-11-30	11	Família	individual	active		enfermagem	\N		2026-01-19 15:23:21.077+00	2026-01-19 15:23:21.077+00
338	24	6	1	\N	2027-11-30	40	Família	individual	active		farmacia	\N		2026-01-19 15:22:16.895+00	2026-01-19 15:23:21.082+00
341	24	7	1	\N	2027-10-30	15	Compra/Doação	individual	active		enfermagem	\N		2026-01-19 15:26:59.864+00	2026-01-19 15:26:59.864+00
340	24	7	1	\N	2027-10-30	10	Compra/Doação	individual	active		farmacia	\N		2026-01-19 15:25:57.298+00	2026-01-19 15:26:59.869+00
343	163	8	1	\N	2027-08-30	19	Família	individual	active	4Y9621	enfermagem	\N		2026-01-19 15:32:04.852+00	2026-01-19 15:32:04.852+00
342	163	8	1	\N	2027-08-30	45	Família	individual	active	4Y9621	farmacia	\N		2026-01-19 15:30:38.526+00	2026-01-19 15:32:04.856+00
344	115	7	1	\N	2027-01-30	1	UBS	individual	active	\N	enfermagem	\N	\N	2026-01-19 15:32:49.032+00	2026-01-19 15:32:49.032+00
345	44	9	1	\N	2027-01-30	20	Compra/Doação	individual	active		farmacia	\N		2026-01-19 15:36:16.866+00	2026-01-19 15:36:16.866+00
298	29	17	1	\N	2027-06-30	15	Altocusto	individual	active		farmacia	\N	Uso contínuo	2026-01-17 14:04:10.242+00	2026-01-22 13:21:44.688+00
295	149	39	1	\N	2027-05-30	30	UBS	individual	active		farmacia	\N	Uso contínuo	2026-01-17 13:39:34.692+00	2026-01-22 13:24:24.524+00
293	49	39	1	\N	2026-10-30	14	Compra/Doação	individual	active		farmacia	\N		2026-01-17 13:35:49.825+00	2026-01-22 15:22:55.865+00
297	24	17	1	\N	2027-09-30	14	Altocusto	individual	active		farmacia	\N	Uso contínuo	2026-01-17 14:03:18.291+00	2026-01-22 17:36:39.148+00
313	35	28	1	\N	2027-05-30	28	UBS	individual	active		farmacia	\N	L:0670/25M	2026-01-17 15:03:52.813+00	2026-01-22 18:39:00.462+00
296	143	39	1	\N	2027-10-30	30	UBS	individual	active		farmacia	\N		2026-01-17 13:41:23.352+00	2026-01-22 20:34:20.538+00
288	24	39	1	\N	2027-04-30	40	UBS	individual	active		farmacia	\N	Uso contínuo	2026-01-17 13:19:13.281+00	2026-01-22 20:34:47.21+00
284	141	40	3	\N	2027-06-30	20	Família	individual	active	LFKP07577	enfermagem	\N	Psicotrópico	2026-01-16 22:04:29.385+00	2026-01-23 13:31:06.662+00
319	161	11	3	\N	2027-06-30	7	UBS	individual	active	50029446	farmacia	\N		2026-01-17 15:21:23.963+00	2026-01-26 13:51:33.428+00
329	50	28	6	\N	2026-01-30	14	Compra/Doação	individual	active	900356	enfermagem	\N	\N	2026-01-19 14:49:44.347+00	2026-01-27 20:33:11.08+00
334	27	2	1	\N	2028-06-30	15	Compra/Doação	individual	active	BR181039	farmacia	\N	Uso contínuo	2026-01-19 15:09:39.522+00	2026-01-27 20:23:42.703+00
327	162	30	3	\N	2027-07-30	10	Compra/Doação	individual	active	104790	farmacia	\N		2026-01-19 14:26:14.934+00	2026-01-27 21:44:42.673+00
325	123	25	3	\N	2026-12-30	10	Altocusto	individual	active	50022743	farmacia	\N	Uso contínuo	2026-01-19 13:28:11.949+00	2026-01-28 21:44:37.714+00
283	51	33	3	\N	2026-06-30	0	Compra/Doação	individual	active	927429	farmacia	\N	Psicotrópico - uso contínuo	2026-01-16 21:59:02.831+00	2026-01-28 21:59:39.595+00
346	58	26	1	\N	2027-09-30	20	Compra/Doação	individual	active	\N	enfermagem	\N	\N	2026-01-19 16:28:08.461+00	2026-01-19 16:28:08.461+00
130	58	26	1	\N	2027-09-30	0	Compra/Doação	individual	active	\N	farmacia	\N	\N	2026-01-12 21:46:03.925+00	2026-01-19 16:28:08.47+00
348	43	35	1	\N	2027-08-30	15	Compra/Doação	individual	active	6H0819	enfermagem	\N		2026-01-19 16:35:23.008+00	2026-01-19 16:35:23.008+00
347	43	35	1	\N	2027-08-30	15	Compra/Doação	individual	active	6H0819	farmacia	\N		2026-01-19 16:33:01.052+00	2026-01-19 16:35:23.013+00
349	33	29	3	\N	2027-10-30	15	Compra/Doação	individual	active	\N	enfermagem	\N	\N	2026-01-19 16:38:20.253+00	2026-01-19 16:38:20.253+00
352	54	2	1	\N	2026-10-30	20	UBS	individual	active	1577/24M	farmacia	\N	Uso contínuo	2026-01-19 19:34:27.471+00	2026-01-19 19:34:27.471+00
353	106	2	1	\N	2026-10-30	60	UBS	individual	active	50020777	farmacia	\N		2026-01-19 19:39:46.325+00	2026-01-19 19:39:46.325+00
356	164	19	3	\N	2027-02-28	6	UBS	individual	active	2508414	farmacia	\N	Contínuo	2026-01-19 19:54:49.763+00	2026-01-19 19:54:49.763+00
360	161	2	4	\N	2027-06-30	2	UBS	individual	active		farmacia	\N	L: 50029446	2026-01-19 20:09:04.396+00	2026-01-19 20:09:04.396+00
361	115	2	1	\N	2027-01-30	1	UBS	individual	active		farmacia	\N		2026-01-19 20:09:52.466+00	2026-01-19 20:09:52.466+00
363	23	\N	2	\N	2027-07-30	1	Compra/Doação	geral	active	1218422	farmacia	\N		2026-01-19 20:28:17.951+00	2026-01-19 20:28:17.951+00
364	74	2	1	\N	2026-12-30	25	UBS	individual	active	BR176466	enfermagem	\N	Uso contínuo	2026-01-19 20:29:36.119+00	2026-01-19 20:29:36.119+00
351	74	2	1	\N	2026-12-30	0	UBS	individual	active	BR176466	farmacia	\N	Uso contínuo	2026-01-19 19:31:50.154+00	2026-01-19 20:29:36.128+00
365	165	\N	7	\N	2027-01-30	28	UBS	geral	active	1120070	farmacia	\N		2026-01-19 20:33:11.75+00	2026-01-19 20:33:11.75+00
367	35	11	6	\N	2027-05-30	28	UBS	individual	active		enfermagem	\N	0670/25M	2026-01-19 20:37:03.625+00	2026-01-19 20:37:03.625+00
368	39	33	1	\N	2027-07-30	14	Compra/Doação	individual	active	\N	enfermagem	\N	\N	2026-01-20 12:35:49.475+00	2026-01-20 12:35:49.475+00
375	125	38	3	\N	2027-02-28	160	Altocusto	individual	active	50025076	farmacia	\N	Uso contínuo	2026-01-20 13:06:27.925+00	2026-01-26 17:10:27.549+00
372	83	29	1	\N	2027-03-30	15	Compra/Doação	individual	active	3025371	enfermagem	\N		2026-01-20 12:55:22.238+00	2026-01-20 12:55:22.238+00
371	83	\N	1	\N	2027-03-30	15	Compra/Doação	geral	active	3025371	farmacia	\N		2026-01-20 12:54:15.235+00	2026-01-20 12:55:22.249+00
357	140	19	3	\N	2027-10-30	36	UBS	individual	active	50020767	farmacia	\N		2026-01-19 19:58:22.596+00	2026-01-27 21:20:13.275+00
393	90	26	3	\N	2027-04-30	18	Compra/Doação	individual	active	\N	enfermagem	\N	\N	2026-01-20 18:21:38.779+00	2026-01-20 18:21:38.779+00
377	166	11	7	\N	2027-05-30	15	UBS	individual	active	25E25V	enfermagem	\N		2026-01-20 13:37:00.982+00	2026-01-20 13:37:00.982+00
394	91	26	3	\N	2027-03-30	20	Compra/Doação	individual	active	\N	enfermagem	\N	\N	2026-01-20 18:22:04.211+00	2026-01-20 18:22:04.211+00
378	166	8	7	\N	2027-05-30	15	UBS	individual	active	25E25V	enfermagem	\N		2026-01-20 13:37:26.568+00	2026-01-20 13:37:26.568+00
376	166	\N	7	\N	2027-05-30	20	UBS	geral	active	25E25V	farmacia	\N		2026-01-20 13:35:47.897+00	2026-01-20 13:37:26.573+00
380	160	11	2	\N	2026-09-30	20	Compra/Doação	individual	active	24I0210	enfermagem	\N		2026-01-20 13:40:05.125+00	2026-01-20 13:40:05.125+00
395	103	14	3	\N	2027-07-30	6	Compra/Doação	individual	active	2510824	farmacia	\N		2026-01-20 18:23:52.665+00	2026-01-20 18:23:52.665+00
381	160	42	2	\N	2026-09-30	20	Compra/Doação	individual	active	24I0210	enfermagem	\N		2026-01-20 13:40:47.62+00	2026-01-20 13:40:47.62+00
379	160	\N	2	\N	2026-09-30	0	Compra/Doação	geral	active	24I0210	farmacia	\N		2026-01-20 13:39:38.16+00	2026-01-20 13:40:47.626+00
382	76	11	1	\N	2026-07-30	1	UBS	individual	active	\N	enfermagem	\N	\N	2026-01-20 13:42:55.6+00	2026-01-20 13:42:55.6+00
384	26	11	1	\N	2028-01-30	4	Compra/Doação	individual	active	25002	enfermagem	\N		2026-01-20 13:45:08.87+00	2026-01-20 13:45:08.87+00
383	26	11	1	\N	2028-01-30	0	Compra/Doação	individual	active	25002	farmacia	\N		2026-01-20 13:44:45.523+00	2026-01-20 13:45:08.874+00
386	155	\N	1	\N	2026-05-30	2	Compra/Doação	geral	active	0025880	farmacia	\N		2026-01-20 14:05:03.541+00	2026-01-20 14:05:03.541+00
387	155	\N	1	\N	2026-08-30	11	UBS	geral	active	DS24I440	farmacia	\N		2026-01-20 14:09:32.932+00	2026-01-20 14:09:32.932+00
388	155	\N	1	\N	2026-09-30	10	UBS	geral	active	DS24J452	farmacia	\N		2026-01-20 14:11:58.724+00	2026-01-20 14:11:58.724+00
389	155	\N	1	\N	2026-04-30	1	Compra/Doação	geral	active	0025795	farmacia	\N		2026-01-20 14:12:49.853+00	2026-01-20 14:12:49.853+00
391	59	19	1	\N	2027-04-30	20	UBS	individual	active	250406	enfermagem	\N		2026-01-20 18:15:36.496+00	2026-01-20 18:15:36.496+00
390	59	19	1	\N	2027-04-30	0	UBS	individual	active	250406	farmacia	\N		2026-01-20 18:14:58.696+00	2026-01-20 18:15:36.504+00
392	103	18	3	\N	2028-03-30	36	Família	individual	active	50508074	farmacia	\N		2026-01-20 18:19:42.665+00	2026-01-20 18:19:42.665+00
398	55	24	1	\N	2026-07-30	20	Compra/Doação	individual	active	24G09V	enfermagem	\N		2026-01-20 18:45:50.209+00	2026-01-20 18:45:50.209+00
397	55	24	1	\N	2026-07-30	10	Compra/Doação	individual	active	24G09V	farmacia	\N		2026-01-20 18:45:30.05+00	2026-01-20 18:45:50.215+00
399	149	20	1	\N	2027-11-30	60	Família	individual	active	2516635	farmacia	\N		2026-01-20 18:50:18.63+00	2026-01-20 18:50:18.63+00
401	102	20	1	\N	2027-07-30	30	Família	individual	active	B25G2207	farmacia	\N		2026-01-20 18:55:44.488+00	2026-01-20 18:55:44.488+00
403	16	20	1	\N	2026-06-30	30	Família	individual	active	PD0504	farmacia	\N		2026-01-20 18:58:51.046+00	2026-01-20 18:58:51.046+00
406	125	20	1	\N	2027-12-30	30	Família	individual	active	2111415	farmacia	\N	Uso contínuo	2026-01-20 19:09:40.126+00	2026-01-20 19:09:40.126+00
407	123	20	1	\N	2026-10-30	30	Família	individual	active	EKP14448	farmacia	\N	Uso contínuo	2026-01-20 19:11:16.694+00	2026-01-20 19:11:16.694+00
409	168	8	1	\N	2026-04-30	30	Família	individual	active	3Z2601	farmacia	\N		2026-01-20 19:52:12.943+00	2026-01-20 19:52:12.943+00
354	18	2	1	\N	2027-09-30	10	UBS	individual	active	L25J065	farmacia	\N		2026-01-19 19:42:13.387+00	2026-01-28 13:26:34.626+00
366	35	\N	6	\N	2027-05-30	30	UBS	geral	active	0670/25M	farmacia	\N	0670/25M	2026-01-19 20:34:46.005+00	2026-01-28 13:37:18.653+00
358	106	19	1	\N	2026-10-30	20	UBS	individual	active		farmacia	\N	L: 50020777	2026-01-19 20:00:21.843+00	2026-01-22 18:08:40.728+00
400	80	20	1	\N	2027-12-30	20	Família	individual	active	141835	farmacia	\N		2026-01-20 18:54:44.302+00	2026-01-22 18:18:18.054+00
404	167	20	1	\N	2028-01-30	18	Família	individual	active	M502427	farmacia	\N		2026-01-20 19:07:06.386+00	2026-01-22 18:19:59.43+00
402	29	20	1	\N	2027-09-30	30	Família	individual	active	5C5802	farmacia	\N		2026-01-20 18:56:48.58+00	2026-01-22 18:21:02.426+00
355	35	2	1	\N	2027-05-30	18	UBS	individual	active		farmacia	\N	L:0670/25M	2026-01-19 19:48:36.84+00	2026-01-22 18:41:03.436+00
362	111	42	3	\N	2027-05-30	15	UBS	individual	active	L25G19J	farmacia	\N		2026-01-19 20:11:36.357+00	2026-01-23 13:38:43.817+00
405	64	20	3	\N	2028-06-30	45	Família	individual	active	50502483	farmacia	\N	Uso  contínuo	2026-01-20 19:08:19.907+00	2026-01-23 14:04:51.036+00
370	144	38	1	\N	2026-09-30	30	UBS	individual	active	1542/24M	enfermagem	\N		2026-01-20 12:44:12.499+00	2026-01-26 11:53:39.886+00
396	46	26	2	\N	2027-11-30	3	UBS	individual	active	L:5C3338	farmacia	\N	Uso contínuo	2026-01-20 18:25:20.439+00	2026-01-26 19:13:39.84+00
359	106	2	1	\N	2026-10-30	20	UBS	individual	active		farmacia	\N	L: 50020777	2026-01-19 20:03:46.756+00	2026-01-26 19:46:27.103+00
374	139	19	3	\N	2026-07-30	40	UBS	individual	active	240370	enfermagem	\N	Uso contínuo	2026-01-20 13:00:01.509+00	2026-01-27 21:18:51.88+00
350	73	2	1	\N	2026-10-30	24	UBS	individual	active	B24J2421	farmacia	\N		2026-01-19 19:29:31.427+00	2026-01-28 13:27:13.237+00
410	168	8	1	\N	2026-03-30	10	Compra/Doação	individual	active	3X7039	enfermagem	\N		2026-01-20 19:52:47.15+00	2026-01-20 19:52:47.15+00
408	168	8	1	\N	2026-03-30	0	Compra/Doação	individual	active	3X7039	farmacia	\N		2026-01-20 19:50:42.749+00	2026-01-20 19:52:47.157+00
412	113	4	1	\N	2026-11-30	14	UBS	individual	active	5002104	enfermagem	\N		2026-01-20 20:05:45.039+00	2026-01-20 20:05:45.039+00
411	113	4	1	\N	2026-11-30	16	UBS	individual	active	5002104	farmacia	\N		2026-01-20 20:05:15.699+00	2026-01-20 20:05:45.056+00
414	125	4	3	\N	2027-02-28	14	Altocusto	individual	active	50025076	enfermagem	\N		2026-01-20 20:08:22.263+00	2026-01-26 16:43:40.758+00
415	87	15	3	\N	2027-02-28	13	Compra/Doação	individual	active	\N	enfermagem	\N	\N	2026-01-20 20:14:33.801+00	2026-01-20 20:14:33.801+00
416	64	15	3	\N	2028-05-30	30	Compra/Doação	individual	active		farmacia	\N		2026-01-20 20:16:47.073+00	2026-01-20 20:16:47.073+00
417	119	15	3	\N	2027-07-30	1	UBS	individual	active	50030073	farmacia	\N		2026-01-20 20:18:00.238+00	2026-01-20 20:18:00.238+00
421	111	17	3	\N	2027-03-30	23	Altocusto	individual	active	\N	enfermagem	\N		2026-01-20 20:53:45.933+00	2026-01-20 20:55:15.149+00
424	125	24	3	\N	2026-06-30	23	Altocusto	individual	active	50016175	enfermagem	\N		2026-01-20 21:07:10.8+00	2026-01-20 21:07:10.8+00
423	125	24	3	\N	2026-06-30	87	Altocusto	individual	active	50016175	farmacia	\N		2026-01-20 21:06:34.549+00	2026-01-20 21:07:10.807+00
426	64	29	3	\N	2027-08-30	14	Compra/Doação	individual	active	\N	enfermagem	\N	\N	2026-01-20 21:15:14.564+00	2026-01-20 21:15:14.564+00
428	51	29	3	\N	2027-07-30	22	UBS	individual	active		enfermagem	\N	Psicotrópico	2026-01-20 21:21:25.261+00	2026-01-20 21:21:25.261+00
303	51	29	3	\N	2027-07-30	38	UBS	individual	active		farmacia	\N	Psicotrópico	2026-01-17 14:31:50.893+00	2026-01-20 21:21:25.269+00
430	100	34	3	\N	2027-01-30	10	Compra/Doação	individual	active	PP0403	enfermagem	\N		2026-01-20 21:26:12.463+00	2026-01-20 21:26:12.463+00
429	100	34	3	\N	2027-01-30	0	Compra/Doação	individual	active	PP0403	farmacia	\N		2026-01-20 21:25:28.699+00	2026-01-20 21:26:12.469+00
431	100	34	3	\N	2027-10-30	10	Compra/Doação	individual	active	\N	enfermagem	\N	\N	2026-01-20 21:26:47.761+00	2026-01-20 21:26:47.761+00
433	125	35	3	\N	2027-01-30	21	Altocusto	individual	active	50023328A	enfermagem	\N		2026-01-20 21:33:13.25+00	2026-01-20 21:33:13.25+00
422	140	19	3	\N	2027-10-30	24	UBS	individual	active	50020767	enfermagem	\N	+ 1 cp do anterior	2026-01-20 20:57:36.353+00	2026-01-27 21:20:13.271+00
435	100	35	3	\N	2027-01-30	16	Compra/Doação	individual	active	PP0403	enfermagem	\N	\N	2026-01-20 21:37:00.906+00	2026-01-20 21:37:00.906+00
434	100	35	3	\N	2027-01-30	20	Compra/Doação	individual	active	PP0403	farmacia	\N	\N	2026-01-20 21:36:19.56+00	2026-01-20 21:37:00.913+00
438	156	40	3	\N	2027-09-30	10	Família	individual	active	5A5309	farmacia	\N		2026-01-20 21:45:32.553+00	2026-01-20 21:45:32.553+00
439	156	40	3	\N	2026-07-30	13	Família	individual	active	50016416	enfermagem	\N		2026-01-20 21:45:58.121+00	2026-01-20 21:45:58.121+00
437	156	40	3	\N	2026-07-30	10	Família	individual	active	50016416	farmacia	\N		2026-01-20 21:44:26.848+00	2026-01-20 21:45:58.125+00
441	40	27	1	\N	2026-11-30	15	Compra/Doação	individual	active	$N8841	enfermagem	\N		2026-01-21 13:06:06.015+00	2026-01-21 13:06:06.015+00
440	40	27	1	\N	2026-11-30	0	Compra/Doação	individual	active	$N8841	farmacia	\N		2026-01-21 13:04:59.747+00	2026-01-21 13:06:06.03+00
443	169	39	1	\N	2027-04-30	15	Compra/Doação	individual	active		enfermagem	\N		2026-01-21 13:16:32.631+00	2026-01-21 13:16:32.631+00
442	169	39	1	\N	2027-04-30	10	Compra/Doação	individual	active		farmacia	\N		2026-01-21 13:15:58.241+00	2026-01-21 13:16:32.644+00
444	73	16	1	\N	2026-10-30	12	Compra/Doação	individual	active	B24J2421	farmacia	\N		2026-01-21 13:31:14.896+00	2026-01-21 13:31:14.896+00
446	37	6	1	\N	2027-03-30	28	Família	individual	active	\N	enfermagem	\N	\N	2026-01-21 15:08:16.869+00	2026-01-21 15:08:16.869+00
448	37	6	1	\N	2027-10-30	20	Compra/Doação	individual	active	502203	enfermagem	\N		2026-01-21 15:11:38.939+00	2026-01-21 15:11:38.939+00
447	37	6	1	\N	2027-10-30	10	Compra/Doação	individual	active	502203	farmacia	\N		2026-01-21 15:09:38.547+00	2026-01-21 15:11:38.98+00
449	115	8	1	\N	2027-01-30	2	UBS	individual	active	\N	enfermagem	\N	\N	2026-01-21 16:30:51.931+00	2026-01-21 16:30:51.931+00
450	46	26	2	\N	2027-01-30	1	UBS	individual	active	5C3338	enfermagem	\N	Uso contínuo	2026-01-21 16:52:06.762+00	2026-01-21 16:52:06.762+00
451	171	38	1	\N	2027-07-30	10	UBS	individual	active	0957/25M	farmacia	\N		2026-01-21 17:03:33.153+00	2026-01-21 17:03:33.153+00
453	46	38	1	\N	2027-11-30	1	UBS	individual	active	5C3338	enfermagem	\N		2026-01-21 17:18:55.521+00	2026-01-21 17:18:55.521+00
452	46	38	1	\N	2027-11-30	0	UBS	individual	active	5C3338	farmacia	\N		2026-01-21 17:18:34.722+00	2026-01-21 17:18:55.533+00
454	26	11	1	\N	2028-05-30	4	UBS	individual	active	25086	farmacia	\N		2026-01-21 17:58:25.45+00	2026-01-21 17:58:25.45+00
455	166	11	7	\N	2026-09-30	28	UBS	individual	active	B24J0766	farmacia	\N		2026-01-21 18:02:12.344+00	2026-01-21 18:02:12.344+00
458	160	42	1	\N	2027-10-30	60	UBS	individual	active	1740214	farmacia	\N		2026-01-21 18:22:08.128+00	2026-01-21 18:22:08.128+00
460	172	26	1	\N	2027-11-30	55	UBS	individual	active	DFF8251A	enfermagem	\N		2026-01-21 18:26:10.133+00	2026-01-21 18:26:10.133+00
457	172	26	1	\N	2027-11-30	125	UBS	individual	active	DFF8251A	farmacia	\N		2026-01-21 18:15:38.806+00	2026-01-21 18:26:10.14+00
461	172	19	3	\N	2027-11-30	55	UBS	individual	active	DFF8251A	enfermagem	\N		2026-01-21 18:26:21.686+00	2026-01-21 18:26:21.686+00
459	172	19	3	\N	2027-11-30	125	UBS	individual	active	DFF8251A	farmacia	\N		2026-01-21 18:25:47.497+00	2026-01-21 18:26:21.692+00
462	160	11	1	\N	2027-10-30	30	UBS	individual	active	IT40214	farmacia	\N		2026-01-21 18:40:07.543+00	2026-01-21 18:40:07.543+00
464	31	25	3	\N	2027-09-30	1	UBS	individual	active	B25J0093	farmacia	\N		2026-01-21 18:44:39.617+00	2026-01-21 18:44:39.617+00
465	91	36	3	\N	2028-06-30	60	Família	individual	active	BLGM24007	farmacia	\N		2026-01-21 19:46:04.75+00	2026-01-21 19:46:04.75+00
466	91	36	3	\N	2028-06-30	180	Família	individual	active	BLGM24006	farmacia	\N		2026-01-21 19:47:37.503+00	2026-01-21 19:47:37.503+00
469	173	21	5	\N	2027-07-30	1	Compra/Doação	individual	active	50030366	enfermagem	\N	Devido a urgência, usamos o do abrigo e depois reposto por família.	2026-01-21 20:00:26.772+00	2026-01-21 20:00:26.772+00
468	173	\N	5	\N	2027-07-30	1	Compra/Doação	geral	active	50030366	farmacia	\N	Devido a urgência, usamos o do abrigo e depois reposto por família.	2026-01-21 19:59:58.598+00	2026-01-21 20:00:26.78+00
467	89	36	3	\N	2027-08-30	90	Família	individual	active	:L25H2B8	farmacia	\N		2026-01-21 19:51:12.673+00	2026-01-21 20:02:36.07+00
470	89	36	3	\N	2027-08-30	60	Família	individual	active	L25H66X	farmacia	\N		2026-01-21 20:04:47.993+00	2026-01-21 20:04:47.993+00
472	125	36	3	\N	2026-10-30	60	Família	individual	active	50018813	farmacia	\N		2026-01-21 20:13:06.927+00	2026-01-21 20:13:06.927+00
471	125	36	3	\N	2026-10-30	100	Família	individual	active	2400003	farmacia	\N		2026-01-21 20:11:25.243+00	2026-01-23 13:24:30.307+00
419	125	16	3	\N	2026-09-30	30	Altocusto	individual	active	5000188811	enfermagem	\N	PSICOTRÓPICOS	2026-01-20 20:50:51.847+00	2026-01-26 11:59:20.579+00
425	140	29	3	\N	2028-01-30	20	UBS	individual	active	50023281	enfermagem	\N	psicotrópico	2026-01-20 21:13:10.832+00	2026-01-26 12:03:48.23+00
456	111	34	3	\N	2027-06-30	30	UBS	individual	active	25G19J	farmacia	\N		2026-01-21 18:05:21.811+00	2026-01-26 12:08:35.442+00
413	125	4	3	\N	2027-02-28	16	Altocusto	individual	active	50025076	farmacia	\N		2026-01-20 20:07:34.53+00	2026-01-26 16:42:57.692+00
432	125	35	3	\N	2027-01-30	88	Altocusto	individual	active	50023328A	farmacia	\N		2026-01-20 21:30:26.49+00	2026-01-26 17:16:42.875+00
445	73	2	1	\N	2026-10-30	36	UBS	individual	active	B24J2421	enfermagem	\N		2026-01-21 13:33:21.67+00	2026-01-28 13:27:13.212+00
463	32	24	3	\N	2027-07-30	0	UBS	individual	active	2517054	farmacia	\N		2026-01-21 18:42:43.498+00	2026-01-28 21:46:44.732+00
420	111	17	3	\N	2027-03-30	25	Altocusto	individual	active	25C45P	farmacia	\N		2026-01-20 20:53:17.024+00	2026-01-29 12:32:18.627+00
474	174	36	3	\N	2026-11-30	320	Família	individual	active	00053200	farmacia	\N		2026-01-21 20:26:04.88+00	2026-01-21 20:26:04.88+00
477	134	36	3	\N	2027-03-30	60	Família	individual	active	LFKP03695	farmacia	\N		2026-01-21 20:31:58.019+00	2026-01-21 20:31:58.019+00
480	64	36	3	\N	2027-05-30	10	Família	individual	active	L25E935	farmacia	\N		2026-01-21 20:37:50.329+00	2026-01-23 13:20:51.029+00
481	155	36	1	\N	2026-04-30	1	Família	individual	active	0025795	farmacia	\N		2026-01-21 20:45:03.164+00	2026-01-21 20:45:03.164+00
482	176	36	1	\N	2026-10-30	1	Família	individual	active	2425224	farmacia	\N		2026-01-21 20:46:04.68+00	2026-01-21 20:46:04.68+00
483	175	36	3	\N	2026-08-30	1	Família	individual	active	4784D	farmacia	\N		2026-01-21 20:47:14.03+00	2026-01-21 20:47:14.03+00
484	52	8	4	\N	2026-04-30	1	UBS	individual	active	\N	enfermagem	\N	\N	2026-01-21 21:00:58.114+00	2026-01-21 21:00:58.114+00
485	48	4	2	\N	2026-11-20	2	UBS	individual	active	\N	enfermagem	\N	\N	2026-01-21 21:06:26.149+00	2026-01-21 21:06:26.149+00
486	29	18	1	\N	2027-05-30	15	UBS	individual	active	\N	enfermagem	\N	\N	2026-01-21 21:07:40.803+00	2026-01-21 21:07:40.803+00
487	55	18	1	\N	2027-01-30	20	Família	individual	active	258798	enfermagem	\N		2026-01-21 21:08:12.322+00	2026-01-21 21:08:12.322+00
488	95	16	1	\N	2027-10-30	15	Família	individual	active	2510845	enfermagem	\N		2026-01-22 13:20:40.201+00	2026-01-22 13:20:40.201+00
489	29	17	1	\N	2027-06-30	15	Altocusto	individual	active		enfermagem	\N	Uso contínuo	2026-01-22 13:21:44.683+00	2026-01-22 13:21:44.683+00
490	83	18	1	\N	2027-08-30	15	Família	individual	active	\N	enfermagem	\N	\N	2026-01-22 13:23:26.191+00	2026-01-22 13:23:26.191+00
491	38	23	1	\N	2027-02-21	15	Família	individual	active	\N	enfermagem	\N	\N	2026-01-22 13:23:53.115+00	2026-01-22 13:23:53.115+00
492	149	39	1	\N	2027-05-30	30	UBS	individual	active		enfermagem	\N	Uso contínuo	2026-01-22 13:24:24.517+00	2026-01-22 13:24:24.517+00
495	80	24	1	\N	2027-09-30	10	Compra/Doação	individual	active	120569	enfermagem	\N		2026-01-22 15:19:41.818+00	2026-01-22 15:19:41.818+00
496	44	29	1	\N	2027-01-30	20	UBS	individual	active	17139	enfermagem	\N		2026-01-22 15:20:00.723+00	2026-01-22 15:20:00.723+00
497	83	39	1	\N	2027-04-30	15	Altocusto	individual	active		enfermagem	\N		2026-01-22 15:21:48.744+00	2026-01-22 15:21:48.744+00
498	49	39	1	\N	2026-10-30	14	Compra/Doação	individual	active		enfermagem	\N		2026-01-22 15:22:55.852+00	2026-01-22 15:22:55.852+00
499	55	17	1	\N	2026-07-30	14	UBS	individual	active	24G09V	farmacia	\N		2026-01-22 17:30:23.834+00	2026-01-22 17:32:09.375+00
500	55	17	1	\N	2026-07-30	12	UBS	individual	active	24G09V	enfermagem	\N	6 já tinha	2026-01-22 17:32:09.368+00	2026-01-22 17:34:22.029+00
501	24	17	1	\N	2027-09-30	16	Altocusto	individual	active		enfermagem	\N	6 já tinha no saquinho.	2026-01-22 17:36:39.14+00	2026-01-22 17:36:39.14+00
502	28	17	1	\N	2026-07-30	20	UBS	individual	active		farmacia	\N		2026-01-22 17:39:39.832+00	2026-01-22 17:39:39.832+00
505	80	18	1	\N	2027-06-30	15	Altocusto	individual	active	WL0108	enfermagem	\N		2026-01-22 17:49:07.599+00	2026-01-22 17:49:07.599+00
523	40	23	1	\N	2027-02-28	25	Família	individual	active	\N	enfermagem	\N	1 cp a mais no saquinho.	2026-01-22 18:26:01.325+00	2026-01-26 11:51:23.618+00
507	28	18	1	\N	2027-05-30	30	Família	individual	active	LFRA027641	enfermagem	\N		2026-01-22 18:00:25.753+00	2026-01-22 18:00:25.753+00
508	35	18	1	\N	2027-05-30	30	Família	individual	active	0670/25M	enfermagem	\N		2026-01-22 18:01:18.331+00	2026-01-22 18:01:18.331+00
509	151	18	1	\N	2027-01-30	15	Família	individual	active	BR180114	enfermagem	\N		2026-01-22 18:01:56.518+00	2026-01-22 18:01:56.518+00
510	149	18	1	\N	2027-05-30	20	Família	individual	active	2506377	farmacia	\N		2026-01-22 18:04:55.955+00	2026-01-22 18:04:55.955+00
511	43	18	1	\N	2028-11-30	15	Família	individual	active	505827	enfermagem	\N		2026-01-22 18:06:36.798+00	2026-01-22 18:06:36.798+00
512	24	19	1	\N	2027-09-30	10	Farmácia Popular	individual	active	\N	enfermagem	\N	\N	2026-01-22 18:08:09.627+00	2026-01-22 18:08:09.627+00
513	106	19	1	\N	2026-10-30	10	UBS	individual	active		enfermagem	\N	L: 50020777	2026-01-22 18:08:40.722+00	2026-01-22 18:08:40.722+00
514	55	26	1	\N	2027-01-30	10	UBS	individual	active	\N	enfermagem	\N	\N	2026-01-22 18:10:07.185+00	2026-01-22 18:10:07.185+00
515	95	26	1	\N	2026-11-30	10	Compra/Doação	individual	active	\N	enfermagem	\N	e tem mais 4 cps no saquinho de transferência.	2026-01-22 18:12:50.199+00	2026-01-22 18:12:50.199+00
516	177	26	1	\N	2027-11-30	30	Compra/Doação	individual	active	62957	farmacia	\N		2026-01-22 18:16:27.879+00	2026-01-22 18:16:27.879+00
517	80	20	1	\N	2027-12-30	10	Família	individual	active	141835	enfermagem	\N	3 cps a mais no saquinho	2026-01-22 18:18:18.045+00	2026-01-22 18:18:18.045+00
518	167	20	1	\N	2028-01-30	12	Família	individual	active	M502427	enfermagem	\N	3 cps a mais no saquinho	2026-01-22 18:19:59.424+00	2026-01-22 18:19:59.424+00
519	29	20	1	\N	2027-09-30	30	Família	individual	active	5C5802	enfermagem	\N	6 cps a mais no saquinho	2026-01-22 18:21:02.419+00	2026-01-22 18:21:02.419+00
520	102	25	1	\N	2027-08-30	15	Família	individual	active	\N	enfermagem	\N	1 cp a mais no saquinho.	2026-01-22 18:23:10.265+00	2026-01-22 18:23:10.265+00
521	28	22	1	\N	2027-07-30	15	Família	individual	active	\N	enfermagem	\N	3 cps a mais	2026-01-22 18:24:13.565+00	2026-01-22 18:24:13.565+00
522	26	23	1	\N	2027-08-30	4	Família	individual	active	\N	enfermagem	\N	1 cp a mais	2026-01-22 18:25:07.164+00	2026-01-22 18:25:07.164+00
525	44	24	1	\N	2027-01-30	10	UBS	individual	active		enfermagem	\N	4 cps a mais no saquinho	2026-01-22 18:28:43.632+00	2026-01-22 18:28:43.632+00
527	178	35	1	\N	2026-07-12	60	Família	individual	active	309968	enfermagem	\N		2026-01-22 18:36:42.149+00	2026-01-22 18:36:42.149+00
528	35	28	1	\N	2027-05-30	28	UBS	individual	active		enfermagem	\N	L:0670/25M	2026-01-22 18:39:00.456+00	2026-01-22 18:39:00.456+00
530	35	19	1	\N	2027-05-30	28	UBS	individual	active		enfermagem	\N	L:0670/25M	2026-01-22 18:39:38.929+00	2026-01-22 18:39:38.929+00
529	35	2	1	\N	2027-05-30	38	UBS	individual	active		enfermagem	\N	L:0670/25M	2026-01-22 18:39:19.658+00	2026-01-22 18:41:03.432+00
532	179	1	1	\N	2027-04-30	20	Família	individual	active	24155	enfermagem	\N		2026-01-22 19:47:13.832+00	2026-01-22 19:47:13.832+00
534	55	29	1	\N	2026-07-30	10	UBS	individual	active	24G09V	enfermagem	\N	5 cps a mais no saquinho	2026-01-22 19:50:17.63+00	2026-01-22 19:50:17.63+00
533	55	29	1	\N	2026-07-30	30	UBS	individual	active	24G09V	farmacia	\N	\N	2026-01-22 19:49:21.708+00	2026-01-22 19:50:17.652+00
536	24	29	1	\N	2026-05-30	15	Farmácia Popular	individual	active	BR18000	enfermagem	\N	7 cps a mais no saquinho	2026-01-22 19:57:37.754+00	2026-01-22 19:57:37.754+00
535	24	29	1	\N	2026-05-30	30	Farmácia Popular	individual	active	BR18000	farmacia	\N		2026-01-22 19:55:44.775+00	2026-01-22 19:57:37.762+00
538	180	29	1	\N	2027-04-30	20	UBS	individual	active	2503126	enfermagem	\N	4 cps a mais no saquinho	2026-01-22 20:07:44.726+00	2026-01-22 20:07:44.726+00
540	49	29	1	\N	2027-05-30	10	UBS	individual	active	FJA25003A	enfermagem	\N	3 cps a mais no saquinho	2026-01-22 20:11:08.763+00	2026-01-22 20:11:08.763+00
539	49	29	1	\N	2027-05-30	10	UBS	individual	active	FJA25003A	farmacia	\N	\N	2026-01-22 20:10:21.354+00	2026-01-22 20:11:08.776+00
542	84	29	1	\N	2026-04-30	10	Compra/Doação	individual	active	0424001	enfermagem	\N	7 cps a mais no saquinho	2026-01-22 20:15:01.008+00	2026-01-22 20:15:01.008+00
479	32	36	3	\N	2027-06-30	30	Família	individual	active	LFKP 07711	enfermagem	\N		2026-01-21 20:36:21.342+00	2026-01-23 13:14:07.706+00
476	32	36	3	\N	2027-06-30	30	Família	individual	active	LFKP 07711	farmacia	\N		2026-01-21 20:29:18.047+00	2026-01-23 13:14:07.719+00
478	157	36	3	\N	2027-07-30	14	Família	individual	active	250715	farmacia	\N		2026-01-21 20:35:08.91+00	2026-01-23 13:22:31.097+00
504	80	18	1	\N	2027-06-30	80	Altocusto	individual	active	WL0108	farmacia	\N		2026-01-22 17:47:53.57+00	2026-01-23 19:51:05.261+00
473	125	36	3	\N	2026-10-21	60	Família	individual	active	50025076	farmacia	\N		2026-01-21 20:14:04.321+00	2026-01-28 13:25:53.076+00
545	24	35	1	\N	2026-09-30	45	Família	individual	active		farmacia	\N		2026-01-22 20:24:41.91+00	2026-01-22 20:24:41.91+00
546	80	35	1	\N	2027-09-30	10	Família	individual	active	120835	enfermagem	\N	5 cps a mais no saquinho	2026-01-22 20:28:56.467+00	2026-01-22 20:28:56.467+00
547	27	35	1	\N	2028-09-30	15	Família	individual	active	BR183391	enfermagem	\N	2 cps a mais no saquinho	2026-01-22 20:29:57.576+00	2026-01-22 20:29:57.576+00
548	74	35	1	\N	2027-01-30	15	Família	individual	active	M50772	enfermagem	\N	1 cp a mais no saquinho	2026-01-22 20:31:09.009+00	2026-01-22 20:31:09.009+00
544	74	35	1	\N	2027-01-30	15	Família	individual	active	M50772	farmacia	\N		2026-01-22 20:21:50.816+00	2026-01-22 20:31:09.02+00
549	39	35	1	\N	2027-10-30	14	Família	individual	active	\N	enfermagem	\N	2 cps a mais no saquinho	2026-01-22 20:32:00.309+00	2026-01-22 20:32:00.309+00
550	129	35	1	\N	2026-03-30	9	Compra/Doação	individual	active	24040014	enfermagem	\N	2 a mais no saquinho	2026-01-22 20:32:41.142+00	2026-01-22 20:32:41.142+00
543	129	35	1	\N	2026-03-30	18	Compra/Doação	individual	active	24040014	farmacia	\N		2026-01-22 20:18:04.666+00	2026-01-22 20:32:41.147+00
551	102	38	1	\N	2027-05-30	15	Compra/Doação	individual	active	\N	enfermagem	\N	4 a mais no saquinho.	2026-01-22 20:33:31.63+00	2026-01-22 20:33:31.63+00
552	143	39	1	\N	2027-10-30	30	UBS	individual	active		enfermagem	\N	5 a mais no saquinho	2026-01-22 20:34:20.533+00	2026-01-22 20:34:20.533+00
553	24	39	1	\N	2027-04-30	20	UBS	individual	active		enfermagem	\N	4 a mais no saquinho	2026-01-22 20:34:47.198+00	2026-01-22 20:34:47.198+00
554	17	40	1	\N	2027-01-30	10	Família	individual	active	17135Y	enfermagem	\N	2 a mais no saquinho	2026-01-22 20:35:19.033+00	2026-01-22 20:35:19.033+00
556	64	14	3	\N	2026-08-30	30	Família	individual	active	50701426	farmacia	\N		2026-01-22 20:48:48.347+00	2026-01-22 20:48:48.347+00
557	139	19	3	\N	2026-07-30	60	UBS	individual	active	240368	farmacia	\N		2026-01-22 21:22:28.485+00	2026-01-22 21:22:28.485+00
559	34	13	1	\N	2027-06-30	6	UBS	individual	active	0784/25	farmacia	\N		2026-01-22 21:31:07.882+00	2026-01-22 21:31:07.882+00
561	54	13	1	\N	2026-10-30	20	UBS	individual	active	1577/24M	farmacia	\N		2026-01-22 21:34:06.961+00	2026-01-22 21:34:06.961+00
562	143	38	1	\N	2027-06-30	30	UBS	individual	active	4W4964	farmacia	\N		2026-01-22 21:37:12.012+00	2026-01-22 21:37:12.012+00
563	144	38	1	\N	2026-09-30	90	UBS	individual	active	1486/24M	farmacia	\N		2026-01-22 21:41:07.27+00	2026-01-22 21:41:07.27+00
565	31	7	3	\N	2027-09-30	3	UBS	individual	active	B25J0093	farmacia	\N		2026-01-22 21:50:05.044+00	2026-01-22 21:50:05.044+00
566	83	39	1	\N	2027-09-30	30	UBS	individual	active	3026002	farmacia	\N		2026-01-22 21:52:39.054+00	2026-01-22 21:52:39.054+00
567	17	29	1	\N	2027-01-30	30	UBS	individual	active		farmacia	\N		2026-01-22 21:55:45.133+00	2026-01-22 21:55:45.133+00
568	16	15	1	\N	2026-08-30	30	UBS	individual	active	PD0504	farmacia	\N		2026-01-22 22:00:09.94+00	2026-01-22 22:00:09.94+00
569	17	35	1	\N	2027-01-30	30	UBS	individual	active	17192	farmacia	\N		2026-01-22 22:02:32.805+00	2026-01-22 22:02:32.805+00
570	55	3	1	\N	2027-01-30	60	UBS	individual	active	258798	farmacia	\N		2026-01-22 22:07:56.289+00	2026-01-22 22:07:56.289+00
571	36	3	1	\N	2027-06-30	30	UBS	individual	active	2515602	farmacia	\N		2026-01-22 22:10:06.496+00	2026-01-22 22:10:06.496+00
572	74	29	1	\N	2026-12-30	25	UBS	individual	active	BR176466	farmacia	\N		2026-01-22 22:13:37.609+00	2026-01-22 22:13:37.609+00
573	37	6	1	\N	2027-03-30	60	UBS	individual	active	4R5214	farmacia	\N		2026-01-22 22:15:29.732+00	2026-01-22 22:15:29.732+00
574	16	6	1	\N	2026-08-30	30	UBS	individual	active	PD0504	farmacia	\N		2026-01-22 22:17:14.582+00	2026-01-22 22:17:14.582+00
575	59	6	1	\N	2027-04-30	30	UBS	individual	active	260405	farmacia	\N		2026-01-22 22:19:33.967+00	2026-01-22 22:19:33.967+00
560	36	13	1	\N	2027-06-30	90	UBS	individual	active	2515602	farmacia	\N		2026-01-22 21:32:22.947+00	2026-01-22 22:22:09.666+00
576	45	12	1	\N	2026-09-30	20	Família	individual	active	\N	enfermagem	\N	\N	2026-01-23 11:48:47.644+00	2026-01-23 11:48:47.644+00
577	58	1	1	\N	2027-09-30	20	Família	individual	active	\N	enfermagem	\N	\N	2026-01-23 11:49:44.38+00	2026-01-23 11:49:44.38+00
578	113	2	3	\N	2026-11-30	20	UBS	individual	active	\N	enfermagem	\N	\N	2026-01-23 11:50:33.458+00	2026-01-23 11:50:33.458+00
579	120	20	3	\N	2027-07-30	2	Família	individual	active	0952/25	farmacia	\N		2026-01-23 12:02:19.841+00	2026-01-23 12:02:19.841+00
436	91	36	1	\N	2028-03-30	20	Família	individual	active	BLGM24003	enfermagem	\N	Psicotrópico - uso contínuo	2026-01-20 21:40:29.046+00	2026-01-23 13:17:44.068+00
581	64	36	3	\N	2027-05-30	20	Família	individual	active	L25E935	enfermagem	\N	há mais 3 cps no saquinho lote L25E935. 23 no total.	2026-01-23 13:20:51.022+00	2026-01-23 13:20:51.022+00
582	157	36	3	\N	2027-07-30	14	Família	individual	active	250715	enfermagem	\N	Há 6 cps no saquinho. 20 no total.	2026-01-23 13:22:31.076+00	2026-01-23 13:22:31.076+00
583	125	36	3	\N	2026-10-30	20	Família	individual	active	2400003	enfermagem	\N	há mais 4 cps no saquinho. 24 no total.	2026-01-23 13:24:30.301+00	2026-01-23 13:24:30.301+00
584	101	38	3	\N	2027-07-30	1	Compra/Doação	individual	active	\N	enfermagem	\N	L:2511493	2026-01-23 13:26:21.286+00	2026-01-23 13:26:21.286+00
585	125	38	3	\N	2027-02-28	20	Altocusto	individual	active	50025076	enfermagem	\N	há mais 4 cps no saquinho L:50016175 / 10 L:50015434 / L:50016392	2026-01-23 13:29:19.38+00	2026-01-23 13:29:19.38+00
586	64	40	1	\N	2027-05-30	10	Família	individual	active	25F27T	enfermagem	\N	há mais 8 cps no saquinho. 18 no total.	2026-01-23 13:32:45.659+00	2026-01-23 13:32:45.659+00
588	111	40	3	\N	2026-10-30	10	Família	individual	active	952541	enfermagem	\N	há mais 2 cps no saquinho L:25C45P. Total de 12 cps	2026-01-23 13:35:55.746+00	2026-01-23 13:35:55.746+00
587	111	40	3	\N	2026-10-30	10	Família	individual	active	952541	farmacia	\N	\N	2026-01-23 13:34:25.018+00	2026-01-23 13:35:55.759+00
589	111	42	3	\N	2027-05-30	15	UBS	individual	active	L25G19J	enfermagem	\N	há mais 7 cps no saquinho L:25C92W. Total de 22 cps.	2026-01-23 13:38:43.809+00	2026-01-23 13:38:43.809+00
590	139	22	3	\N	2026-07-30	20	UBS	individual	active	240368	enfermagem	\N	há mais 2 cps no saquinho L:LERA0451	2026-01-23 13:41:31.875+00	2026-01-23 13:41:31.875+00
558	139	22	3	\N	2026-07-30	40	UBS	individual	active	240368	farmacia	\N		2026-01-22 21:24:33.627+00	2026-01-23 13:41:31.882+00
591	111	13	3	\N	2027-06-30	15	UBS	individual	active	\N	enfermagem	\N	L:25G19J há 5 cps a mais no saquinho, total de3 20.	2026-01-23 13:53:20.075+00	2026-01-23 13:53:20.075+00
592	71	14	3	\N	2027-10-30	10	Compra/Doação	individual	active	C2416778	enfermagem	\N	há mais 2 cps no saquinho, total de 12.	2026-01-23 13:54:44.364+00	2026-01-23 13:54:44.364+00
593	103	14	3	\N	2027-10-30	12	Família	individual	active	5D0211	enfermagem	\N	há mais 2 cps no saquinho L:2510824	2026-01-23 13:55:45.876+00	2026-01-23 13:55:45.876+00
555	103	14	3	\N	2027-10-30	24	Família	individual	active	5D0211	farmacia	\N		2026-01-22 20:47:40.13+00	2026-01-23 13:55:45.887+00
594	134	18	1	\N	2027-03-30	10	Família	individual	active	LFK06420	enfermagem	\N	há mais 1 cp no saquinho, total de 11 cps.	2026-01-23 13:58:03.277+00	2026-01-23 13:58:03.277+00
595	89	19	3	\N	2027-08-30	15	Compra/Doação	individual	active	50300038	enfermagem	\N	há mais 4 cps no saquinho L:BLGH24005	2026-01-23 14:01:11.572+00	2026-01-23 14:01:11.572+00
596	64	20	3	\N	2028-06-30	15	Família	individual	active	50502483	enfermagem	\N	há mais 5 cps no saquinho L:50400733, total de 20 cps.	2026-01-23 14:04:51.026+00	2026-01-23 14:04:51.026+00
599	35	12	1	\N	2026-10-30	17	Família	individual	active	1686/24M	farmacia	\N		2026-01-23 14:33:49.289+00	2026-01-23 14:33:49.289+00
601	28	12	1	\N	2026-11-30	30	Família	individual	active	B24L0279	farmacia	\N		2026-01-23 14:37:04.264+00	2026-01-23 14:37:04.264+00
564	110	2	3	\N	2027-08-30	3	UBS	individual	active	25H837	farmacia	\N		2026-01-22 21:46:35.005+00	2026-01-26 13:52:40.574+00
580	95	20	1	\N	2027-05-30	20	Família	individual	active	42901016	farmacia	\N		2026-01-23 12:07:18.66+00	2026-01-27 12:10:15.708+00
602	28	12	1	\N	2027-05-30	60	Família	individual	active	FRA02530	farmacia	\N		2026-01-23 14:38:11.506+00	2026-01-23 14:38:11.506+00
603	181	12	1	\N	2026-03-30	60	Família	individual	active	2CV95RX5GAWR2	enfermagem	\N	1 cx com 620 cps	2026-01-23 14:45:25.405+00	2026-01-23 14:45:25.405+00
604	155	12	1	\N	2026-05-30	1	Família	individual	active	DS24F286	enfermagem	\N		2026-01-23 14:45:34.944+00	2026-01-23 14:45:34.944+00
605	71	25	3	\N	2028-04-30	10	Família	individual	active	\N	enfermagem	\N	há mais 2 cps no saquinho, total de 12 cps.	2026-01-23 16:49:15.398+00	2026-01-23 16:49:15.398+00
606	123	25	3	\N	2026-04-30	30	Altocusto	individual	active	50022743	enfermagem	\N	há mais 5 cps no saquinho.	2026-01-23 16:51:47.503+00	2026-01-23 16:51:47.503+00
608	58	26	1	\N	2027-09-30	20	Compra/Doação	individual	active	1034378	enfermagem	\N	emprestado do Waldemar Viana.	2026-01-23 16:56:35.579+00	2026-01-23 16:56:35.579+00
609	22	26	1	\N	2027-06-30	1	Farmácia Popular	individual	active	\N	enfermagem	\N	L:07643331	2026-01-23 16:58:14.368+00	2026-01-23 16:58:14.368+00
614	110	13	4	\N	2027-08-30	2	UBS	individual	active	\N	enfermagem	\N	para geral	2026-01-23 18:27:23.511+00	2026-01-23 18:27:23.511+00
616	125	24	3	\N	2027-02-28	60	Altocusto	individual	active	50025076	farmacia	\N		2026-01-23 18:40:46.575+00	2026-01-23 18:40:46.575+00
619	125	4	3	\N	2026-10-30	90	Altocusto	individual	active	24100007	farmacia	\N		2026-01-23 18:46:35.543+00	2026-01-23 18:46:35.543+00
620	183	25	3	\N	2027-04-30	28	Altocusto	individual	active	250466V	farmacia	\N		2026-01-23 18:50:42.597+00	2026-01-23 18:50:42.597+00
621	123	25	3	\N	2027-03-30	30	Altocusto	individual	active	50025322	farmacia	\N		2026-01-23 18:52:45.77+00	2026-01-23 18:52:45.77+00
623	125	25	3	\N	2026-10-30	30	Altocusto	individual	active	24100007	farmacia	\N		2026-01-23 18:54:40.929+00	2026-01-23 18:54:40.929+00
625	123	3	3	\N	2027-03-30	120	Altocusto	individual	active	50026239	farmacia	\N		2026-01-23 18:59:27.386+00	2026-01-23 18:59:27.386+00
627	138	35	3	\N	2027-04-30	90	Altocusto	individual	active	50026937	farmacia	\N		2026-01-23 19:04:56.017+00	2026-01-23 19:04:56.017+00
628	158	35	3	\N	2026-10-30	28	Altocusto	individual	active	250216	farmacia	\N	\N	2026-01-23 19:08:01.122+00	2026-01-23 19:08:01.122+00
629	126	35	3	\N	2027-01-30	30	Altocusto	individual	active	50023334	farmacia	\N		2026-01-23 19:10:03.365+00	2026-01-23 19:10:03.365+00
633	184	11	1	\N	2027-08-30	6	Compra/Doação	individual	active	4Y5971	farmacia	\N		2026-01-23 19:21:40.319+00	2026-01-23 19:21:40.319+00
634	80	29	1	\N	2027-06-30	30	Altocusto	individual	active	WL0108	farmacia	\N		2026-01-23 19:39:48.989+00	2026-01-23 19:39:48.989+00
635	138	29	3	\N	2027-04-30	60	Altocusto	individual	active	50026937	farmacia	\N		2026-01-23 19:41:14.973+00	2026-01-23 19:41:14.973+00
637	24	29	1	\N	2027-10-30	90	Farmácia Popular	individual	active	25K845	farmacia	\N		2026-01-23 20:28:56.245+00	2026-01-23 20:28:56.245+00
638	29	29	1	\N	2027-06-30	60	Farmácia Popular	individual	active	B25F1215	farmacia	\N		2026-01-23 20:31:27.563+00	2026-01-23 20:31:27.563+00
639	28	29	1	\N	2027-07-30	30	Farmácia Popular	individual	active	0B1562	farmacia	\N		2026-01-23 20:32:56.093+00	2026-01-23 20:32:56.093+00
640	30	29	1	\N	2028-05-30	30	Farmácia Popular	individual	active	E0341E2	farmacia	\N		2026-01-23 20:37:25.757+00	2026-01-23 20:37:25.757+00
641	26	20	1	\N	2027-07-30	4	Farmácia Popular	individual	active	4X0901	farmacia	\N		2026-01-23 20:41:19.096+00	2026-01-23 20:41:19.096+00
642	24	42	1	\N	2027-09-30	30	Farmácia Popular	individual	active	25I53S	farmacia	\N		2026-01-23 20:43:58.97+00	2026-01-23 20:43:58.97+00
643	143	42	1	\N	2026-09-30	30	Farmácia Popular	individual	active	4K1826	farmacia	\N		2026-01-23 20:45:09.288+00	2026-01-23 20:45:09.288+00
644	24	9	1	\N	2027-10-30	30	Farmácia Popular	individual	active	25K174	farmacia	\N		2026-01-23 20:46:56.684+00	2026-01-23 20:46:56.684+00
645	29	9	1	\N	2027-06-30	30	Farmácia Popular	individual	active	B25F1215	farmacia	\N		2026-01-23 20:51:11.688+00	2026-01-23 20:51:11.688+00
646	81	4	1	\N	2027-07-30	1	Farmácia Popular	individual	active	12251046A	farmacia	\N		2026-01-23 20:54:24.012+00	2026-01-23 20:54:24.012+00
647	82	4	1	\N	2027-08-30	2	Farmácia Popular	individual	active	1420394	farmacia	\N		2026-01-23 20:57:41.363+00	2026-01-23 20:57:41.363+00
648	24	14	1	\N	2027-10-30	30	Farmácia Popular	individual	active	25K845	farmacia	\N		2026-01-23 20:59:59.168+00	2026-01-23 20:59:59.168+00
649	16	14	1	\N	2027-01-30	30	Farmácia Popular	individual	active	PL4709	farmacia	\N		2026-01-23 21:01:18.775+00	2026-01-23 21:01:18.775+00
650	82	39	2	\N	2027-08-30	2	Farmácia Popular	individual	active	1420394	farmacia	\N		2026-01-23 21:06:51.092+00	2026-01-23 21:06:51.092+00
651	81	39	2	\N	2027-08-30	1	Farmácia Popular	individual	active	12251046A	farmacia	\N		2026-01-23 21:08:27.485+00	2026-01-23 21:08:27.485+00
652	82	6	1	\N	2027-08-30	2	Farmácia Popular	individual	active	1420394	farmacia	\N		2026-01-23 21:13:44.357+00	2026-01-23 21:13:44.357+00
654	80	11	1	\N	2027-05-30	10	Compra/Doação	individual	active	61718	enfermagem	\N		2026-01-26 11:49:30.276+00	2026-01-26 11:49:30.276+00
653	80	11	1	\N	2027-05-30	20	Compra/Doação	individual	active	61718	farmacia	\N		2026-01-26 11:48:48.633+00	2026-01-26 11:49:30.283+00
655	85	15	1	\N	2026-12-30	15	Compra/Doação	individual	active	\N	enfermagem	\N	L:5062C60100	2026-01-26 11:50:31.223+00	2026-01-26 11:50:31.223+00
656	58	28	1	\N	2027-09-30	20	Compra/Doação	individual	active	\N	enfermagem	\N	L:1034381	2026-01-26 11:52:33.443+00	2026-01-26 11:52:33.443+00
658	16	39	1	\N	2026-05-30	15	Compra/Doação	individual	active	NW7852	enfermagem	\N		2026-01-26 11:56:02.468+00	2026-01-26 11:56:02.468+00
660	75	24	1	\N	2027-06-30	4	Família	individual	active	25F0275	enfermagem	\N		2026-01-26 11:58:09.15+00	2026-01-26 11:58:09.15+00
659	75	24	1	\N	2027-06-30	6	Família	individual	active	25F0275	farmacia	\N		2026-01-26 11:57:44.412+00	2026-01-26 11:58:09.156+00
662	125	16	3	\N	2026-09-30	7	Altocusto	individual	active	50018811	enfermagem	\N		2026-01-26 12:01:21.451+00	2026-01-26 12:01:21.451+00
663	33	29	3	\N	2027-10-30	15	Compra/Doação	individual	active	50306956	enfermagem	\N	\N	2026-01-26 12:02:59.987+00	2026-01-26 12:02:59.987+00
665	111	29	3	\N	2027-03-30	20	UBS	individual	active	25092W	enfermagem	\N		2026-01-26 12:07:04.316+00	2026-01-26 12:07:04.316+00
664	111	29	3	\N	2027-03-30	10	UBS	individual	active	25092W	farmacia	\N		2026-01-26 12:06:34.464+00	2026-01-26 12:07:04.329+00
666	111	34	3	\N	2027-06-30	60	UBS	individual	active	25G19J	enfermagem	\N		2026-01-26 12:08:35.436+00	2026-01-26 12:08:35.436+00
622	123	25	3	\N	2027-03-30	150	Altocusto	individual	active	50026239	farmacia	\N		2026-01-23 18:53:34.529+00	2026-01-26 14:30:03.903+00
624	125	25	3	\N	2027-02-28	150	Altocusto	individual	active	50025076	farmacia	\N		2026-01-23 18:55:33.603+00	2026-01-26 14:30:59.605+00
626	125	3	3	\N	2027-02-28	120	Altocusto	individual	active	50025076	farmacia	\N		2026-01-23 19:02:39.002+00	2026-01-26 14:51:00.974+00
631	125	16	3	\N	2026-10-30	210	Altocusto	individual	active	24100007	farmacia	\N		2026-01-23 19:15:30.376+00	2026-01-26 15:21:57.2+00
630	123	16	3	\N	2027-03-30	210	Altocusto	individual	active	50026239	farmacia	\N		2026-01-23 19:14:37.258+00	2026-01-26 15:24:21.256+00
615	182	\N	4	\N	2027-06-30	29	Compra/Doação	geral	active	B25D2719	farmacia	\N		2026-01-23 18:29:23.583+00	2026-01-26 21:27:30.319+00
617	125	2	3	\N	2027-02-28	40	Altocusto	individual	active	50025076	farmacia	\N		2026-01-23 18:42:15.878+00	2026-01-27 20:58:53.271+00
610	71	14	3	\N	2027-06-30	110	Família	individual	active	CNP5L005	farmacia	\N		2026-01-23 17:03:09.03+00	2026-01-27 21:12:17.572+00
618	126	19	3	\N	2027-03-30	50	Altocusto	individual	active	50025995	farmacia	\N		2026-01-23 18:44:14.257+00	2026-01-27 21:23:35.734+00
636	64	29	3	\N	2027-05-30	50	Altocusto	individual	active	25E935	farmacia	\N		2026-01-23 19:43:49.38+00	2026-01-27 21:46:19.889+00
612	71	34	3	\N	2027-02-28	20	Altocusto	individual	active	4S3328	enfermagem	\N	+ 6 cps anterior	2026-01-23 17:11:49.244+00	2026-01-28 22:05:10.786+00
611	71	34	3	\N	2027-02-28	10	Altocusto	individual	active	4S3328	farmacia	\N	contínuo	2026-01-23 17:06:13.94+00	2026-01-28 22:05:10.79+00
668	138	35	3	\N	2027-02-28	20	Altocusto	individual	active	50024823	enfermagem	\N		2026-01-26 12:12:01.762+00	2026-01-26 12:12:01.762+00
667	138	35	3	\N	2027-02-28	40	Altocusto	individual	active	50024823	farmacia	\N		2026-01-26 12:11:37.268+00	2026-01-26 12:12:01.767+00
669	43	27	1	\N	2028-09-30	60	Família	individual	active	5A0215	farmacia	\N		2026-01-26 12:55:53.49+00	2026-01-26 12:55:53.49+00
670	24	27	1	\N	2027-11-30	30	Família	individual	active	25K4G4	farmacia	\N	Uso contínuo	2026-01-26 12:57:10.497+00	2026-01-26 12:57:10.497+00
671	143	27	1	\N	2027-06-30	30	Família	individual	active	4V8282	farmacia	\N	Uso contínuo	2026-01-26 12:58:10.016+00	2026-01-26 12:58:10.016+00
674	186	27	1	\N	2027-02-28	30	Família	individual	active	4T9964	farmacia	\N	Uso contínuo	2026-01-26 13:03:22.236+00	2026-01-26 13:03:22.236+00
675	34	27	1	\N	2027-10-30	1	Família	individual	active	2513312	farmacia	\N	Uso contínuo	2026-01-26 13:07:23.538+00	2026-01-26 13:08:40.759+00
676	18	27	1	\N	2027-05-30	20	Família	individual	active	25G27B	farmacia	\N	Uso contínuo	2026-01-26 13:09:40.314+00	2026-01-26 13:09:40.314+00
677	119	27	3	\N	2027-07-30	1	Família	individual	active	50030073	farmacia	\N	Uso contínuo	2026-01-26 13:10:36.344+00	2026-01-26 13:10:36.344+00
678	61	27	1	\N	2026-06-30	7	Família	individual	active	064207	farmacia	\N		2026-01-26 13:25:49.907+00	2026-01-26 13:25:49.907+00
679	34	27	1	\N	2027-06-30	3	Família	individual	active	0784/25	farmacia	\N	Uso contínuo	2026-01-26 13:26:45.729+00	2026-01-26 13:26:45.729+00
680	35	\N	1	\N	2026-10-30	20	Compra/Doação	geral	active	1686/24M	farmacia	\N	\N	2026-01-26 13:30:52.654+00	2026-01-26 13:30:52.654+00
682	22	27	1	\N	2026-06-30	1	Família	individual	active	XH9J	enfermagem	\N	Uso contínuo	2026-01-26 13:32:48.737+00	2026-01-26 13:32:48.737+00
672	39	27	1	\N	2027-03-30	14	Família	individual	active	2501536	farmacia	\N	Uso contínuo	2026-01-26 12:59:09.903+00	2026-01-29 11:57:57.008+00
613	161	11	3	\N	2027-06-30	3	UBS	individual	active	50029446	enfermagem	\N	para geral	2026-01-23 18:25:22.361+00	2026-01-26 13:51:33.421+00
684	110	2	3	\N	2027-08-30	1	UBS	individual	active	25H837	enfermagem	\N		2026-01-26 13:52:40.564+00	2026-01-26 13:52:40.564+00
685	125	2	3	\N	2026-04-30	10	Compra/Doação	individual	active	50012707	farmacia	\N	Uso contínuo	2026-01-26 14:40:45.829+00	2026-01-26 14:40:45.829+00
686	125	2	3	\N	2026-07-30	20	Altocusto	individual	active	50016393	farmacia	\N	Uso contínuo	2026-01-26 14:44:43.57+00	2026-01-26 14:44:43.57+00
687	125	2	3	\N	2026-09-30	60	Altocusto	individual	active	50018811	farmacia	\N	Uso contínuo	2026-01-26 14:46:03.338+00	2026-01-26 14:46:03.338+00
688	125	2	3	\N	2026-10-30	30	Altocusto	individual	active	24100003	farmacia	\N	Uso contínuo	2026-01-26 14:47:05.97+00	2026-01-26 14:47:05.97+00
689	125	3	3	\N	2026-10-30	60	Altocusto	individual	active	24100003	farmacia	\N	Uso contínuo	2026-01-26 14:51:43.391+00	2026-01-26 14:51:43.391+00
690	125	3	3	\N	2026-07-30	10	Altocusto	individual	active	50016392	farmacia	\N	Uso contínuo	2026-01-26 14:53:47.215+00	2026-01-26 14:53:47.215+00
691	125	3	3	\N	2026-09-30	90	Altocusto	individual	active	50018813	farmacia	\N	Uso contínuo	2026-01-26 14:54:58.403+00	2026-01-26 14:54:58.403+00
692	125	3	3	\N	2026-09-30	71	Altocusto	individual	active	50018814	farmacia	\N	Uso contínuo	2026-01-26 14:55:53.366+00	2026-01-26 14:55:53.366+00
695	123	3	3	\N	2026-12-30	60	Altocusto	individual	active	50022743	farmacia	\N	Uso contínuo	2026-01-26 15:00:38.481+00	2026-01-26 15:00:38.481+00
696	123	3	4	\N	2027-03-30	90	Altocusto	individual	active	50026239	farmacia	\N	Uso contínuo	2026-01-26 15:06:57.843+00	2026-01-26 15:06:57.843+00
697	123	3	4	\N	2027-03-30	30	Altocusto	individual	active	50025322	farmacia	\N	Uso contínuo	2026-01-26 15:07:49.493+00	2026-01-26 15:07:49.493+00
698	125	24	3	\N	2026-10-30	60	Altocusto	individual	active	24100007	farmacia	\N	Uso contínuo	2026-01-26 15:09:33.232+00	2026-01-26 15:09:33.232+00
699	125	24	3	\N	2026-07-30	10	Altocusto	individual	active	50016392	farmacia	\N	Uso contínuo	2026-01-26 15:13:52.29+00	2026-01-26 15:13:52.29+00
700	125	24	3	\N	2026-09-30	80	Altocusto	individual	active	50018813	farmacia	\N	Uso contínuo	2026-01-26 15:14:49.321+00	2026-01-26 15:14:49.321+00
701	125	16	3	\N	2026-04-30	20	Altocusto	individual	active	50012725	farmacia	\N	Uso contínuo	2026-01-26 15:19:10.858+00	2026-01-26 15:19:10.858+00
702	125	16	3	\N	2026-06-30	90	Altocusto	individual	active	50016176	farmacia	\N	Uso contínuo	2026-01-26 15:20:01.809+00	2026-01-26 15:20:01.809+00
703	125	16	3	\N	2026-10-30	30	Altocusto	individual	active	24100003	farmacia	\N	Uso contínuo	2026-01-26 15:23:08.337+00	2026-01-26 15:23:08.337+00
704	123	16	3	\N	2027-03-30	30	Altocusto	individual	active	50025322	farmacia	\N	Uso contínuo	2026-01-26 15:25:11.996+00	2026-01-26 15:25:11.996+00
705	125	4	3	\N	2026-09-30	120	Altocusto	individual	active	50018811	farmacia	\N	Uso contínuo	2026-01-26 16:45:19.839+00	2026-01-26 16:45:19.839+00
706	125	38	3	\N	2026-07-30	100	Altocusto	individual	active	50016392	farmacia	\N	Uso contínuo	2026-01-26 16:54:51.857+00	2026-01-26 16:54:51.857+00
708	125	38	3	\N	2026-09-30	60	Altocusto	individual	active	50018811	farmacia	\N	Uso contínuo	2026-01-26 16:57:02.168+00	2026-01-26 16:57:02.168+00
707	125	38	3	\N	2026-09-30	120	Altocusto	individual	active	50018814	farmacia	\N	Uso contínuo	2026-01-26 16:55:58.503+00	2026-01-26 16:57:52.773+00
709	125	38	3	\N	2026-10-30	90	Altocusto	individual	active	24100007	farmacia	\N	Uso contínuo	2026-01-26 16:58:40.059+00	2026-01-26 17:09:29.651+00
710	125	35	3	\N	2026-07-30	20	Altocusto	individual	active	50016795	farmacia	\N	Uso contínuo	2026-01-26 17:19:20.021+00	2026-01-26 17:19:20.021+00
711	125	35	3	\N	2026-11-30	50	Altocusto	individual	active	50021599A	farmacia	\N	Uso contínuo	2026-01-26 17:20:26.248+00	2026-01-26 17:20:26.248+00
712	126	35	3	\N	2026-06-30	100	Altocusto	individual	active	24060014	farmacia	\N	Uso contínuo	2026-01-26 17:23:22+00	2026-01-26 17:23:22+00
713	138	35	3	\N	2026-12-30	60	Altocusto	individual	active	50022825	farmacia	\N	Uso contínuo	2026-01-26 17:33:37.82+00	2026-01-26 17:33:37.82+00
714	138	35	3	\N	2026-12-30	30	Altocusto	individual	active	50022818	farmacia	\N	Uso contínuo	2026-01-26 17:35:05.386+00	2026-01-26 17:35:05.386+00
715	126	35	3	\N	2026-11-30	30	Altocusto	individual	active	50021599	farmacia	\N	Uso contínuo	2026-01-26 17:36:43.578+00	2026-01-26 17:36:43.578+00
716	189	\N	8	\N	2026-10-30	30	Compra/Doação	geral	active	552027	farmacia	\N		2026-01-26 18:27:21.168+00	2026-01-26 18:27:21.168+00
718	22	39	1	\N	2027-06-30	1	Farmácia Popular	individual	active	07643327	enfermagem	\N	\N	2026-01-26 19:12:04.493+00	2026-01-26 19:12:04.493+00
719	46	26	2	\N	2027-11-30	1	UBS	individual	active	L:5C3338	enfermagem	\N	Uso contínuo	2026-01-26 19:13:39.835+00	2026-01-26 19:13:39.835+00
720	28	12	1	\N	2026-11-30	30	Família	individual	active	B24K2721	farmacia	\N		2026-01-26 19:43:05.648+00	2026-01-26 19:43:05.648+00
721	106	2	1	\N	2026-10-30	10	UBS	individual	active		enfermagem	\N	L: 50020777	2026-01-26 19:46:27.095+00	2026-01-26 19:46:27.095+00
723	22	4	2	\N	2027-03-30	1	Farmácia Popular	individual	active	07643252	enfermagem	\N		2026-01-26 19:49:58.895+00	2026-01-26 19:49:58.895+00
724	81	4	2	\N	2027-04-30	1	Farmácia Popular	individual	active	12250728A	farmacia	\N		2026-01-26 19:51:46.857+00	2026-01-26 19:51:46.857+00
725	105	33	3	\N	2027-09-30	3	Compra/Doação	individual	active	\N	enfermagem	\N	3 ampolas	2026-01-26 21:42:07.943+00	2026-01-26 21:42:07.943+00
727	190	8	3	\N	2027-03-30	15	Compra/Doação	individual	active	25040284	enfermagem	\N	Uso contínuo	2026-01-27 11:50:27.988+00	2026-01-27 11:50:27.988+00
726	190	8	3	\N	2027-03-30	75	Compra/Doação	individual	active	25040284	farmacia	\N	Uso contínuo	2026-01-27 11:50:03.083+00	2026-01-27 11:50:27.994+00
673	185	27	1	\N	2027-09-30	20	Família	individual	active	4Z9312	farmacia	\N	Uso contínuo	2026-01-26 13:01:22.494+00	2026-01-27 12:09:26.906+00
694	123	3	3	\N	2026-08-30	20	Altocusto	individual	active	50017919	farmacia	\N	Uso contínuo	2026-01-26 14:59:44.266+00	2026-01-27 21:03:35.924+00
683	188	\N	4	\N	2027-03-30	26	UBS	geral	active	251189	farmacia	\N	Uso geral - contínuo	2026-01-26 13:36:24.678+00	2026-01-28 13:43:26.055+00
729	71	29	3	\N	2027-10-30	10	Compra/Doação	individual	active	C2416778	enfermagem	\N	Uso contínuo	2026-01-27 11:54:50.446+00	2026-01-27 11:54:50.446+00
728	71	29	3	\N	2027-10-30	10	Compra/Doação	individual	active	C2416778	farmacia	\N	Uso contínuo	2026-01-27 11:54:10.229+00	2026-01-27 11:54:50.453+00
730	58	26	1	\N	2027-09-30	20	Compra/Doação	individual	active	1034382	enfermagem	\N		2026-01-27 12:00:32.248+00	2026-01-27 12:00:32.248+00
733	149	20	1	\N	2027-09-30	60	Família	individual	active	2513066	farmacia	\N	Uso contínuo	2026-01-27 12:06:56.704+00	2026-01-27 12:06:56.704+00
734	149	20	1	\N	2027-05-30	20	Família	individual	active	2506377	enfermagem	\N	Uso contínuo	2026-01-27 12:07:51.086+00	2026-01-27 12:07:51.086+00
735	149	20	1	\N	2026-06-30	20	Família	individual	active	2407472	enfermagem	\N	Uso contínuo	2026-01-27 12:08:06.258+00	2026-01-27 12:08:06.258+00
736	185	27	1	\N	2027-09-30	10	Família	individual	active	4Z9312	enfermagem	\N	Uso contínuo	2026-01-27 12:09:26.894+00	2026-01-27 12:09:26.894+00
737	95	20	1	\N	2027-05-30	10	Família	individual	active	42901016	enfermagem	\N		2026-01-27 12:10:15.702+00	2026-01-27 12:10:15.702+00
740	71	40	3	\N	2027-02-28	10	Família	individual	active	4S3328	enfermagem	\N	rep. 26/01 - 18:40	2026-01-27 16:12:42.56+00	2026-01-27 16:12:42.56+00
738	71	40	3	\N	2027-02-28	20	Família	individual	active	4S3328	farmacia	\N	Uso contínuo	2026-01-27 12:40:34.387+00	2026-01-27 16:12:42.573+00
741	35	40	1	\N	2027-05-30	10	Família	individual	active	0670/25M	enfermagem	\N	rep. 26/01 - 18:40	2026-01-27 16:13:50.122+00	2026-01-27 16:13:50.122+00
739	35	40	1	\N	2027-05-30	30	Família	individual	active	0670/25M	farmacia	\N	Uso contínuo	2026-01-27 12:42:10.738+00	2026-01-27 16:13:50.128+00
742	182	\N	4	\N	2027-08-30	2	Compra/Doação	geral	active	4Y6625	farmacia	\N		2026-01-27 17:48:48.032+00	2026-01-27 17:48:48.032+00
744	191	11	4	\N	2027-05-30	1	Compra/Doação	individual	active	25052304	enfermagem	\N	Para uso no morador Miguel	2026-01-27 17:56:57.678+00	2026-01-27 17:56:57.678+00
746	192	11	4	\N	2028-12-27	1	Compra/Doação	individual	active		enfermagem	\N	para uso no morador Miguel	2026-01-27 17:59:18.285+00	2026-01-27 17:59:18.285+00
747	193	\N	5	\N	2027-11-30	1	Compra/Doação	geral	active	0344232511	farmacia	\N		2026-01-27 18:05:51.449+00	2026-01-27 18:05:51.449+00
748	182	\N	4	\N	2027-03-30	1	Compra/Doação	geral	active	2504806	farmacia	\N		2026-01-27 18:06:47.765+00	2026-01-27 18:06:47.765+00
749	194	\N	4	\N	2028-08-30	2	Compra/Doação	geral	active	2531928	farmacia	\N		2026-01-27 18:10:39.023+00	2026-01-27 18:10:39.023+00
751	39	12	1	\N	2027-03-30	14	Família	individual	active	983437	enfermagem	\N		2026-01-27 20:13:09.207+00	2026-01-27 20:13:09.207+00
750	39	12	1	\N	2027-03-30	14	Família	individual	active	983437	farmacia	\N		2026-01-27 20:08:06.266+00	2026-01-27 20:13:09.215+00
753	36	4	1	\N	2027-05-31	28	UBS	individual	active	2515609	enfermagem	\N	\N	2026-01-27 20:26:11.696+00	2026-01-27 20:26:11.696+00
755	179	1	1	\N	2028-07-30	32	Família	individual	active	2426271	enfermagem	\N		2026-01-27 20:55:40.206+00	2026-01-27 20:55:40.206+00
754	179	1	1	\N	2028-07-30	40	Família	individual	active	2426271	farmacia	\N		2026-01-27 20:54:48.385+00	2026-01-27 20:55:40.229+00
756	125	2	3	\N	2027-02-28	20	Altocusto	individual	active	50025076	enfermagem	\N	20 + 5 cps do L:50016175	2026-01-27 20:58:53.259+00	2026-01-27 20:58:53.259+00
757	123	3	3	\N	2026-06-30	10	Altocusto	individual	active	50016074	enfermagem	\N	Uso contínuo	2026-01-27 21:02:40.311+00	2026-01-27 21:02:40.311+00
758	123	3	3	\N	2026-08-30	10	Altocusto	individual	active	50017919	enfermagem	\N	+ 11 cps do L: 4R2028	2026-01-27 21:03:35.917+00	2026-01-27 21:03:35.917+00
759	123	3	3	\N	2027-03-30	30	Altocusto	individual	active		enfermagem	\N		2026-01-27 21:05:26.113+00	2026-01-27 21:05:26.113+00
760	138	8	3	\N	2027-03-30	15	Compra/Doação	individual	active	ME25814	enfermagem	\N	+ 4 do anterior = total 19	2026-01-27 21:08:35.349+00	2026-01-27 21:08:35.349+00
761	71	14	3	\N	2027-06-30	10	Família	individual	active	CNP5L005	enfermagem	\N	+ 4 cps do anterior = total 14	2026-01-27 21:12:17.563+00	2026-01-27 21:12:17.563+00
763	64	14	3	\N	2027-05-30	10	UBS	individual	active	25E371	enfermagem	\N	+ 5 cps anterior	2026-01-27 21:16:09.521+00	2026-01-27 21:16:09.521+00
762	64	14	3	\N	2027-05-30	10	UBS	individual	active	25E371	farmacia	\N		2026-01-27 21:15:15.698+00	2026-01-27 21:16:09.527+00
764	126	19	3	\N	2027-01-30	8	Altocusto	individual	active	50023326A	enfermagem	\N	\N	2026-01-27 21:22:11.21+00	2026-01-27 21:23:01.157+00
765	126	19	3	\N	2027-03-30	10	Altocusto	individual	active	50025995	enfermagem	\N		2026-01-27 21:23:35.724+00	2026-01-27 21:23:35.724+00
767	22	26	2	\N	2027-08-30	1	Altocusto	individual	active	14250394	enfermagem	\N		2026-01-27 21:35:25.176+00	2026-01-27 21:35:25.176+00
766	22	26	2	\N	2027-08-30	1	Altocusto	individual	active	14250394	farmacia	\N		2026-01-27 21:34:39.755+00	2026-01-27 21:35:25.183+00
768	64	29	3	\N	2027-05-30	10	Altocusto	individual	active	25E935	enfermagem	\N	+ 3 cps	2026-01-27 21:46:19.871+00	2026-01-27 21:46:19.871+00
769	18	2	1	\N	2027-09-30	20	UBS	individual	active	L25J065	enfermagem	\N		2026-01-28 13:26:34.613+00	2026-01-28 13:26:34.613+00
771	28	6	1	\N	2027-01-30	18	Compra/Doação	individual	active	2502069	enfermagem	\N		2026-01-28 13:29:55.754+00	2026-01-28 13:29:55.754+00
770	28	6	1	\N	2027-01-30	0	Compra/Doação	individual	active	2502069	farmacia	\N		2026-01-28 13:29:26.682+00	2026-01-28 13:29:55.835+00
773	83	29	1	\N	2027-03-30	15	UBS	individual	active	3025731	enfermagem	\N		2026-01-28 13:32:10.373+00	2026-01-28 13:32:10.373+00
772	83	29	1	\N	2027-03-30	0	UBS	individual	active	3025731	farmacia	\N		2026-01-28 13:31:38.981+00	2026-01-28 13:32:10.379+00
774	121	3	1	\N	2029-05-29	10	Compra/Doação	individual	active	ORC.198513/1	farmacia	\N		2026-01-28 13:34:45.931+00	2026-01-28 13:34:45.931+00
775	188	\N	4	\N	2027-03-30	3	UBS	geral	active	251189	enfermagem	\N	para uso geral	2026-01-28 13:43:26.033+00	2026-01-28 13:43:26.033+00
776	34	\N	2	\N	2027-06-30	4	UBS	geral	active	0784/25	enfermagem	\N	para uso geral	2026-01-28 13:45:09.688+00	2026-01-28 13:45:09.688+00
777	83	35	1	\N	2026-12-30	30	Compra/Doação	individual	active	3024726	farmacia	\N		2026-01-28 14:16:23.527+00	2026-01-28 14:16:23.527+00
778	110	28	4	\N	2027-08-30	2	UBS	individual	active	25H837	farmacia	\N	\N	2026-01-28 14:44:30.82+00	2026-01-28 14:44:30.82+00
779	27	\N	6	\N	2028-06-30	60	Altocusto	geral	active	BR180753	farmacia	\N		2026-01-28 14:51:21.275+00	2026-01-28 14:51:21.275+00
780	143	39	1	\N	2026-04-30	30	UBS	individual	active	4B5549	farmacia	\N		2026-01-28 15:06:35.723+00	2026-01-28 15:06:35.723+00
781	143	\N	6	\N	2027-06-30	30	UBS	geral	active	4V8282	farmacia	\N		2026-01-28 15:08:19.626+00	2026-01-28 15:08:19.626+00
782	195	39	1	\N	2027-03-30	30	UBS	individual	active	4R5256	farmacia	\N		2026-01-28 15:17:46.967+00	2026-01-28 15:17:46.967+00
784	196	30	4	\N	2027-01-28	1	Compra/Doação	individual	active	\N	enfermagem	\N		2026-01-28 19:11:53.661+00	2026-01-28 19:11:53.661+00
783	196	\N	4	\N	2027-01-28	0	Compra/Doação	geral	active	\N	farmacia	\N		2026-01-28 19:10:14.001+00	2026-01-28 19:11:53.669+00
786	46	25	2	\N	2027-11-30	1	UBS	individual	active	5C3338	enfermagem	\N		2026-01-28 20:43:20.551+00	2026-01-28 20:43:20.551+00
785	46	25	2	\N	2027-11-30	2	UBS	individual	active	5C3338	farmacia	\N		2026-01-28 20:39:42.159+00	2026-01-28 20:43:20.558+00
788	44	42	1	\N	2027-01-30	30	UBS	individual	active	471921	farmacia	\N		2026-01-28 20:53:17.559+00	2026-01-28 20:53:17.559+00
789	113	4	3	\N	2026-11-30	60	UBS	individual	active	50022104	farmacia	\N		2026-01-28 20:58:06.965+00	2026-01-28 20:58:06.965+00
790	111	17	1	\N	2027-06-30	90	UBS	individual	active	25G19J	farmacia	\N		2026-01-28 21:01:35.925+00	2026-01-28 21:01:35.925+00
791	161	11	4	\N	2027-06-30	10	UBS	individual	active	50029446	farmacia	\N		2026-01-28 21:03:48.093+00	2026-01-28 21:03:48.093+00
792	64	25	3	\N	2027-05-30	10	Altocusto	individual	active	25E935	enfermagem	\N	+ 3 cps anterior	2026-01-28 21:43:33.481+00	2026-01-28 21:43:33.481+00
793	123	25	3	\N	2026-12-30	20	Altocusto	individual	active	50022743	enfermagem	\N	+ 3 cps anterior	2026-01-28 21:44:37.703+00	2026-01-28 21:44:37.703+00
787	55	5	1	\N	2027-01-30	50	UBS	individual	active	25B798	farmacia	\N		2026-01-28 20:49:37.686+00	2026-01-28 22:10:54.224+00
794	32	24	3	\N	2027-07-30	30	UBS	individual	active	2517054	enfermagem	\N	+ 2 cps L:4N ou M8914	2026-01-28 21:46:44.724+00	2026-01-28 21:46:44.724+00
796	134	22	3	\N	2027-06-30	20	Família	individual	active	2412726	enfermagem	\N	+ 5 cps anterior	2026-01-28 21:57:24.192+00	2026-01-28 21:57:24.192+00
795	134	22	3	\N	2027-06-30	0	Família	individual	active	2412726	farmacia	\N		2026-01-28 21:56:51.657+00	2026-01-28 21:57:24.198+00
797	51	33	3	\N	2026-06-30	15	Compra/Doação	individual	active	927429	enfermagem	\N	Psicotrópico - uso contínuo	2026-01-28 21:59:39.582+00	2026-01-28 21:59:39.582+00
798	51	33	3	\N	2027-01-30	30	UBS	individual	active	25010243	farmacia	\N		2026-01-28 22:00:46.924+00	2026-01-28 22:00:46.924+00
799	100	34	3	\N	2027-10-30	10	Compra/Doação	individual	active	561616	enfermagem	\N	+ 8 cps anterior	2026-01-28 22:04:29.793+00	2026-01-28 22:04:29.793+00
801	185	42	1	\N	2027-05-30	8	Compra/Doação	individual	active	4U9458	enfermagem	\N	atorvastatina de 20mg (dar 2 cps para 40mg)	2026-01-28 22:07:59.159+00	2026-01-28 22:07:59.159+00
800	185	42	1	\N	2027-05-30	0	Compra/Doação	individual	active	4U9458	farmacia	\N		2026-01-28 22:06:35.908+00	2026-01-28 22:07:59.168+00
802	142	5	1	\N	2028-09-30	25	Compra/Doação	individual	active	BR173864	enfermagem	\N	levotiroxina 100mg (dar 1/2 cp para 50mg)	2026-01-28 22:09:21.914+00	2026-01-28 22:09:21.914+00
752	142	5	1	\N	2028-09-30	0	Compra/Doação	individual	active	BR173864	farmacia	\N		2026-01-27 20:17:30.97+00	2026-01-28 22:09:21.921+00
803	55	5	1	\N	2027-01-30	20	UBS	individual	active	25B798	enfermagem	\N		2026-01-28 22:10:54.086+00	2026-01-28 22:10:54.086+00
804	39	27	1	\N	2027-03-30	14	Família	individual	active	2501536	enfermagem	\N	Uso contínuo	2026-01-29 11:57:56.987+00	2026-01-29 11:57:56.987+00
805	45	23	1	\N	2027-03-30	20	Família	individual	active	\N	enfermagem	\N	\N	2026-01-29 11:58:43.731+00	2026-01-29 11:58:43.731+00
806	29	18	1	\N	2027-05-30	30	Família	individual	active	B25E042	enfermagem	\N		2026-01-29 12:01:50.848+00	2026-01-29 12:01:50.848+00
808	16	15	1	\N	2027-05-30	20	Compra/Doação	individual	active	40303748	enfermagem	\N		2026-01-29 12:04:17.012+00	2026-01-29 12:04:17.012+00
807	16	15	1	\N	2027-05-30	0	Compra/Doação	individual	active	40303748	farmacia	\N		2026-01-29 12:03:55.063+00	2026-01-29 12:04:17.018+00
809	111	17	3	\N	2027-03-30	15	Altocusto	individual	active	25C45P	enfermagem	\N	emprestado para a Rother	2026-01-29 12:32:18.62+00	2026-01-29 12:32:18.62+00
810	87	8	3	\N	2027-02-28	10	Compra/Doação	individual	active	MPA250158	enfermagem	\N	\N	2026-01-29 12:34:25.607+00	2026-01-29 12:34:25.607+00
812	28	19	1	\N	2027-07-30	30	UBS	individual	active	B25H1712	enfermagem	\N		2026-01-29 13:17:11.813+00	2026-01-29 13:17:11.813+00
811	28	19	1	\N	2027-07-30	0	UBS	individual	active	B25H1712	farmacia	\N		2026-01-29 13:16:08.242+00	2026-01-29 13:17:11.824+00
\.


--
-- Data for Name: gaveta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gaveta (num_gaveta, categoria_id, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: insumo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.insumo (id, nome, descricao, estoque_minimo, preco, "createdAt", "updatedAt") FROM stdin;
11	Clister / Clisterol	solução de glicerina a 120mg/ml - 500ml	1	\N	2025-12-24 18:38:16.604+00	2025-12-24 18:38:16.604+00
12	Equipo macrogotas - 1 via	equipo de infusão gravitacional	10	\N	2025-12-24 18:40:18.123+00	2025-12-24 18:40:18.123+00
13	tiras ou fitas de dextro - teste	fita de dextro ou tiras-teste	50	\N	2026-01-07 20:24:47.052+00	2026-01-07 20:24:47.052+00
14	Lancetas	para lancetador para punção indolor	100	\N	2026-01-07 20:27:54.347+00	2026-01-07 20:27:54.347+00
15	Fraldas	Fralda GG	5	\N	2026-01-09 14:29:22.653+00	2026-01-09 14:29:22.653+00
16	Ataduras pequena	Atadura de crepom INA - 13fios/cm (10cm largura x 1,8cm comprimento)	12	\N	2026-01-13 21:49:49.499+00	2026-01-13 21:49:49.499+00
17	Casex curativo	Curativo de hidrocoloide	2	\N	2026-01-14 17:15:14.055+00	2026-01-14 17:15:14.055+00
18	Ataduras grandes	Atadura de crepom INA	10	42.40	2026-01-17 15:56:11.272+00	2026-01-17 15:56:15.588+00
19	Calcio + Vit. D3	carbonato de cálcio + vitamina D3	10	52.44	2026-01-22 18:30:37.091+00	2026-01-22 18:30:40.89+00
20	Copinhos descartáveis	copo de 50ml	500	45.35	2026-01-23 14:19:33.832+00	2026-01-23 14:19:39.18+00
21	Soro frasco	solução fisiológica de cloreto de sódio0,9% de uso nasal e dermatológico.	10	54.54	2026-01-23 14:42:38.641+00	2026-01-23 14:42:43.337+00
22	Compressa de gaze	7,5cm x 7,5cm . 13cm x 24cm	10	44.63	2026-01-27 17:32:22.142+00	2026-01-27 17:32:26.996+00
23	Curativo filme Peel	Curativo filme transparente	2	49.30	2026-01-27 17:41:22.144+00	2026-01-27 17:41:26.099+00
24	Soro flaconete	cloreto de sódio 0,9%	2	49.11	2026-01-27 17:52:33.364+00	2026-01-27 17:52:38.366+00
25	Dispositivo de transferência	adaptador para transferência de soluções	2	57.51	2026-01-27 18:11:37.534+00	2026-01-27 18:12:09.897+00
26	Soro injetável	cloreto de sódio 0,9%	5	76.45	2026-01-27 18:15:28.631+00	2026-01-27 18:15:32.259+00
27	Atadura de Rayon (Polarfix)	usado para curativos de queimaduras ou onde necessite de alta absorçao	1	37.21	2026-01-27 18:19:10.666+00	2026-01-27 18:19:14.185+00
28	Avental impermeável descartável manga longa	Avental impermeável descartável manga longa	10	47.16	2026-01-27 18:34:35.108+00	2026-01-27 18:34:38.119+00
29	Fixador para Sonda Nasal	Fixador para Sonda Nasal cor bege	3	41.40	2026-01-27 19:53:49.712+00	2026-01-27 19:53:52.768+00
30	Clorexidina aquosa (2%)	digliconato de clorexidina	2	31.68	2026-01-28 18:56:22.496+00	2026-01-28 18:56:25.888+00
31	Álcool 70% - 1L	álcool etílico hidratado	1	46.82	2026-01-28 18:57:41.443+00	2026-01-28 18:57:45.49+00
\.


--
-- Data for Name: login; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.login (id, login, password, refresh_token, "createdAt", "updatedAt", first_name, last_name) FROM stdin;
2	galdiniguilherme@gmail.com	$2b$10$SZllZ2DU8J7jpXuQ9Ojkre133Paf/hNDh.IXHX3OpRvP0AABVMUG6	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjIsImxvZ2luIjoiZ2FsZGluaWd1aWxoZXJtZUBnbWFpbC5jb20iLCJpYXQiOjE3Njg4NTY0NTQsImV4cCI6MTc2ODg2NzI1NH0.ryTG76rn7ayjiVGWdqKyOFtgWpecnTZfB11xd70fNXM	2026-01-19 21:00:54.629+00	2026-01-19 21:00:54.725+00	Guilherme	Tosi
1	farmaciahelenadornfeld@gmail.com	$2b$10$J/JQBCR/NYikHc.IXhKuOO/U643S0a2UMk3XBOrGCedii1QTobGFG	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsImxvZ2luIjoiZmFybWFjaWFoZWxlbmFkb3JuZmVsZEBnbWFpbC5jb20iLCJpYXQiOjE3Njk2ODk4MTksImV4cCI6MTc2OTcwMDYxOX0.QD5QKlRWJOqXJAsfA5zmtdPO_nqQt5BhVWfSvqtuwoE	2026-01-15 17:50:12.31+00	2026-01-29 12:30:19.622+00	Nice	Oliveira
\.


--
-- Data for Name: medicamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.medicamento (id, nome, dosagem, unidade_medida, principio_ativo, estoque_minimo, preco, "createdAt", "updatedAt") FROM stdin;
16	Sinvastatina	20.00	mg	Sinvastatina	15	\N	2025-12-24 15:11:01.337+00	2025-12-24 15:11:01.337+00
17	Salicetil	100.00	mg	ácido acetilsalicílico	10	\N	2025-12-24 17:04:28.323+00	2025-12-24 17:04:28.323+00
18	Alopurinol	100.00	mg	alopurinol	10	\N	2025-12-24 17:09:49.19+00	2025-12-24 17:09:49.19+00
19	Carvedilol	6.25	mg	carvedilol	10	\N	2025-12-24 17:12:07.206+00	2025-12-24 17:12:07.206+00
20	bromoprida	10.00	mg	bromoprida	10	\N	2025-12-24 17:13:48.78+00	2025-12-24 17:13:48.78+00
21	Hidroxizina	25.00	mg	cloridrato de hidroxizina	10	\N	2025-12-24 17:15:52.044+00	2025-12-24 17:15:52.044+00
22	Aerodini / Aerolin	100.00	mcg	sulfato de salbutamol jato-dose	2	\N	2025-12-24 17:19:15.967+00	2025-12-24 17:19:15.967+00
23	Clenil / beclometasona	250.00	mcg	dipropionato de beclametasona dose	2	\N	2025-12-24 17:27:49.384+00	2025-12-24 17:27:49.384+00
24	Metformina	500.00	mg	cloridrato de metformina 	10	\N	2025-12-24 17:32:58.495+00	2025-12-24 17:32:58.495+00
25	espironolactona	25.00	mg	espironolactona	10	\N	2025-12-24 17:33:25.502+00	2025-12-24 17:33:25.502+00
26	Alendronato de sódio	70.00	mg	Alendronato de sódio	1	\N	2025-12-24 17:34:07.428+00	2025-12-24 17:34:07.428+00
27	Glifage XR 	500.00	mg	cloridrato de metformina	15	\N	2025-12-24 17:40:39.676+00	2025-12-24 17:40:39.676+00
29	Losartana	50.00	mg	losartana potássica	10	\N	2025-12-24 17:42:23.247+00	2025-12-24 17:42:23.247+00
30	Prolopa BD	100.25	mg	levodopa+ cloridrato de benserazida	2	\N	2025-12-24 17:43:22.047+00	2025-12-24 17:43:22.047+00
31	Tramal / Tramadol	100.00	mg	cloridrato de tramadol	1	\N	2025-12-24 17:55:28.522+00	2025-12-24 17:55:28.522+00
33	Olanzapina	10.00	mg	Olanzapina	10	\N	2025-12-24 18:22:47.46+00	2025-12-24 18:22:47.46+00
34	Simeticona mg/ml	75.00	mg	simeticona - antigases	5	\N	2025-12-24 18:41:22.384+00	2025-12-24 18:41:22.384+00
35	Omeprazol	20.00	mg	Omeprazol	20	\N	2025-12-24 18:43:23.272+00	2025-12-24 18:43:23.272+00
36	domperidona	10.00	mg	domperidona	10	\N	2025-12-24 19:50:02.089+00	2025-12-24 19:50:02.089+00
37	Metildopa	250.00	mg	Metildopa	10	\N	2026-01-06 11:47:52.846+00	2026-01-06 11:48:36.347+00
38	Cobavital	1.40	mg	cobamamida + cloridrato de ciproeptadina 	10	\N	2026-01-07 13:06:59.068+00	2026-01-07 13:06:59.068+00
39	Pantoprazol sódico	40.00	mg	pantoprazol sódico	10	\N	2026-01-07 13:07:42.066+00	2026-01-07 13:07:42.066+00
40	hemifumarato de bisoprolol	5.00	mg	hemifumarato de bisoprolol	10	\N	2026-01-07 13:09:01.88+00	2026-01-07 13:09:01.88+00
41	betaistina	24.00	mg	dicloridrato de betaistina	10	\N	2026-01-07 13:09:56.827+00	2026-01-07 13:09:56.827+00
42	Novaldina	500.00	mg	dipirona mg/ml	1	\N	2026-01-07 13:11:12.705+00	2026-01-07 13:11:12.705+00
43	Somalgin cardio tamponado	100.00	mg	ácido acetilsalicílico	15	\N	2026-01-07 13:13:47.083+00	2026-01-07 13:13:47.083+00
44	AAS	100.00	mg	ácido acetilsalicílico	10	\N	2026-01-07 13:15:06.196+00	2026-01-07 13:15:06.196+00
45	Enalapril	10.00	mg	maleato de enalapril	10	\N	2026-01-07 13:16:51.907+00	2026-01-07 13:16:51.907+00
47	Captopril	25.00	mg	captopril	10	\N	2026-01-07 13:51:20.494+00	2026-01-07 13:51:20.494+00
48	Depakene	250.00	mg	ácido valproico	25	\N	2026-01-07 15:04:43.288+00	2026-01-07 15:04:43.288+00
49	clopidogrel	75.00	mg	bissulfato de clopidogrel	10	\N	2026-01-07 15:08:43.269+00	2026-01-07 15:08:43.269+00
50	montelucaste de sódio sachê	4.00	mg	montelucaste de sódio	4	\N	2026-01-07 15:14:27.15+00	2026-01-07 15:17:08.507+00
51	Trazodona	50.00	mg	trazodona	10	\N	2026-01-07 16:45:48.246+00	2026-01-07 16:45:48.246+00
52	Domperidona mg/ml	1.00	mg	Domperidona	2	\N	2026-01-07 16:46:51.277+00	2026-01-07 16:46:51.277+00
53	lactulose mg/ml	667.00	mg	lactulose	5	\N	2026-01-07 16:47:51.849+00	2026-01-07 16:47:51.849+00
54	Ácido fólico	5.00	mg	ácido fólico	10	\N	2026-01-07 16:48:23.147+00	2026-01-07 16:48:23.147+00
55	Tiamina	300.00	mg	tiamina	10	\N	2026-01-07 16:48:53.946+00	2026-01-07 16:48:53.946+00
56	ciclobenzaprina	10.00	mg	ciclobenzaprina	10	\N	2026-01-07 16:49:55.175+00	2026-01-07 16:49:55.175+00
58	aminofilina	100.00	mg	aminofilina	10	\N	2026-01-07 16:51:11.404+00	2026-01-07 16:51:11.404+00
59	dipirona monoidratada	500.00	mg	dipirona monoidratada	3	\N	2026-01-07 16:52:35.515+00	2026-01-07 16:52:35.515+00
60	Calcio 1500 + Vit D 400UI	1500.00	mg	Calcio 1500 + Vit D 400UI	15	\N	2026-01-07 16:54:12.772+00	2026-01-07 16:54:12.772+00
61	Buscopam composto	6.67	mg	buscopam composto	5	\N	2026-01-07 16:55:27.073+00	2026-01-07 16:55:27.073+00
64	Memantina	10.00	mg	cloridrato de memantina	15	\N	2026-01-07 17:20:58.482+00	2026-01-07 17:20:58.482+00
66	Tramadon ampola - mg/ml	50.00	mg	cloridrato de tramadol	1	\N	2026-01-07 17:36:10.27+00	2026-01-07 17:36:10.27+00
67	dipirona monoidratada ampola - injetável	1.00	g	dipirona monoidratada 	1	\N	2026-01-07 17:37:34.724+00	2026-01-07 17:37:34.724+00
82	salbutamol 	100.00	mcg	salbutamol	2	\N	2026-01-09 14:23:32.54+00	2026-01-09 14:23:32.54+00
65	dexametasona mg/ml - injetável	4.00	mg	fosfato dissódico de dexametasona	1	\N	2026-01-07 17:34:51.912+00	2026-01-07 17:40:06.32+00
68	Hyplex B - VA, IV ou IM	2.00	ml	polivitaminico	1	\N	2026-01-07 17:49:47.451+00	2026-01-07 17:49:47.451+00
69	bromoprida injetável	10.00	mg	bromoprida	1	\N	2026-01-07 17:50:47.234+00	2026-01-07 17:50:47.234+00
70	Condroflex - pó para solução	1.50	g	sulfato de glicosamina 1,5g + sulfato de condroitina 1,2g	10	\N	2026-01-07 21:18:39.875+00	2026-01-07 21:18:39.875+00
72	Almeida prado 46 - laxante	0.01	g	picossulfato de sódio 0,005g + cassia senna 1DH + polygonum punctatum 1CH +collinsonia canadensis 1CH	10	\N	2026-01-07 22:00:02.659+00	2026-01-07 22:01:04.094+00
73	Loratadina 	10.00	mg	loratadina	10	\N	2026-01-08 14:13:36.464+00	2026-01-08 14:13:36.464+00
74	Levotiroxina sódica	25.00	mcg	levotiroxina sódica	10	\N	2026-01-08 14:14:56.102+00	2026-01-08 14:14:56.102+00
75	muvinlax	3350.00	mg	macrogol+bicarbonato de sódio+cloreto de sódio+cloreto de potássio	5	\N	2026-01-08 16:55:27.723+00	2026-01-08 16:55:27.723+00
76	Buscopan mg/ml	10.00	mg	butilbrometo de escopolamina mg/ml	1	\N	2026-01-08 16:59:30.512+00	2026-01-08 16:59:30.512+00
77	Tansulosina	0.40	mg	cloridrato de tansulosina	10	\N	2026-01-08 17:00:05.102+00	2026-01-08 17:00:05.102+00
78	Flagyl	250.00	mg	metronidazol	5	\N	2026-01-08 17:19:50.402+00	2026-01-08 17:19:50.402+00
79	metronidazol	250.00	mg	meetronidazol	5	\N	2026-01-08 17:20:46.582+00	2026-01-08 17:20:46.582+00
80	dapagliflozina	10.00	mg	dapagliflozina	10	\N	2026-01-09 13:55:52.128+00	2026-01-09 13:55:52.128+00
81	dipropionato de beclametasona	250.00	mcg	dipropionato de beclametasona	2	\N	2026-01-09 14:17:53.563+00	2026-01-09 14:17:53.563+00
46	acetilcisteína mg/ml	20.00	mg	acetilcisteína Xarope	1	\N	2026-01-07 13:44:41.029+00	2026-01-09 14:37:46.89+00
63	amoxicilina + clavulanato de potássio	875.00	mg	amoxicilina + clavulanato de potássio - antibiótico	7	\N	2026-01-07 17:15:50.672+00	2026-01-09 14:38:20.096+00
57	azitromicina	500.00	mg	azitromicina -antibiótico	14	\N	2026-01-07 16:50:43.345+00	2026-01-09 14:38:46.7+00
71	donepezila	10.00	mg	donepezila - psicotrópico	10	\N	2026-01-07 21:38:45.591+00	2026-01-09 14:39:39.267+00
32	Escitalopram	10.00	mg	oxalato de escitalopram - psicotrópico	10	\N	2025-12-24 17:58:24.621+00	2026-01-09 14:40:12.296+00
83	Gliclazida	60.00	mg	Gliclazida - diabetes	15	\N	2026-01-09 15:05:06.237+00	2026-01-09 15:05:06.237+00
84	Calcio + colecalciferol (vit.D) 400UI	600.00	mg	Calcio + colecalciferol	10	\N	2026-01-12 17:48:05.748+00	2026-01-12 17:48:38.842+00
86	Duloxetina	60.00	mg	cloridrato de duloxetina 	10	\N	2026-01-12 17:52:21.452+00	2026-01-12 17:52:21.452+00
85	Citoneurim	5000.00	mcg	nitrato de tiamina 100mg + cloridrato de piridoxina 100mg + cianocobalamina 5000mcg	10	\N	2026-01-12 17:51:49.474+00	2026-01-12 18:01:22.637+00
87	Mirtazapina	15.00	mg	mirtazapina	10	\N	2026-01-12 18:29:02.411+00	2026-01-12 18:29:02.411+00
88	Prednisona	5.00	mg	prednisona	10	\N	2026-01-12 18:34:52.047+00	2026-01-12 18:34:52.047+00
89	Lamotrigina	100.00	mg	lamotrigina	10	\N	2026-01-12 18:38:12.08+00	2026-01-12 18:38:12.08+00
90	Lamotrigina	25.00	mg	lamotrigina 	10	\N	2026-01-12 18:38:55.469+00	2026-01-12 18:38:55.469+00
91	Lamotrigina	50.00	mg	lamotrigina	10	\N	2026-01-12 18:39:18.218+00	2026-01-12 18:39:18.218+00
92	levotiroxina	88.00	mcg	levotiroxina sódica	10	\N	2026-01-12 18:42:09.83+00	2026-01-12 18:42:09.83+00
93	Levotiroxina	62.50	mcg	levotiroxina sódica	10	\N	2026-01-12 18:42:38.071+00	2026-01-12 18:42:38.071+00
94	Floratil	200.00	mg	Saccharomyces boulardii CNCM I-745 - liofilizado 200mg	1	\N	2026-01-12 18:56:55.003+00	2026-01-12 18:56:55.003+00
95	Diosmina + hesperidina	450.00	mg	diosmina 450mg + hesperidina 50mg	10	\N	2026-01-12 22:03:36.408+00	2026-01-12 22:03:36.408+00
96	Colecalciferol (Vit.D) UI	7000.00	mg	colecalciferol	1	\N	2026-01-12 22:40:17.141+00	2026-01-12 22:40:17.141+00
97	Acetilcisteína Sachê	600.00	mg	acetilcisteína	5	\N	2026-01-12 22:43:06.347+00	2026-01-12 22:43:06.347+00
98	Di-magnésio malato	600.00	mg	magnésio	10	\N	2026-01-12 22:47:59.98+00	2026-01-12 22:47:59.98+00
99	BioFlex	40.00	mg	colágeno não hidrolisado tipo II 	10	\N	2026-01-12 22:51:51.34+00	2026-01-12 22:51:51.34+00
100	Pregabalina	75.00	mg	pregabalina	10	\N	2026-01-12 22:53:59.458+00	2026-01-12 22:53:59.458+00
101	Escitalopram gotas	20.00	mg	oxalato de escitalopram	1	\N	2026-01-12 23:04:31.275+00	2026-01-12 23:04:31.275+00
102	Buclina	25.00	mg	dicloridrato de buclizina	10	\N	2026-01-12 23:05:52.691+00	2026-01-12 23:05:52.691+00
103	paracetamol + codeína	500.00	mg	paracetamol 500mg + codeína 30mg	10	\N	2026-01-12 23:14:42.661+00	2026-01-12 23:14:42.661+00
104	Timolol	5.00	mg	maleato de timolol 5mg/ml	1	\N	2026-01-12 23:21:33.072+00	2026-01-12 23:21:33.072+00
105	nevrix IM	100.00	mg	cloridrato de tiamina 100mg/2ml+cloridrato de piridoxina 100mg/2ml+cianocobalamina 50mg/2ml	2	\N	2026-01-12 23:23:55.906+00	2026-01-12 23:23:55.906+00
106	Pamergan	25.00	mg	prometazina	10	\N	2026-01-12 23:39:17.924+00	2026-01-12 23:39:17.924+00
107	Spiolto	2.50	mcg	brometo de tiotrópio monoidratado 2,5mcg+cloridrato de olodaterol 2,5mcg	1	\N	2026-01-12 23:44:49.074+00	2026-01-12 23:44:49.074+00
108	Magnésio elementar	130.00	mg	magnésio 130mg + cloridrato de piridoxina 1mg	10	\N	2026-01-13 16:33:58.948+00	2026-01-13 16:33:58.948+00
109	Polietilenoglicol  SACHÊ  (PEG)	4000.00	mg	Polietilenoglicol 4000	10	\N	2026-01-13 16:36:02.114+00	2026-01-13 16:36:02.114+00
110	Neomicina 	5.00	mg	sulfato de neomicina 5mg/g + bacitracina 250UI/g	2	\N	2026-01-13 19:05:30.669+00	2026-01-13 19:05:30.669+00
111	Sertralina	50.00	mg	cloridrato de sertralina	15	\N	2026-01-13 19:31:07.604+00	2026-01-13 19:31:07.604+00
112	Meloxicam	15.00	mg	meloxicam	5	\N	2026-01-13 19:36:55.11+00	2026-01-13 19:36:55.11+00
113	Clorpromazina	25.00	mg	cloridrato de clorpromazina	10	\N	2026-01-13 19:39:05.394+00	2026-01-13 19:39:05.394+00
114	Paracetamol	200.00	mg	paracetamol 	1	\N	2026-01-13 19:43:22.961+00	2026-01-13 19:43:22.961+00
115	bromoprida 	4.00	mg	bromoprida	1	\N	2026-01-13 19:45:16.301+00	2026-01-13 19:45:16.301+00
116	Albendazol	400.00	mg	albendazol	1	\N	2026-01-13 20:26:56.973+00	2026-01-13 20:26:56.973+00
117	Metilcobalamina sublingual	1000.00	mcg	metilcobalamina 	10	\N	2026-01-13 21:34:40.511+00	2026-01-13 21:34:40.511+00
118	Aapixabana	5.00	mg	apixabana	10	\N	2026-01-13 21:39:34.853+00	2026-01-13 21:39:34.853+00
119	levozine 4%	40.00	mg	cloridrato de levomepromazina	1	\N	2026-01-14 12:32:04.723+00	2026-01-14 12:32:04.723+00
120	Clonazepam	2.50	mg	clonazepam gotas	1	\N	2026-01-14 12:33:26.058+00	2026-01-14 12:33:26.058+00
121	Vitamina D3	50000.00	mg	colecalciferol UI	1	\N	2026-01-14 13:07:52.908+00	2026-01-14 13:07:52.908+00
122	Tramadol	50.00	mg	cloridrato de tramadol	10	\N	2026-01-14 14:05:01.231+00	2026-01-14 14:05:01.231+00
123	Quetiapina 	25.00	mg	hemifurato de quetiapina	10	\N	2026-01-14 14:10:11.558+00	2026-01-14 14:10:11.558+00
124	Quetiapina	50.00	mg	hemifurato de quetiapina	10	\N	2026-01-14 14:11:03.556+00	2026-01-14 14:11:03.556+00
125	Quetiapina	100.00	mg	hemifurato de quetiapina	10	\N	2026-01-14 14:11:22.961+00	2026-01-14 14:11:22.961+00
126	Quetiapina	200.00	mg	hemifurato de quetiapina 	10	\N	2026-01-14 14:11:47.937+00	2026-01-14 14:11:47.937+00
127	Kaimbra flex - Suplemento Alimentar	500.00	mg	potássio 126mg, fósforo 104mg, vitamina D 15mcg, vitamina B1 2mg, vitamina B12 9,94mcg	10	\N	2026-01-14 14:18:46.861+00	2026-01-14 14:18:46.861+00
128	ORA PRO-NÓBIS - Suplemento alimentar	1.00	mg	combinação rica de proteínas, aminoácidos essenciais, fibras, vitaminas e minerais	10	\N	2026-01-14 14:22:12.097+00	2026-01-14 14:22:12.097+00
129	Rosuvastatina cálcica	20.00	mg	rosuvastatina cálcica	10	\N	2026-01-14 14:31:04.173+00	2026-01-14 14:31:04.173+00
130	Clenil A - Inalatório	400.00	mcg	dipropionato de beclometasona	1	\N	2026-01-14 14:35:32.672+00	2026-01-14 14:35:32.672+00
131	Torante - expectorante	15.00	mg	Hedera Helix L.	1	\N	2026-01-14 14:38:53.783+00	2026-01-14 14:38:53.783+00
132	Hidraplex (sais para hidratar)	27.90	g	cloreto de sódio 3,5g + cloreto de potássio 1,5g + citrato de sódio di-hidratado 2,9g + glicose 20g	2	\N	2026-01-14 14:41:34.425+00	2026-01-14 14:41:34.425+00
133	Inalador Relvar Ellipta	100.25	mcg	furoato de fluticasona + trifenatato de vilanterol	1	\N	2026-01-14 14:55:11.041+00	2026-01-14 14:55:11.041+00
134	Clonazepam	2.00	mg	clonazepam	10	\N	2026-01-15 11:49:10.17+00	2026-01-15 11:49:10.17+00
135	Sustrate	10.00	mg	propaltinitrato sublingual	10	\N	2026-01-15 12:04:09.983+00	2026-01-15 12:04:09.983+00
147	Venaflon (Diosmina 900mg+hesperidina 100mg)	900	mg	diosmina 900mg + hesperidina 100mg	10	\N	2026-01-16 17:30:55.667+00	2026-01-16 17:30:55.667+00
138	Olanzapina	10	mg	olanzapina	10	99.39	2026-01-16 13:54:01.522+00	2026-01-16 13:54:03.524+00
139	Fenitoína	100	mg	fenitoína	10	6.69	2026-01-16 13:55:21.151+00	2026-01-16 13:55:22.313+00
140	Biperideno	2	mg	biperideno	10	\N	2026-01-16 13:56:18.053+00	2026-01-16 13:56:18.053+00
141	Clonazepam	0,5	mg	clonazepam	10	\N	2026-01-16 15:06:06.113+00	2026-01-16 15:06:06.113+00
142	Levotiroxina sódica	50	mcg	Levotiroxina sódica	10	25.01	2026-01-16 15:07:18.704+00	2026-01-16 15:07:20.239+00
143	Espironolactona	25	mg	espironolactona	10	18.89	2026-01-16 15:08:04.672+00	2026-01-16 15:08:05.253+00
144	Paracetamol	500	mg	paracetamol	5	17.79	2026-01-16 16:42:37.265+00	2026-01-16 16:42:38.952+00
145	Drusolol	5	ml	cloridrato de dorzolamida 2% + maleato de timolol 0,5%	1	79.58	2026-01-16 17:15:55.01+00	2026-01-16 17:15:56.288+00
146	Colecalciferol	50.000	UI	Colecalciferol	1	\N	2026-01-16 17:18:49.307+00	2026-01-16 17:18:49.307+00
148	Venalot creme	240	ml	Cumarina, com a versão Venalot H contendo também Heparina Sódica	1	75.50	2026-01-16 17:32:53.257+00	2026-01-16 17:32:54.489+00
149	Anlodipino	5	mg	besilato de anlodipino	10	71.99	2026-01-16 17:49:51.621+00	2026-01-16 17:49:53.788+00
150	Anlodipino	20	mg	besilato de anlodipino	10	91.02	2026-01-16 17:50:44.24+00	2026-01-16 17:50:45.926+00
151	Levotiroxina sódica	75	mcg	Levotiroxina sódica	10	27.31	2026-01-16 18:02:51.032+00	2026-01-16 18:02:52.987+00
152	Escitalopram	20	mg	oxalato de escitalopram	10	104.35	2026-01-16 18:15:47.13+00	2026-01-16 18:15:48.969+00
153	Insulina regular ml	100	UI	insulilna humana regular	1	\N	2026-01-16 18:43:39.894+00	2026-01-16 18:43:39.894+00
154	Insulina NPH - UI/ml	100	UI	insulina humana	1	\N	2026-01-16 18:45:48.047+00	2026-01-16 18:45:48.047+00
155	Dipirona gotas	500	mg/ml	dipirona monoidratada gotas	5	\N	2026-01-16 19:31:49.938+00	2026-01-16 19:31:49.938+00
156	Olanzapina	5	mg	olanzapina	10	65.59	2026-01-16 21:46:31.295+00	2026-01-16 21:46:31.921+00
157	Galantamina	8	mg	bromidrato de galantamina	14	152.62	2026-01-16 22:11:20.521+00	2026-01-16 22:11:22.561+00
158	Galantamina	16	mg	bromidrato de galantamina	14	196.03	2026-01-16 22:12:11.522+00	2026-01-16 22:12:13.643+00
159	Atenolol	25	mg	atenolol	10	4.26	2026-01-17 13:22:50.711+00	2026-01-17 13:22:52.799+00
160	Sulfato ferroso	40	mg	sulfato ferroso	10	51.22	2026-01-17 14:11:11.395+00	2026-01-17 14:11:13.04+00
161	Colagenase (Kollagenase)	0,6	g	colagenase 0,6U/g + cloranfenicol 0,01g/g	2	\N	2026-01-17 15:19:44.824+00	2026-01-17 15:19:44.824+00
162	Risperidona	2	mg	Risperidona	10	31.97	2026-01-19 14:24:57.845+00	2026-01-19 14:24:59.905+00
163	Rivaroxabana	20	mg	Rivaroxabana	15	100.06	2026-01-19 15:28:52.646+00	2026-01-19 15:28:55.301+00
164	Haldol ou Haloperidol	70,52	mg/ml	Decanoato de haloperidol	2	\N	2026-01-19 19:52:31.532+00	2026-01-19 19:52:31.532+00
165	cefalexina monoidratada	500	mg	cefalexina monoidratada	8	\N	2026-01-19 20:31:28.233+00	2026-01-19 20:31:28.233+00
166	Ciprofloxacino	500	mg	ciprofloxacino	10	30.38	2026-01-20 13:29:09.094+00	2026-01-20 13:30:33.862+00
167	Isossorbida	20	mg	mononitrato de isossorbida	30	11.45	2026-01-20 19:05:50.771+00	2026-01-20 19:05:52.087+00
168	Calcitriol (Sigmatriol)	0.25	mg	calcitriol	10	\N	2026-01-20 19:47:10.511+00	2026-01-20 19:47:10.511+00
169	Furosemida	40	mg	furosemida	10	7.12	2026-01-21 13:12:05.091+00	2026-01-21 13:12:07.14+00
170	Ondansertrona	4	mg	cloridrato de ondansertrona	5	\N	2026-01-21 16:32:21.717+00	2026-01-21 16:32:21.717+00
171	Prednisona	20	mg	prednisonna	5	11.64	2026-01-21 17:02:17.133+00	2026-01-21 17:02:21.842+00
172	Nortriptilina	25	mg	nortriptilina	10	44.42	2026-01-21 18:09:36.873+00	2026-01-21 18:09:39.029+00
173	Enema (Phosfo enema)	0.16	g	fosfato de sódio monobásico+fosfato de sódio dibássico	1	\N	2026-01-21 19:57:52.428+00	2026-01-21 19:57:52.428+00
174	Piridostigmina (Mestinon)	60	mg	brometo de piridostigmina	30	45.35	2026-01-21 20:20:12.509+00	2026-01-21 20:20:16.384+00
175	Podoneem	10	ml	meloleca, cravo, tomilho, copaía e neem	1	\N	2026-01-21 20:41:41.734+00	2026-01-21 20:41:41.734+00
176	Nimesulida	50	mg/ml	nimesulida	1	\N	2026-01-21 20:42:40.16+00	2026-01-21 20:42:40.16+00
177	Metoprolol	25	mg	succinato de metoprolol	10	20.78	2026-01-22 18:15:19.323+00	2026-01-22 18:15:20.284+00
178	Calcio + Vit. D3 400UI	500	mg	carbonato de calcio + Vitamina D3	10	\N	2026-01-22 18:34:44.573+00	2026-01-22 18:34:44.573+00
179	Carbamazepina	200	mg	carbamazepina	10	21.54	2026-01-22 19:45:29.768+00	2026-01-22 19:45:31.415+00
180	Cilostazol	100	mg	cilostazol	20	53.13	2026-01-22 20:02:36.272+00	2026-01-22 20:02:38.618+00
181	Alenia	400	mcg	fumarato de formoterol di-hidratado 12mcg + budesonida	1	138.94	2026-01-23 14:29:53.848+00	2026-01-23 14:29:55.069+00
182	Nistatina Pomada 100000UI/g	200	mg	nistatina + oxido de zinco	10	\N	2026-01-23 18:23:41.798+00	2026-01-23 18:23:41.798+00
183	Galantamina	24	mg	bromidrato de galantamina	10	226.02	2026-01-23 18:48:38.084+00	2026-01-23 18:48:40.386+00
184	Nitazoxanida	500	mg	nitazoxanida	1	38.58	2026-01-23 19:19:48.324+00	2026-01-23 19:20:31.12+00
185	Atorvastatina	40	mg	atorvastatina cálcica	30	32.01	2026-01-26 13:00:14.913+00	2026-01-26 13:00:16.835+00
186	Bisoprolol	2.5	mg	hemifurato de bisoprolol	10	41.37	2026-01-26 13:02:31.756+00	2026-01-26 13:02:33.43+00
187	Rivaroxabana	10	mg	rivaroxabana	10	89.03	2026-01-26 13:04:45.843+00	2026-01-26 13:04:51.946+00
188	Lactulose (Lactben)	667	mg/ml	lactulose	10	\N	2026-01-26 13:34:42.883+00	2026-01-26 13:34:42.883+00
189	Vitamina D3	1000	UI	vitamina D3 1000	10	99.44	2026-01-26 18:22:52.28+00	2026-01-26 18:22:55.306+00
190	Desvenlafaxina	50	mg	succinato de desvenlafaxina	10	96.36	2026-01-27 11:48:12.843+00	2026-01-27 11:48:15.866+00
191	Curatec gel com PHMB	100	ml	gel com PHMB + EDTA	1	\N	2026-01-27 17:45:21.651+00	2026-01-27 17:45:21.651+00
192	Creme barreira (Comfeel)	60	ml	creme barreira	1	\N	2026-01-27 17:47:05.869+00	2026-01-27 17:47:05.869+00
193	Óleo Cicatrizante Dermaex	200	ml	óleo curativo para feridas e escaras	3	\N	2026-01-27 18:04:41.746+00	2026-01-27 18:04:41.746+00
194	TopcoidGel mg/	5	g	polissulfato de mucopolissacarídeo	2	\N	2026-01-27 18:09:21.267+00	2026-01-27 18:09:21.267+00
28	hidroclorotiazida	25.00	mg	hidrocloritiazida	10	\N	2025-12-24 17:41:53.464+00	2026-01-28 13:28:14.96+00
195	Carvedilol	25	mg	carvedilol	10	24.74	2026-01-28 15:16:32.85+00	2026-01-28 15:16:36.447+00
196	Pasta D'água	250	mg	óxido de zinco	1	\N	2026-01-28 18:54:53.138+00	2026-01-28 18:54:53.138+00
\.


--
-- Data for Name: movimentacao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.movimentacao (id, tipo, data, login_id, insumo_id, medicamento_id, armario_id, gaveta_id, quantidade, casela_id, setor, lote, "createdAt", "updatedAt", destino) FROM stdin;
34	entrada	2025-12-24 15:16:14.178+00	1	\N	16	6	\N	105	\N	farmacia	\N	2025-12-24 15:16:14.178+00	2025-12-24 15:16:14.178+00	\N
35	entrada	2025-12-24 15:18:07.051+00	1	\N	16	6	\N	45	\N	farmacia	\N	2025-12-24 15:18:07.051+00	2025-12-24 15:18:07.051+00	\N
36	entrada	2025-12-24 15:19:02.045+00	1	\N	16	6	\N	15	\N	farmacia	\N	2025-12-24 15:19:02.045+00	2025-12-24 15:19:02.045+00	\N
37	entrada	2025-12-24 17:06:06.296+00	1	\N	17	6	\N	60	\N	farmacia	\N	2025-12-24 17:06:06.296+00	2025-12-24 17:06:06.296+00	\N
38	entrada	2025-12-24 17:06:54.124+00	1	\N	16	6	\N	30	\N	farmacia	\N	2025-12-24 17:06:54.125+00	2025-12-24 17:06:54.125+00	\N
39	entrada	2025-12-24 17:08:20.71+00	1	\N	16	6	\N	30	\N	farmacia	\N	2025-12-24 17:08:20.71+00	2025-12-24 17:08:20.71+00	\N
40	entrada	2025-12-24 17:08:59.676+00	1	\N	16	6	\N	30	\N	farmacia	\N	2025-12-24 17:08:59.676+00	2025-12-24 17:08:59.676+00	\N
41	entrada	2025-12-24 17:11:03.624+00	1	\N	18	6	\N	17	\N	farmacia	\N	2025-12-24 17:11:03.624+00	2025-12-24 17:11:03.624+00	\N
42	entrada	2025-12-24 17:12:59.612+00	1	\N	19	6	\N	12	\N	farmacia	\N	2025-12-24 17:12:59.613+00	2025-12-24 17:12:59.613+00	\N
43	entrada	2025-12-24 17:14:46.52+00	1	\N	20	6	\N	15	\N	farmacia	\N	2025-12-24 17:14:46.52+00	2025-12-24 17:14:46.52+00	\N
44	entrada	2025-12-24 17:17:03.898+00	1	\N	21	6	\N	25	\N	farmacia	\N	2025-12-24 17:17:03.898+00	2025-12-24 17:17:03.898+00	\N
45	entrada	2025-12-24 17:24:51.868+00	1	\N	22	1	\N	3	4	farmacia	\N	2025-12-24 17:24:51.868+00	2025-12-24 17:24:51.868+00	\N
46	entrada	2025-12-24 17:26:39.362+00	1	\N	22	2	\N	2	\N	farmacia	\N	2025-12-24 17:26:39.362+00	2025-12-24 17:26:39.362+00	\N
47	entrada	2025-12-24 17:28:58.263+00	1	\N	23	2	\N	4	\N	farmacia	\N	2025-12-24 17:28:58.264+00	2025-12-24 17:28:58.264+00	\N
48	entrada	2025-12-24 17:35:44.568+00	1	\N	24	1	\N	30	42	farmacia	\N	2025-12-24 17:35:44.568+00	2025-12-24 17:35:44.568+00	\N
49	entrada	2025-12-24 17:36:45.393+00	1	\N	24	1	\N	30	42	farmacia	\N	2025-12-24 17:36:45.393+00	2025-12-24 17:36:45.393+00	\N
50	entrada	2025-12-24 17:37:43.273+00	1	\N	25	1	\N	30	42	farmacia	\N	2025-12-24 17:37:43.273+00	2025-12-24 17:37:43.273+00	\N
51	entrada	2025-12-24 17:38:38.154+00	1	\N	26	1	\N	4	42	farmacia	\N	2025-12-24 17:38:38.154+00	2025-12-24 17:38:38.154+00	\N
52	entrada	2025-12-24 17:45:02.798+00	1	\N	27	6	\N	105	\N	farmacia	\N	2025-12-24 17:45:02.798+00	2025-12-24 17:45:02.798+00	\N
53	entrada	2025-12-24 17:46:08.288+00	1	\N	28	6	\N	30	\N	farmacia	\N	2025-12-24 17:46:08.289+00	2025-12-24 17:46:08.289+00	\N
54	entrada	2025-12-24 17:47:11.948+00	1	\N	29	6	\N	60	\N	farmacia	\N	2025-12-24 17:47:11.948+00	2025-12-24 17:47:11.948+00	\N
55	entrada	2025-12-24 17:48:17.953+00	1	\N	30	2	\N	30	29	farmacia	\N	2025-12-24 17:48:17.953+00	2025-12-24 17:48:17.953+00	\N
56	entrada	2025-12-24 17:56:33.768+00	1	\N	31	1	\N	1	24	farmacia	\N	2025-12-24 17:56:33.768+00	2025-12-24 17:56:33.768+00	\N
57	entrada	2025-12-24 18:11:45.329+00	1	\N	32	1	\N	30	24	farmacia	\N	2025-12-24 18:11:45.329+00	2025-12-24 18:11:45.329+00	\N
58	entrada	2025-12-24 18:20:26.778+00	1	\N	32	1	\N	30	24	farmacia	\N	2025-12-24 18:20:26.779+00	2025-12-24 18:20:26.779+00	\N
59	entrada	2025-12-24 18:24:02.919+00	1	\N	33	1	\N	30	24	farmacia	\N	2025-12-24 18:24:02.92+00	2025-12-24 18:24:02.92+00	\N
60	entrada	2025-12-24 18:28:49.794+00	1	\N	22	1	\N	2	39	farmacia	\N	2025-12-24 18:28:49.794+00	2025-12-24 18:28:49.794+00	\N
61	entrada	2025-12-24 18:29:56.155+00	1	\N	23	1	\N	2	39	farmacia	\N	2025-12-24 18:29:56.155+00	2025-12-24 18:29:56.155+00	\N
62	entrada	2025-12-24 18:31:19.187+00	1	\N	24	1	\N	30	9	farmacia	\N	2025-12-24 18:31:19.187+00	2025-12-24 18:31:19.187+00	\N
63	entrada	2025-12-24 18:32:07.266+00	1	\N	29	1	\N	30	9	farmacia	\N	2025-12-24 18:32:07.266+00	2025-12-24 18:32:07.266+00	\N
64	entrada	2025-12-24 18:34:19.646+00	1	\N	22	1	\N	2	26	farmacia	\N	2025-12-24 18:34:19.646+00	2025-12-24 18:34:19.646+00	\N
65	entrada	2025-12-24 18:42:35.521+00	1	\N	34	2	\N	15	\N	farmacia	\N	2025-12-24 18:42:35.521+00	2025-12-24 18:42:35.521+00	\N
66	entrada	2025-12-24 18:45:16.994+00	1	\N	34	1	\N	1	6	farmacia	\N	2025-12-24 18:45:16.994+00	2025-12-24 18:45:16.994+00	\N
67	entrada	2025-12-24 18:54:06.918+00	1	\N	35	1	\N	56	6	farmacia	\N	2025-12-24 18:54:06.918+00	2025-12-24 18:54:06.918+00	\N
68	entrada	2025-12-24 18:55:04.661+00	1	\N	35	1	\N	20	6	farmacia	\N	2025-12-24 18:55:04.661+00	2025-12-24 18:55:04.661+00	\N
69	entrada	2025-12-24 18:57:06.697+00	1	12	\N	5	\N	2	\N	farmacia	\N	2025-12-24 18:57:06.697+00	2025-12-24 18:57:06.697+00	\N
70	entrada	2025-12-24 19:00:06.376+00	1	11	\N	5	\N	2	\N	farmacia	\N	2025-12-24 19:00:06.376+00	2025-12-24 19:00:06.376+00	\N
71	entrada	2025-12-24 19:52:18.137+00	1	\N	36	1	\N	60	4	farmacia	\N	2025-12-24 19:52:18.137+00	2025-12-24 19:52:18.137+00	\N
72	saida	2025-12-24 19:53:12.747+00	1	\N	36	1	\N	30	4	farmacia	\N	2025-12-24 19:53:12.747+00	2025-12-24 19:53:12.747+00	\N
73	entrada	2026-01-06 11:46:04.726+00	1	\N	27	1	\N	30	3	farmacia	\N	2026-01-06 11:46:04.726+00	2026-01-06 11:46:04.726+00	\N
74	entrada	2026-01-06 11:50:02.21+00	1	\N	37	1	\N	28	6	farmacia	\N	2026-01-06 11:50:02.21+00	2026-01-06 11:50:02.21+00	\N
75	entrada	2026-01-07 13:18:43.335+00	1	\N	43	1	\N	15	23	farmacia	\N	2026-01-07 13:18:43.335+00	2026-01-07 13:18:43.335+00	\N
76	entrada	2026-01-07 13:20:57.209+00	1	\N	45	1	\N	50	23	farmacia	\N	2026-01-07 13:20:57.209+00	2026-01-07 13:20:57.209+00	\N
77	entrada	2026-01-07 13:22:05.238+00	1	\N	40	1	\N	30	23	farmacia	\N	2026-01-07 13:22:05.238+00	2026-01-07 13:22:05.238+00	\N
78	entrada	2026-01-07 13:26:25.075+00	1	\N	39	1	\N	28	23	farmacia	\N	2026-01-07 13:26:25.075+00	2026-01-07 13:26:25.075+00	\N
79	entrada	2026-01-07 13:27:54.111+00	1	\N	38	1	\N	30	23	farmacia	\N	2026-01-07 13:27:54.111+00	2026-01-07 13:27:54.111+00	\N
80	entrada	2026-01-07 13:29:14.453+00	1	\N	26	1	\N	4	23	farmacia	\N	2026-01-07 13:29:14.453+00	2026-01-07 13:29:14.453+00	\N
81	entrada	2026-01-07 13:30:23.331+00	1	\N	41	1	\N	30	23	farmacia	\N	2026-01-07 13:30:23.331+00	2026-01-07 13:30:23.331+00	\N
82	entrada	2026-01-07 13:31:49.026+00	1	\N	42	1	\N	1	23	farmacia	\N	2026-01-07 13:31:49.026+00	2026-01-07 13:31:49.026+00	\N
83	saida	2026-01-07 13:34:50.233+00	1	\N	38	1	\N	15	23	farmacia	\N	2026-01-07 13:34:50.233+00	2026-01-07 13:34:50.233+00	\N
84	saida	2026-01-07 13:35:47.242+00	1	\N	41	1	\N	10	23	farmacia	\N	2026-01-07 13:35:47.242+00	2026-01-07 13:35:47.242+00	\N
85	entrada	2026-01-07 13:45:58.213+00	1	\N	46	2	\N	3	26	farmacia	\N	2026-01-07 13:45:58.213+00	2026-01-07 13:45:58.213+00	\N
86	saida	2026-01-07 13:48:17.219+00	1	\N	46	2	\N	1	26	farmacia	\N	2026-01-07 13:48:17.219+00	2026-01-07 13:48:17.219+00	\N
87	entrada	2026-01-07 13:53:08.303+00	1	\N	47	1	\N	30	3	farmacia	\N	2026-01-07 13:53:08.303+00	2026-01-07 13:53:08.303+00	\N
88	entrada	2026-01-07 15:06:33.652+00	1	\N	48	2	\N	100	4	farmacia	\N	2026-01-07 15:06:33.652+00	2026-01-07 15:06:33.652+00	\N
89	entrada	2026-01-07 15:09:38.749+00	1	\N	49	1	\N	30	4	farmacia	\N	2026-01-07 15:09:38.749+00	2026-01-07 15:09:38.749+00	\N
90	entrada	2026-01-07 15:15:58.779+00	1	\N	50	7	\N	15	\N	farmacia	\N	2026-01-07 15:15:58.779+00	2026-01-07 15:15:58.779+00	\N
91	entrada	2026-01-07 16:28:53.354+00	1	\N	45	1	\N	60	12	farmacia	\N	2026-01-07 16:28:53.354+00	2026-01-07 16:28:53.354+00	\N
93	entrada	2026-01-07 17:18:11.507+00	1	\N	63	7	\N	7	\N	farmacia	\N	2026-01-07 17:18:11.507+00	2026-01-07 17:18:11.507+00	\N
94	entrada	2026-01-07 17:25:15.223+00	1	\N	64	3	\N	45	\N	farmacia	\N	2026-01-07 17:25:15.223+00	2026-01-07 17:25:15.223+00	\N
95	entrada	2026-01-07 17:43:05.356+00	1	\N	65	3	\N	1	\N	farmacia	\N	2026-01-07 17:43:05.356+00	2026-01-07 17:43:05.356+00	\N
96	entrada	2026-01-07 17:43:57.108+00	1	\N	65	3	\N	1	\N	farmacia	\N	2026-01-07 17:43:57.108+00	2026-01-07 17:43:57.108+00	\N
97	entrada	2026-01-07 17:45:06.761+00	1	\N	66	3	\N	1	\N	farmacia	\N	2026-01-07 17:45:06.762+00	2026-01-07 17:45:06.762+00	\N
98	entrada	2026-01-07 17:46:24.581+00	1	\N	67	3	\N	1	\N	farmacia	\N	2026-01-07 17:46:24.581+00	2026-01-07 17:46:24.581+00	\N
99	entrada	2026-01-07 17:47:26.987+00	1	\N	67	3	\N	1	\N	farmacia	\N	2026-01-07 17:47:26.988+00	2026-01-07 17:47:26.988+00	\N
100	entrada	2026-01-07 17:48:26.094+00	1	\N	67	3	\N	2	\N	farmacia	\N	2026-01-07 17:48:26.094+00	2026-01-07 17:48:26.094+00	\N
101	entrada	2026-01-07 17:52:02.472+00	1	\N	68	3	\N	1	\N	farmacia	\N	2026-01-07 17:52:02.472+00	2026-01-07 17:52:02.472+00	\N
102	entrada	2026-01-07 17:52:55.074+00	1	\N	69	3	\N	2	\N	farmacia	\N	2026-01-07 17:52:55.074+00	2026-01-07 17:52:55.074+00	\N
103	entrada	2026-01-07 19:11:12.723+00	1	\N	64	3	\N	60	\N	farmacia	\N	2026-01-07 19:11:12.723+00	2026-01-07 19:11:12.723+00	\N
104	entrada	2026-01-07 19:12:41.034+00	1	\N	41	1	\N	30	18	farmacia	\N	2026-01-07 19:12:41.034+00	2026-01-07 19:12:41.034+00	\N
105	entrada	2026-01-07 20:29:09.768+00	1	13	\N	5	\N	50	\N	farmacia	\N	2026-01-07 20:29:09.768+00	2026-01-07 20:29:09.768+00	\N
106	saida	2026-01-07 20:30:16.381+00	1	13	\N	5	\N	50	\N	farmacia	\N	2026-01-07 20:30:16.381+00	2026-01-07 20:30:16.381+00	\N
107	entrada	2026-01-07 20:31:31.893+00	1	14	\N	5	\N	500	\N	farmacia	\N	2026-01-07 20:31:31.893+00	2026-01-07 20:31:31.893+00	\N
108	saida	2026-01-07 20:32:26.247+00	1	14	\N	5	\N	100	\N	farmacia	\N	2026-01-07 20:32:26.247+00	2026-01-07 20:32:26.247+00	\N
109	entrada	2026-01-07 21:10:04.432+00	1	\N	39	1	\N	28	35	farmacia	\N	2026-01-07 21:10:04.432+00	2026-01-07 21:10:04.432+00	\N
110	entrada	2026-01-07 21:14:31.136+00	1	\N	41	1	\N	30	35	farmacia	\N	2026-01-07 21:14:31.136+00	2026-01-07 21:14:31.136+00	\N
111	entrada	2026-01-07 21:16:22.934+00	1	\N	36	1	\N	60	35	farmacia	\N	2026-01-07 21:16:22.935+00	2026-01-07 21:16:22.935+00	\N
112	entrada	2026-01-07 21:20:48.769+00	1	\N	70	1	\N	30	35	farmacia	\N	2026-01-07 21:20:48.769+00	2026-01-07 21:20:48.769+00	\N
113	saida	2026-01-07 21:22:25.63+00	1	\N	41	1	\N	10	35	farmacia	\N	2026-01-07 21:22:25.63+00	2026-01-07 21:22:25.63+00	\N
114	saida	2026-01-07 21:26:22.607+00	1	\N	39	1	\N	14	35	farmacia	\N	2026-01-07 21:26:22.607+00	2026-01-07 21:26:22.607+00	\N
115	entrada	2026-01-07 21:39:52.828+00	1	\N	71	3	\N	30	40	farmacia	\N	2026-01-07 21:39:52.828+00	2026-01-07 21:39:52.828+00	\N
116	saida	2026-01-07 21:41:07.296+00	1	\N	71	3	\N	10	40	farmacia	\N	2026-01-07 21:41:07.296+00	2026-01-07 21:41:07.296+00	\N
117	entrada	2026-01-07 21:46:57.484+00	1	\N	24	1	\N	60	22	farmacia	\N	2026-01-07 21:46:57.484+00	2026-01-07 21:46:57.484+00	\N
118	entrada	2026-01-07 21:48:07.243+00	1	\N	16	1	\N	30	22	farmacia	\N	2026-01-07 21:48:07.244+00	2026-01-07 21:48:07.244+00	\N
119	entrada	2026-01-07 21:50:54.633+00	1	\N	28	1	\N	30	22	farmacia	\N	2026-01-07 21:50:54.633+00	2026-01-07 21:50:54.633+00	\N
120	entrada	2026-01-07 22:02:58.934+00	1	\N	72	1	\N	60	35	farmacia	\N	2026-01-07 22:02:58.934+00	2026-01-07 22:02:58.934+00	\N
121	entrada	2026-01-08 14:21:25.078+00	1	\N	73	1	\N	36	1	farmacia	\N	2026-01-08 14:21:25.079+00	2026-01-08 14:21:25.079+00	\N
122	entrada	2026-01-08 14:22:26.676+00	1	\N	58	1	\N	20	1	farmacia	\N	2026-01-08 14:22:26.676+00	2026-01-08 14:22:26.676+00	\N
123	entrada	2026-01-08 14:23:15.102+00	1	\N	16	1	\N	30	1	farmacia	\N	2026-01-08 14:23:15.102+00	2026-01-08 14:23:15.102+00	\N
124	entrada	2026-01-08 14:24:24.234+00	1	\N	74	1	\N	25	1	farmacia	\N	2026-01-08 14:24:24.234+00	2026-01-08 14:24:24.234+00	\N
125	entrada	2026-01-08 14:25:26.366+00	1	\N	26	1	\N	4	1	farmacia	\N	2026-01-08 14:25:26.366+00	2026-01-08 14:25:26.366+00	\N
126	entrada	2026-01-08 14:26:49.248+00	1	\N	44	1	\N	30	1	farmacia	\N	2026-01-08 14:26:49.248+00	2026-01-08 14:26:49.248+00	\N
127	entrada	2026-01-08 16:56:58.595+00	1	\N	75	1	\N	20	10	farmacia	\N	2026-01-08 16:56:58.595+00	2026-01-08 16:56:58.595+00	\N
128	entrada	2026-01-08 17:01:10.646+00	1	\N	76	1	\N	1	10	farmacia	\N	2026-01-08 17:01:10.647+00	2026-01-08 17:01:10.647+00	\N
129	entrada	2026-01-08 17:01:58.432+00	1	\N	77	1	\N	30	10	farmacia	\N	2026-01-08 17:01:58.432+00	2026-01-08 17:01:58.432+00	\N
130	saida	2026-01-08 17:06:20.776+00	1	\N	75	1	\N	6	10	farmacia	\N	2026-01-08 17:06:20.776+00	2026-01-08 17:06:20.776+00	\N
131	saida	2026-01-08 17:07:24.353+00	1	\N	77	1	\N	10	10	farmacia	\N	2026-01-08 17:07:24.353+00	2026-01-08 17:07:24.353+00	\N
132	saida	2026-01-08 17:10:00.438+00	1	\N	76	1	\N	1	10	farmacia	\N	2026-01-08 17:10:00.439+00	2026-01-08 17:10:00.439+00	\N
133	entrada	2026-01-08 17:23:00.826+00	1	\N	78	2	\N	14	\N	farmacia	\N	2026-01-08 17:23:00.826+00	2026-01-08 17:23:00.826+00	\N
134	entrada	2026-01-09 13:21:46.762+00	1	\N	52	4	\N	4	\N	farmacia	\N	2026-01-09 13:21:46.762+00	2026-01-09 13:21:46.762+00	\N
135	saida	2026-01-09 13:22:38.503+00	1	\N	52	4	\N	1	\N	farmacia	\N	2026-01-09 13:22:38.504+00	2026-01-09 13:22:38.504+00	\N
136	entrada	2026-01-09 13:30:19.267+00	1	\N	34	1	\N	4	5	farmacia	\N	2026-01-09 13:30:19.267+00	2026-01-09 13:30:19.267+00	\N
137	entrada	2026-01-09 13:31:05.186+00	1	\N	61	1	\N	2	5	farmacia	\N	2026-01-09 13:31:05.186+00	2026-01-09 13:31:05.186+00	\N
138	entrada	2026-01-09 13:32:12.02+00	1	\N	16	1	\N	30	5	farmacia	\N	2026-01-09 13:32:12.021+00	2026-01-09 13:32:12.021+00	\N
139	entrada	2026-01-09 13:33:05.521+00	1	\N	35	1	\N	30	5	farmacia	\N	2026-01-09 13:33:05.522+00	2026-01-09 13:33:05.522+00	\N
140	entrada	2026-01-09 13:38:50.842+00	1	\N	35	1	\N	40	26	farmacia	\N	2026-01-09 13:38:50.842+00	2026-01-09 13:38:50.842+00	\N
141	entrada	2026-01-09 13:39:46.523+00	1	\N	54	1	\N	60	26	farmacia	\N	2026-01-09 13:39:46.523+00	2026-01-09 13:39:46.523+00	\N
142	entrada	2026-01-09 13:40:57.953+00	1	\N	55	1	\N	60	26	farmacia	\N	2026-01-09 13:40:57.953+00	2026-01-09 13:40:57.953+00	\N
143	entrada	2026-01-09 13:56:37.914+00	1	\N	80	1	\N	30	29	farmacia	\N	2026-01-09 13:56:37.914+00	2026-01-09 13:56:37.914+00	\N
144	entrada	2026-01-09 14:00:29.606+00	1	\N	25	1	\N	30	38	farmacia	\N	2026-01-09 14:00:29.606+00	2026-01-09 14:00:29.606+00	\N
145	entrada	2026-01-09 14:03:04.621+00	1	\N	16	1	\N	30	3	farmacia	\N	2026-01-09 14:03:04.621+00	2026-01-09 14:03:04.621+00	\N
146	entrada	2026-01-09 14:03:59.568+00	1	\N	27	1	\N	60	3	farmacia	\N	2026-01-09 14:03:59.569+00	2026-01-09 14:03:59.569+00	\N
147	entrada	2026-01-09 14:08:40.8+00	1	\N	24	1	\N	30	13	farmacia	\N	2026-01-09 14:08:40.8+00	2026-01-09 14:08:40.8+00	\N
148	entrada	2026-01-09 14:09:26.413+00	1	\N	29	1	\N	30	13	farmacia	\N	2026-01-09 14:09:26.413+00	2026-01-09 14:09:26.413+00	\N
149	entrada	2026-01-09 14:14:19.755+00	1	\N	35	1	\N	20	26	farmacia	\N	2026-01-09 14:14:19.756+00	2026-01-09 14:14:19.756+00	\N
150	entrada	2026-01-09 14:18:55.796+00	1	\N	81	1	\N	1	26	farmacia	\N	2026-01-09 14:18:55.796+00	2026-01-09 14:18:55.796+00	\N
151	entrada	2026-01-09 15:11:47.22+00	1	\N	83	1	\N	60	35	farmacia	\N	2026-01-09 15:11:47.22+00	2026-01-09 15:11:47.22+00	\N
152	saida	2026-01-09 15:21:58.295+00	1	\N	83	1	\N	15	35	farmacia	\N	2026-01-09 15:21:58.295+00	2026-01-09 15:21:58.295+00	\N
153	entrada	2026-01-09 18:19:19.092+00	1	\N	83	1	\N	60	18	farmacia	\N	2026-01-09 18:19:19.092+00	2026-01-09 18:19:19.092+00	\N
154	saida	2026-01-09 18:20:24.157+00	1	\N	83	1	\N	15	18	farmacia	\N	2026-01-09 18:20:24.157+00	2026-01-09 18:20:24.157+00	\N
155	entrada	2026-01-09 18:23:19.821+00	1	\N	29	1	\N	30	18	farmacia	\N	2026-01-09 18:23:19.821+00	2026-01-09 18:23:19.821+00	\N
156	entrada	2026-01-12 16:45:48.046+00	1	13	\N	4	\N	100	\N	farmacia	\N	2026-01-12 16:45:48.046+00	2026-01-12 16:45:48.046+00	\N
157	entrada	2026-01-12 16:47:19.568+00	1	14	\N	5	\N	200	\N	farmacia	\N	2026-01-12 16:47:19.568+00	2026-01-12 16:47:19.568+00	\N
158	entrada	2026-01-12 16:48:18.457+00	1	\N	28	1	\N	30	19	farmacia	\N	2026-01-12 16:48:18.457+00	2026-01-12 16:48:18.457+00	\N
159	entrada	2026-01-12 16:49:30.409+00	1	\N	24	1	\N	30	19	farmacia	\N	2026-01-12 16:49:30.409+00	2026-01-12 16:49:30.409+00	\N
160	entrada	2026-01-12 16:51:27.274+00	1	\N	45	1	\N	30	19	farmacia	\N	2026-01-12 16:51:27.274+00	2026-01-12 16:51:27.274+00	\N
161	entrada	2026-01-12 18:04:42.124+00	1	\N	85	1	\N	30	15	farmacia	\N	2026-01-12 18:04:42.125+00	2026-01-12 18:04:42.125+00	\N
162	saida	2026-01-12 18:11:19.058+00	1	\N	75	1	\N	4	10	farmacia	\N	2026-01-12 18:11:19.058+00	2026-01-12 18:11:19.058+00	\N
163	entrada	2026-01-12 18:13:17.46+00	1	\N	84	1	\N	15	15	farmacia	\N	2026-01-12 18:13:17.46+00	2026-01-12 18:13:17.46+00	\N
164	entrada	2026-01-12 18:14:50.968+00	1	\N	86	1	\N	30	15	farmacia	\N	2026-01-12 18:14:50.968+00	2026-01-12 18:14:50.968+00	\N
165	entrada	2026-01-12 18:23:47.115+00	1	\N	64	3	\N	30	9	farmacia	\N	2026-01-12 18:23:47.115+00	2026-01-12 18:23:47.115+00	\N
166	entrada	2026-01-12 18:30:32.707+00	1	\N	87	3	\N	30	15	farmacia	\N	2026-01-12 18:30:32.707+00	2026-01-12 18:30:32.707+00	\N
167	entrada	2026-01-12 18:35:54.329+00	1	\N	88	1	\N	20	28	farmacia	\N	2026-01-12 18:35:54.33+00	2026-01-12 18:35:54.33+00	\N
168	entrada	2026-01-12 18:40:03.028+00	1	\N	89	3	\N	30	19	farmacia	\N	2026-01-12 18:40:03.028+00	2026-01-12 18:40:03.028+00	\N
169	entrada	2026-01-12 18:43:27.6+00	1	\N	92	1	\N	30	42	farmacia	\N	2026-01-12 18:43:27.601+00	2026-01-12 18:43:27.601+00	\N
170	entrada	2026-01-12 18:44:03.756+00	1	\N	93	1	\N	30	42	farmacia	\N	2026-01-12 18:44:03.756+00	2026-01-12 18:44:03.756+00	\N
171	entrada	2026-01-12 18:57:42.117+00	1	\N	94	1	\N	4	42	farmacia	\N	2026-01-12 18:57:42.117+00	2026-01-12 18:57:42.117+00	\N
172	saida	2026-01-12 18:58:30.287+00	1	\N	94	1	\N	4	42	farmacia	\N	2026-01-12 18:58:30.287+00	2026-01-12 18:58:30.287+00	\N
173	saida	2026-01-12 21:39:03.378+00	1	\N	46	2	\N	2	26	farmacia	\N	2026-01-12 21:39:03.378+00	2026-01-12 21:39:03.378+00	\N
174	entrada	2026-01-12 21:46:03.935+00	1	\N	58	1	\N	60	26	farmacia	\N	2026-01-12 21:46:03.935+00	2026-01-12 21:46:03.935+00	\N
175	entrada	2026-01-12 21:47:03.61+00	1	\N	58	1	\N	80	28	farmacia	\N	2026-01-12 21:47:03.61+00	2026-01-12 21:47:03.61+00	\N
176	saida	2026-01-12 21:48:02.167+00	1	\N	58	1	\N	20	26	farmacia	\N	2026-01-12 21:48:02.167+00	2026-01-12 21:48:02.167+00	\N
177	saida	2026-01-12 21:49:02.064+00	1	\N	58	1	\N	20	28	farmacia	\N	2026-01-12 21:49:02.064+00	2026-01-12 21:49:02.064+00	\N
178	entrada	2026-01-12 21:55:47.645+00	1	\N	56	1	\N	30	26	farmacia	\N	2026-01-12 21:55:47.645+00	2026-01-12 21:55:47.645+00	\N
179	saida	2026-01-12 21:57:19.084+00	1	\N	56	1	\N	15	26	farmacia	\N	2026-01-12 21:57:19.084+00	2026-01-12 21:57:19.084+00	\N
180	entrada	2026-01-12 22:05:28.094+00	1	\N	95	1	\N	30	26	farmacia	\N	2026-01-12 22:05:28.094+00	2026-01-12 22:05:28.094+00	\N
181	entrada	2026-01-12 22:12:01.091+00	1	\N	90	3	\N	30	26	farmacia	\N	2026-01-12 22:12:01.092+00	2026-01-12 22:12:01.092+00	\N
182	entrada	2026-01-12 22:12:47.342+00	1	\N	91	3	\N	30	26	farmacia	\N	2026-01-12 22:12:47.342+00	2026-01-12 22:12:47.342+00	\N
183	entrada	2026-01-12 22:20:47.974+00	1	\N	64	3	\N	30	29	farmacia	\N	2026-01-12 22:20:47.974+00	2026-01-12 22:20:47.974+00	\N
184	entrada	2026-01-12 22:21:44.439+00	1	\N	71	3	\N	30	29	farmacia	\N	2026-01-12 22:21:44.439+00	2026-01-12 22:21:44.439+00	\N
185	entrada	2026-01-12 22:24:53.033+00	1	\N	87	3	\N	30	15	farmacia	\N	2026-01-12 22:24:53.034+00	2026-01-12 22:24:53.034+00	\N
186	saida	2026-01-12 22:27:50.6+00	1	\N	87	3	\N	10	15	farmacia	\N	2026-01-12 22:27:50.6+00	2026-01-12 22:27:50.6+00	\N
187	entrada	2026-01-12 22:29:40.909+00	1	\N	33	3	\N	60	29	farmacia	\N	2026-01-12 22:29:40.909+00	2026-01-12 22:29:40.909+00	\N
188	entrada	2026-01-12 22:31:58.024+00	1	\N	40	1	\N	30	29	farmacia	\N	2026-01-12 22:31:58.024+00	2026-01-12 22:31:58.024+00	\N
189	entrada	2026-01-12 22:34:40.928+00	1	\N	87	3	\N	30	8	farmacia	\N	2026-01-12 22:34:40.928+00	2026-01-12 22:34:40.928+00	\N
190	entrada	2026-01-12 22:41:06.774+00	1	\N	96	1	\N	4	8	farmacia	\N	2026-01-12 22:41:06.775+00	2026-01-12 22:41:06.775+00	\N
191	entrada	2026-01-12 22:44:23.874+00	1	\N	97	2	\N	16	8	farmacia	\N	2026-01-12 22:44:23.874+00	2026-01-12 22:44:23.874+00	\N
192	entrada	2026-01-12 22:49:02.852+00	1	\N	98	1	\N	60	34	farmacia	\N	2026-01-12 22:49:02.853+00	2026-01-12 22:49:02.853+00	\N
193	entrada	2026-01-12 22:54:52.469+00	1	\N	99	1	\N	60	34	farmacia	\N	2026-01-12 22:54:52.469+00	2026-01-12 22:54:52.469+00	\N
194	entrada	2026-01-12 22:55:54.053+00	1	\N	88	1	\N	40	34	farmacia	\N	2026-01-12 22:55:54.053+00	2026-01-12 22:55:54.053+00	\N
195	entrada	2026-01-12 22:56:36.115+00	1	\N	100	3	\N	30	34	farmacia	\N	2026-01-12 22:56:36.115+00	2026-01-12 22:56:36.115+00	\N
196	entrada	2026-01-12 23:07:27.021+00	1	\N	72	1	\N	60	38	farmacia	\N	2026-01-12 23:07:27.021+00	2026-01-12 23:07:27.021+00	\N
197	entrada	2026-01-12 23:08:10.487+00	1	\N	102	1	\N	30	38	farmacia	\N	2026-01-12 23:08:10.487+00	2026-01-12 23:08:10.487+00	\N
198	entrada	2026-01-12 23:08:55.949+00	1	\N	101	3	\N	2	38	farmacia	\N	2026-01-12 23:08:55.949+00	2026-01-12 23:08:55.949+00	\N
199	entrada	2026-01-12 23:15:55.478+00	1	\N	103	3	\N	36	11	farmacia	\N	2026-01-12 23:15:55.478+00	2026-01-12 23:15:55.478+00	\N
200	entrada	2026-01-12 23:19:03.095+00	1	\N	39	1	\N	28	33	farmacia	\N	2026-01-12 23:19:03.095+00	2026-01-12 23:19:03.095+00	\N
201	entrada	2026-01-12 23:25:03.217+00	1	\N	105	3	\N	3	33	farmacia	\N	2026-01-12 23:25:03.217+00	2026-01-12 23:25:03.217+00	\N
202	saida	2026-01-12 23:30:59.095+00	1	\N	39	1	\N	7	33	farmacia	\N	2026-01-12 23:30:59.095+00	2026-01-12 23:30:59.095+00	\N
203	saida	2026-01-12 23:31:57.808+00	1	\N	102	1	\N	15	38	farmacia	\N	2026-01-12 23:31:57.808+00	2026-01-12 23:31:57.808+00	\N
204	entrada	2026-01-12 23:32:37.864+00	1	\N	102	1	\N	30	38	farmacia	\N	2026-01-12 23:32:37.864+00	2026-01-12 23:32:37.864+00	\N
205	entrada	2026-01-12 23:40:04.21+00	1	\N	106	1	\N	10	19	farmacia	\N	2026-01-12 23:40:04.21+00	2026-01-12 23:40:04.21+00	\N
206	saida	2026-01-12 23:41:12.519+00	1	\N	106	1	\N	10	19	farmacia	\N	2026-01-12 23:41:12.52+00	2026-01-12 23:41:12.52+00	\N
207	entrada	2026-01-12 23:45:53.545+00	1	\N	107	1	\N	1	27	farmacia	\N	2026-01-12 23:45:53.545+00	2026-01-12 23:45:53.545+00	\N
208	saida	2026-01-12 23:46:56.954+00	1	\N	107	1	\N	1	27	farmacia	\N	2026-01-12 23:46:56.955+00	2026-01-12 23:46:56.955+00	\N
209	saida	2026-01-13 13:27:34.305+00	1	\N	80	1	\N	15	29	farmacia	\N	2026-01-13 13:27:34.305+00	2026-01-13 13:27:34.305+00	\N
210	entrada	2026-01-13 16:37:10.282+00	1	\N	109	2	\N	30	27	farmacia	\N	2026-01-13 16:37:10.282+00	2026-01-13 16:37:10.282+00	\N
211	saida	2026-01-13 16:38:04.398+00	1	\N	109	2	\N	30	27	farmacia	\N	2026-01-13 16:38:04.398+00	2026-01-13 16:38:04.398+00	\N
212	entrada	2026-01-13 16:39:21.262+00	1	\N	108	1	\N	30	27	farmacia	\N	2026-01-13 16:39:21.262+00	2026-01-13 16:39:21.262+00	\N
213	saida	2026-01-13 16:40:54.571+00	1	\N	108	1	\N	30	27	farmacia	\N	2026-01-13 16:40:54.571+00	2026-01-13 16:40:54.571+00	\N
214	entrada	2026-01-13 19:06:43.693+00	1	\N	110	4	\N	2	\N	farmacia	\N	2026-01-13 19:06:43.693+00	2026-01-13 19:06:43.693+00	\N
215	entrada	2026-01-13 19:09:55.102+00	1	\N	110	4	\N	4	13	farmacia	\N	2026-01-13 19:09:55.102+00	2026-01-13 19:09:55.102+00	\N
216	entrada	2026-01-13 19:11:16.323+00	1	\N	59	1	\N	10	2	farmacia	\N	2026-01-13 19:11:16.323+00	2026-01-13 19:11:16.323+00	\N
217	entrada	2026-01-13 19:25:57.984+00	1	\N	102	1	\N	15	38	farmacia	\N	2026-01-13 19:25:57.984+00	2026-01-13 19:25:57.984+00	\N
218	entrada	2026-01-13 19:26:57.896+00	1	\N	102	1	\N	30	11	farmacia	\N	2026-01-13 19:26:57.896+00	2026-01-13 19:26:57.896+00	\N
219	saida	2026-01-13 19:29:24.843+00	1	\N	102	1	\N	15	11	farmacia	\N	2026-01-13 19:29:24.843+00	2026-01-13 19:29:24.843+00	\N
220	entrada	2026-01-13 19:32:56.801+00	1	\N	111	3	\N	60	13	farmacia	\N	2026-01-13 19:32:56.801+00	2026-01-13 19:32:56.801+00	\N
221	entrada	2026-01-13 19:35:48.821+00	1	\N	65	3	\N	1	14	farmacia	\N	2026-01-13 19:35:48.821+00	2026-01-13 19:35:48.821+00	\N
222	entrada	2026-01-13 19:39:57.153+00	1	\N	113	3	\N	60	2	farmacia	\N	2026-01-13 19:39:57.153+00	2026-01-13 19:39:57.153+00	\N
223	saida	2026-01-13 19:41:23.724+00	1	\N	113	3	\N	20	2	farmacia	\N	2026-01-13 19:41:23.724+00	2026-01-13 19:41:23.724+00	\N
224	entrada	2026-01-13 19:44:21.544+00	1	\N	114	1	\N	3	7	farmacia	\N	2026-01-13 19:44:21.544+00	2026-01-13 19:44:21.544+00	\N
225	entrada	2026-01-13 19:46:12.381+00	1	\N	115	1	\N	3	7	farmacia	\N	2026-01-13 19:46:12.381+00	2026-01-13 19:46:12.381+00	\N
226	entrada	2026-01-13 19:46:52.46+00	1	\N	52	1	\N	2	7	farmacia	\N	2026-01-13 19:46:52.46+00	2026-01-13 19:46:52.46+00	\N
227	saida	2026-01-13 19:48:10.262+00	1	\N	115	1	\N	1	7	farmacia	\N	2026-01-13 19:48:10.262+00	2026-01-13 19:48:10.262+00	\N
228	saida	2026-01-13 20:22:38.109+00	1	\N	114	1	\N	1	7	farmacia	\N	2026-01-13 20:22:38.109+00	2026-01-13 20:22:38.109+00	\N
229	saida	2026-01-13 20:24:16.996+00	1	\N	52	4	\N	2	\N	farmacia	\N	2026-01-13 20:24:16.996+00	2026-01-13 20:24:16.996+00	\N
230	entrada	2026-01-13 20:28:34.499+00	1	\N	116	1	\N	8	42	farmacia	\N	2026-01-13 20:28:34.499+00	2026-01-13 20:28:34.499+00	\N
231	entrada	2026-01-13 20:46:36.71+00	1	\N	114	1	\N	2	26	farmacia	\N	2026-01-13 20:46:36.71+00	2026-01-13 20:46:36.71+00	\N
232	entrada	2026-01-13 20:49:15.749+00	1	\N	114	1	\N	3	11	farmacia	\N	2026-01-13 20:49:15.749+00	2026-01-13 20:49:15.749+00	\N
233	entrada	2026-01-13 20:50:16.279+00	1	\N	115	1	\N	3	11	farmacia	\N	2026-01-13 20:50:16.28+00	2026-01-13 20:50:16.28+00	\N
234	saida	2026-01-13 20:51:49.387+00	1	\N	114	1	\N	1	26	farmacia	\N	2026-01-13 20:51:49.387+00	2026-01-13 20:51:49.387+00	\N
235	saida	2026-01-13 20:54:02.301+00	1	\N	114	1	\N	1	11	farmacia	\N	2026-01-13 20:54:02.301+00	2026-01-13 20:54:02.301+00	\N
236	saida	2026-01-13 20:55:13.013+00	1	\N	115	1	\N	1	11	farmacia	\N	2026-01-13 20:55:13.013+00	2026-01-13 20:55:13.013+00	\N
237	entrada	2026-01-13 20:57:20.109+00	1	\N	115	1	\N	3	8	farmacia	\N	2026-01-13 20:57:20.109+00	2026-01-13 20:57:20.109+00	\N
238	entrada	2026-01-13 20:58:12.815+00	1	\N	114	1	\N	3	8	farmacia	\N	2026-01-13 20:58:12.815+00	2026-01-13 20:58:12.815+00	\N
239	saida	2026-01-13 20:58:58.782+00	1	\N	115	1	\N	1	8	farmacia	\N	2026-01-13 20:58:58.782+00	2026-01-13 20:58:58.782+00	\N
240	saida	2026-01-13 21:00:01.904+00	1	\N	114	1	\N	1	8	farmacia	\N	2026-01-13 21:00:01.904+00	2026-01-13 21:00:01.904+00	\N
241	entrada	2026-01-13 21:01:50.072+00	1	\N	52	4	\N	2	8	farmacia	\N	2026-01-13 21:01:50.072+00	2026-01-13 21:01:50.072+00	\N
242	entrada	2026-01-13 21:04:47.958+00	1	\N	76	1	\N	3	\N	farmacia	\N	2026-01-13 21:04:47.958+00	2026-01-13 21:04:47.958+00	\N
243	saida	2026-01-13 21:06:04.133+00	1	\N	76	1	\N	1	\N	farmacia	\N	2026-01-13 21:06:04.133+00	2026-01-13 21:06:04.133+00	\N
244	entrada	2026-01-13 21:35:44.528+00	1	\N	117	1	\N	30	35	farmacia	\N	2026-01-13 21:35:44.528+00	2026-01-13 21:35:44.528+00	\N
245	saida	2026-01-13 21:37:40.078+00	1	\N	110	4	\N	1	\N	farmacia	\N	2026-01-13 21:37:40.078+00	2026-01-13 21:37:40.078+00	\N
246	entrada	2026-01-13 21:40:32.512+00	1	\N	118	6	\N	60	\N	farmacia	\N	2026-01-13 21:40:32.512+00	2026-01-13 21:40:32.512+00	\N
247	saida	2026-01-13 21:43:22.202+00	1	\N	59	1	\N	2	2	farmacia	\N	2026-01-13 21:43:22.202+00	2026-01-13 21:43:22.202+00	\N
248	saida	2026-01-13 21:44:55.554+00	1	\N	34	1	\N	4	5	farmacia	\N	2026-01-13 21:44:55.554+00	2026-01-13 21:44:55.554+00	\N
249	entrada	2026-01-13 21:51:13.159+00	1	16	\N	5	\N	30	\N	farmacia	\N	2026-01-13 21:51:13.159+00	2026-01-13 21:51:13.159+00	\N
250	saida	2026-01-13 21:53:50.074+00	1	16	\N	5	\N	12	\N	farmacia	\N	2026-01-13 21:53:50.074+00	2026-01-13 21:53:50.074+00	\N
251	saida	2026-01-13 21:54:58.764+00	1	16	\N	5	\N	6	\N	farmacia	\N	2026-01-13 21:54:58.764+00	2026-01-13 21:54:58.764+00	\N
252	entrada	2026-01-14 13:09:09.793+00	1	\N	102	1	\N	30	25	farmacia	\N	2026-01-14 13:09:09.794+00	2026-01-14 13:09:09.794+00	\N
253	entrada	2026-01-14 13:10:04.087+00	1	\N	71	3	\N	30	25	farmacia	\N	2026-01-14 13:10:04.087+00	2026-01-14 13:10:04.087+00	\N
254	entrada	2026-01-14 13:12:28.583+00	1	\N	71	6	\N	80	\N	farmacia	\N	2026-01-14 13:12:28.583+00	2026-01-14 13:12:28.583+00	\N
255	saida	2026-01-14 13:14:49.952+00	1	\N	71	6	\N	10	\N	farmacia	\N	2026-01-14 13:14:49.952+00	2026-01-14 13:14:49.952+00	\N
256	saida	2026-01-14 13:16:30.63+00	1	\N	102	1	\N	15	25	farmacia	\N	2026-01-14 13:16:30.63+00	2026-01-14 13:16:30.63+00	\N
257	entrada	2026-01-14 13:20:22.386+00	1	\N	121	1	\N	4	25	farmacia	\N	2026-01-14 13:20:22.387+00	2026-01-14 13:20:22.387+00	\N
258	saida	2026-01-14 13:21:42.362+00	1	\N	121	1	\N	4	25	farmacia	\N	2026-01-14 13:21:42.362+00	2026-01-14 13:21:42.362+00	\N
259	saida	2026-01-14 13:24:13.105+00	1	\N	71	3	\N	10	25	farmacia	\N	2026-01-14 13:24:13.105+00	2026-01-14 13:24:13.105+00	\N
260	entrada	2026-01-14 14:00:40.116+00	1	\N	102	1	\N	30	25	farmacia	\N	2026-01-14 14:00:40.116+00	2026-01-14 14:00:40.116+00	\N
261	entrada	2026-01-14 14:02:37.137+00	1	\N	27	1	\N	30	25	farmacia	\N	2026-01-14 14:02:37.137+00	2026-01-14 14:02:37.137+00	\N
262	entrada	2026-01-14 14:05:56.61+00	1	\N	122	1	\N	30	25	farmacia	\N	2026-01-14 14:05:56.61+00	2026-01-14 14:05:56.61+00	\N
263	entrada	2026-01-14 14:06:49.557+00	1	\N	71	3	\N	30	25	farmacia	\N	2026-01-14 14:06:49.557+00	2026-01-14 14:06:49.557+00	\N
264	entrada	2026-01-14 14:12:53.645+00	1	\N	123	3	\N	20	25	farmacia	\N	2026-01-14 14:12:53.646+00	2026-01-14 14:12:53.646+00	\N
265	entrada	2026-01-14 14:13:49.948+00	1	\N	125	3	\N	110	25	farmacia	\N	2026-01-14 14:13:49.948+00	2026-01-14 14:13:49.948+00	\N
266	entrada	2026-01-14 14:42:27.912+00	1	\N	107	2	\N	1	\N	farmacia	\N	2026-01-14 14:42:27.912+00	2026-01-14 14:42:27.912+00	\N
267	entrada	2026-01-14 14:57:21.924+00	1	\N	133	2	\N	2	\N	farmacia	\N	2026-01-14 14:57:21.925+00	2026-01-14 14:57:21.925+00	\N
268	entrada	2026-01-14 14:58:15.505+00	1	\N	132	2	\N	1	\N	farmacia	\N	2026-01-14 14:58:15.505+00	2026-01-14 14:58:15.505+00	\N
269	entrada	2026-01-14 15:01:54.777+00	1	\N	130	2	\N	2	\N	farmacia	\N	2026-01-14 15:01:54.777+00	2026-01-14 15:01:54.777+00	\N
270	entrada	2026-01-14 15:02:51.897+00	1	\N	129	6	\N	30	\N	farmacia	\N	2026-01-14 15:02:51.897+00	2026-01-14 15:02:51.897+00	\N
271	entrada	2026-01-14 15:05:09.837+00	1	\N	131	2	\N	1	\N	farmacia	\N	2026-01-14 15:05:09.837+00	2026-01-14 15:05:09.837+00	\N
272	entrada	2026-01-14 17:16:23.953+00	1	17	\N	5	\N	6	\N	farmacia	\N	2026-01-14 17:16:23.953+00	2026-01-14 17:16:23.953+00	\N
273	entrada	2026-01-15 11:50:34.543+00	1	\N	134	3	\N	10	18	farmacia	\N	2026-01-15 11:50:34.543+00	2026-01-15 11:50:34.543+00	\N
274	entrada	2026-01-15 11:55:14.207+00	1	\N	126	3	\N	170	19	farmacia	\N	2026-01-15 11:55:14.207+00	2026-01-15 11:55:14.207+00	\N
275	entrada	2026-01-15 11:56:35.631+00	1	\N	111	3	\N	30	34	farmacia	\N	2026-01-15 11:56:35.631+00	2026-01-15 11:56:35.631+00	\N
276	entrada	2026-01-15 11:57:50.187+00	1	\N	35	6	\N	14	\N	farmacia	\N	2026-01-15 11:57:50.187+00	2026-01-15 11:57:50.187+00	\N
277	saida	2026-01-15 11:59:21.021+00	1	\N	35	6	\N	14	\N	farmacia	\N	2026-01-15 11:59:21.022+00	2026-01-15 11:59:21.022+00	\N
278	entrada	2026-01-15 12:00:21.22+00	1	\N	35	1	\N	14	2	farmacia	\N	2026-01-15 12:00:21.22+00	2026-01-15 12:00:21.22+00	\N
279	saida	2026-01-15 12:01:33.253+00	1	\N	35	1	\N	14	2	farmacia	\N	2026-01-15 12:01:33.253+00	2026-01-15 12:01:33.253+00	\N
280	entrada	2026-01-15 12:02:25.009+00	1	\N	35	1	\N	28	13	farmacia	\N	2026-01-15 12:02:25.01+00	2026-01-15 12:02:25.01+00	\N
281	entrada	2026-01-15 12:05:00.458+00	1	\N	135	1	\N	50	18	farmacia	\N	2026-01-15 12:05:00.459+00	2026-01-15 12:05:00.459+00	\N
282	saida	2026-01-15 12:06:20.06+00	1	\N	134	3	\N	10	18	farmacia	\N	2026-01-15 12:06:20.061+00	2026-01-15 12:06:20.061+00	\N
283	saida	2026-01-15 12:07:37.17+00	1	\N	126	3	\N	20	19	farmacia	\N	2026-01-15 12:07:37.17+00	2026-01-15 12:07:37.17+00	\N
284	saida	2026-01-15 12:10:17.827+00	1	\N	111	3	\N	30	34	farmacia	\N	2026-01-15 12:10:17.827+00	2026-01-15 12:10:17.827+00	\N
285	saida	2026-01-15 12:11:57.309+00	1	\N	35	1	\N	28	13	farmacia	\N	2026-01-15 12:11:57.309+00	2026-01-15 12:11:57.309+00	\N
286	saida	2026-01-15 12:13:28.36+00	1	\N	135	1	\N	50	18	farmacia	\N	2026-01-15 12:13:28.36+00	2026-01-15 12:13:28.36+00	\N
287	saida	2026-01-15 12:19:29.198+00	1	\N	16	6	\N	60	\N	farmacia	\N	2026-01-15 12:19:29.198+00	2026-01-15 12:19:29.198+00	\N
288	entrada	2026-01-15 12:20:48.961+00	1	\N	16	1	\N	60	39	farmacia	\N	2026-01-15 12:20:48.961+00	2026-01-15 12:20:48.961+00	\N
289	saida	2026-01-15 12:22:19.106+00	1	\N	16	1	\N	30	39	farmacia	\N	2026-01-15 12:22:19.106+00	2026-01-15 12:22:19.106+00	\N
290	saida	2026-01-15 12:23:55.624+00	1	\N	117	1	\N	30	35	farmacia	\N	2026-01-15 12:23:55.624+00	2026-01-15 12:23:55.624+00	\N
291	saida	2026-01-15 12:25:01.626+00	1	\N	58	1	\N	20	26	farmacia	\N	2026-01-15 12:25:01.626+00	2026-01-15 12:25:01.626+00	\N
92	entrada	2026-01-07 17:06:51.742+00	1	\N	50	6	\N	15	\N	farmacia	\N	2026-01-07 17:06:51.742+00	2026-01-07 17:06:51.742+00	\N
292	entrada	2026-01-15 20:55:33.01+00	1	\N	43	1	\N	51	27	farmacia	L22803	2026-01-15 20:55:33.011+00	2026-01-15 20:55:33.011+00	\N
293	saida	2026-01-15 20:56:11.624+00	1	\N	43	1	\N	15	27	farmacia	L22803	2026-01-15 20:56:11.624+00	2026-01-15 20:56:11.624+00	\N
294	entrada	2026-01-16 14:01:06.281+00	1	\N	138	3	\N	30	8	farmacia	ME25814	2026-01-16 14:01:06.282+00	2026-01-16 14:01:06.282+00	\N
295	entrada	2026-01-16 14:02:50.791+00	1	\N	125	3	\N	50	16	farmacia	5000188811	2026-01-16 14:02:50.791+00	2026-01-16 14:02:50.791+00	\N
296	saida	2026-01-16 14:08:38.018+00	1	\N	138	3	\N	15	8	farmacia	ME25814	2026-01-16 14:08:38.018+00	2026-01-16 14:08:38.018+00	\N
297	saida	2026-01-16 14:12:23.638+00	1	\N	125	3	\N	20	16	farmacia	5000188811	2026-01-16 14:12:23.638+00	2026-01-16 14:12:23.638+00	\N
298	entrada	2026-01-16 14:16:17.52+00	1	\N	139	3	\N	16	22	farmacia	LERA0451	2026-01-16 14:16:17.52+00	2026-01-16 14:16:17.52+00	\N
299	entrada	2026-01-16 14:17:29.6+00	1	\N	140	3	\N	10	29	farmacia	50023281	2026-01-16 14:17:29.6+00	2026-01-16 14:17:29.6+00	\N
300	entrada	2026-01-16 14:19:21.108+00	1	\N	138	3	\N	30	29	farmacia	25010044	2026-01-16 14:19:21.108+00	2026-01-16 14:19:21.108+00	\N
301	entrada	2026-01-16 14:21:25.919+00	1	\N	64	3	\N	30	29	farmacia	40511276	2026-01-16 14:21:25.919+00	2026-01-16 14:21:25.919+00	\N
302	entrada	2026-01-16 14:27:18.342+00	1	\N	111	3	\N	15	40	farmacia	25045P	2026-01-16 14:27:18.343+00	2026-01-16 14:27:18.343+00	\N
303	saida	2026-01-16 14:28:20.75+00	1	\N	139	3	\N	16	22	farmacia	LERA0451	2026-01-16 14:28:20.75+00	2026-01-16 14:28:20.75+00	\N
304	saida	2026-01-16 14:29:02.352+00	1	\N	140	3	\N	10	29	farmacia	50023281	2026-01-16 14:29:02.353+00	2026-01-16 14:29:02.353+00	\N
305	saida	2026-01-16 14:30:15.392+00	1	\N	33	3	\N	10	29	farmacia	\N	2026-01-16 14:30:15.392+00	2026-01-16 14:30:15.392+00	\N
306	saida	2026-01-16 14:30:59.504+00	1	\N	64	3	\N	15	29	farmacia	40511276	2026-01-16 14:30:59.504+00	2026-01-16 14:30:59.504+00	\N
307	saida	2026-01-16 14:36:15.705+00	1	\N	111	3	\N	15	40	farmacia	25045P	2026-01-16 14:36:15.705+00	2026-01-16 14:36:15.705+00	\N
308	entrada	2026-01-16 15:21:13.317+00	1	\N	141	3	\N	30	40	farmacia	LFKP07577	2026-01-16 15:21:13.317+00	2026-01-16 15:21:13.317+00	\N
309	entrada	2026-01-16 15:22:51.586+00	1	\N	143	1	\N	30	40	farmacia	4W4964	2026-01-16 15:22:51.587+00	2026-01-16 15:22:51.587+00	\N
310	entrada	2026-01-16 15:25:09.746+00	1	\N	142	1	\N	30	40	farmacia	BR177565	2026-01-16 15:25:09.746+00	2026-01-16 15:25:09.746+00	\N
311	entrada	2026-01-16 15:26:03.293+00	1	\N	16	1	\N	30	40	farmacia	PH8301	2026-01-16 15:26:03.293+00	2026-01-16 15:26:03.293+00	\N
312	entrada	2026-01-16 16:41:07.393+00	1	\N	29	1	\N	30	40	farmacia	L933297	2026-01-16 16:41:07.393+00	2026-01-16 16:41:07.393+00	\N
313	entrada	2026-01-16 17:04:02.401+00	1	\N	144	1	\N	10	40	farmacia	L24H326	2026-01-16 17:04:02.401+00	2026-01-16 17:04:02.401+00	\N
314	entrada	2026-01-16 17:05:17.415+00	1	\N	17	1	\N	30	40	farmacia	17135Y	2026-01-16 17:05:17.416+00	2026-01-16 17:05:17.416+00	\N
315	entrada	2026-01-16 17:06:36.191+00	1	\N	64	1	\N	30	40	farmacia	25F27T	2026-01-16 17:06:36.192+00	2026-01-16 17:06:36.192+00	\N
316	entrada	2026-01-16 17:10:40.865+00	1	\N	58	1	\N	80	1	farmacia	1034378	2026-01-16 17:10:40.865+00	2026-01-16 17:10:40.865+00	\N
317	entrada	2026-01-16 17:17:04.57+00	1	\N	95	1	\N	60	16	farmacia	2512845	2026-01-16 17:17:04.57+00	2026-01-16 17:17:04.57+00	\N
318	entrada	2026-01-16 17:19:48.113+00	1	\N	146	1	\N	4	16	farmacia	557295	2026-01-16 17:19:48.113+00	2026-01-16 17:19:48.113+00	\N
319	entrada	2026-01-16 17:20:55.999+00	1	\N	16	1	\N	30	16	farmacia	PL4709	2026-01-16 17:20:55.999+00	2026-01-16 17:20:55.999+00	\N
320	entrada	2026-01-16 17:21:56.855+00	1	\N	145	1	\N	1	16	farmacia	2539558	2026-01-16 17:21:56.855+00	2026-01-16 17:21:56.855+00	\N
321	entrada	2026-01-16 17:23:11.282+00	1	\N	73	1	\N	12	16	farmacia	2504982	2026-01-16 17:23:11.282+00	2026-01-16 17:23:11.282+00	\N
322	entrada	2026-01-16 17:34:58.3+00	1	\N	147	1	\N	30	10	farmacia	42900961	2026-01-16 17:34:58.3+00	2026-01-16 17:34:58.3+00	\N
323	entrada	2026-01-16 17:35:57.219+00	1	\N	148	2	\N	1	10	farmacia	5640912	2026-01-16 17:35:57.219+00	2026-01-16 17:35:57.219+00	\N
324	entrada	2026-01-16 17:38:24.547+00	1	\N	26	1	\N	4	18	farmacia	4Q3825	2026-01-16 17:38:24.547+00	2026-01-16 17:38:24.547+00	\N
325	entrada	2026-01-16 17:41:21.617+00	1	\N	26	1	\N	4	18	farmacia	25086	2026-01-16 17:41:21.617+00	2026-01-16 17:41:21.617+00	\N
326	entrada	2026-01-16 17:44:13.503+00	1	\N	83	1	\N	30	18	farmacia	3025426	2026-01-16 17:44:13.503+00	2026-01-16 17:44:13.503+00	\N
327	entrada	2026-01-16 17:45:47.405+00	1	\N	27	1	\N	30	18	farmacia	BR177625	2026-01-16 17:45:47.406+00	2026-01-16 17:45:47.406+00	\N
328	entrada	2026-01-16 17:46:48.326+00	1	\N	27	1	\N	30	18	farmacia	BR181483	2026-01-16 17:46:48.326+00	2026-01-16 17:46:48.326+00	\N
329	entrada	2026-01-16 17:47:41.692+00	1	\N	43	1	\N	60	18	farmacia	505827	2026-01-16 17:47:41.692+00	2026-01-16 17:47:41.692+00	\N
330	entrada	2026-01-16 17:53:19.061+00	1	\N	149	1	\N	30	18	farmacia	PE0324	2026-01-16 17:53:19.061+00	2026-01-16 17:53:19.061+00	\N
331	entrada	2026-01-16 17:54:32.976+00	1	\N	149	1	\N	30	18	farmacia	PJ7090	2026-01-16 17:54:32.976+00	2026-01-16 17:54:32.976+00	\N
332	entrada	2026-01-16 17:56:57.236+00	1	\N	149	1	\N	30	18	farmacia	PR7116	2026-01-16 17:56:57.236+00	2026-01-16 17:56:57.236+00	\N
333	entrada	2026-01-16 18:03:59.524+00	1	\N	151	1	\N	30	18	farmacia	BR180114	2026-01-16 18:03:59.525+00	2026-01-16 18:03:59.525+00	\N
334	entrada	2026-01-16 18:06:47.556+00	1	\N	29	1	\N	60	18	farmacia	B25E042	2026-01-16 18:06:47.556+00	2026-01-16 18:06:47.556+00	\N
335	entrada	2026-01-16 18:08:19.791+00	1	\N	28	1	\N	30	18	farmacia	LFRA027641	2026-01-16 18:08:19.792+00	2026-01-16 18:08:19.792+00	\N
336	entrada	2026-01-16 18:09:18.337+00	1	\N	28	1	\N	30	18	farmacia	LFRA01481	2026-01-16 18:09:18.337+00	2026-01-16 18:09:18.337+00	\N
337	entrada	2026-01-16 18:10:13.36+00	1	\N	16	1	\N	30	18	farmacia	PF7036	2026-01-16 18:10:13.36+00	2026-01-16 18:10:13.36+00	\N
338	entrada	2026-01-16 18:11:07.776+00	1	\N	16	1	\N	30	18	farmacia	PP5177	2026-01-16 18:11:07.776+00	2026-01-16 18:11:07.776+00	\N
339	entrada	2026-01-16 18:14:46.83+00	1	\N	134	1	\N	30	18	farmacia	LFK06420	2026-01-16 18:14:46.83+00	2026-01-16 18:14:46.83+00	\N
340	entrada	2026-01-16 18:19:25.131+00	1	\N	152	1	\N	30	18	farmacia	987108	2026-01-16 18:19:25.131+00	2026-01-16 18:19:25.131+00	\N
341	entrada	2026-01-16 18:40:09.048+00	1	14	\N	5	\N	100	35	farmacia	532401	2026-01-16 18:40:09.048+00	2026-01-16 18:40:09.048+00	\N
342	entrada	2026-01-16 18:41:38.452+00	1	13	\N	1	\N	100	35	farmacia	29527132	2026-01-16 18:41:38.452+00	2026-01-16 18:41:38.452+00	\N
343	entrada	2026-01-16 18:47:24.191+00	1	\N	154	1	\N	1	35	farmacia	ER325050072	2026-01-16 18:47:24.192+00	2026-01-16 18:47:24.192+00	\N
344	entrada	2026-01-16 18:50:41.332+00	1	\N	153	1	\N	1	35	farmacia	ER325050072	2026-01-16 18:50:41.332+00	2026-01-16 18:50:41.332+00	\N
345	saida	2026-01-16 18:51:48.138+00	1	\N	154	1	\N	1	35	farmacia	ER325040332	2026-01-16 18:51:48.138+00	2026-01-16 18:51:48.138+00	\N
346	entrada	2026-01-16 18:53:23.237+00	1	\N	154	1	\N	1	35	enfermagem	EN325040332	2026-01-16 18:53:23.237+00	2026-01-16 18:53:23.237+00	\N
347	saida	2026-01-16 18:54:09.688+00	1	\N	153	1	\N	1	35	farmacia	ER325050072	2026-01-16 18:54:09.688+00	2026-01-16 18:54:09.688+00	\N
348	entrada	2026-01-16 18:56:33.27+00	1	\N	153	1	\N	1	35	enfermagem		2026-01-16 18:56:33.27+00	2026-01-16 18:56:33.27+00	\N
349	entrada	2026-01-16 19:07:14.959+00	1	\N	119	3	\N	1	20	farmacia	50030073	2026-01-16 19:07:14.959+00	2026-01-16 19:07:14.959+00	\N
350	entrada	2026-01-16 19:10:17.12+00	1	\N	27	1	\N	30	35	farmacia	BR183391	2026-01-16 19:10:17.12+00	2026-01-16 19:10:17.12+00	\N
351	entrada	2026-01-16 19:11:32.783+00	1	\N	80	1	\N	30	35	farmacia	120835	2026-01-16 19:11:32.784+00	2026-01-16 19:11:32.784+00	\N
352	entrada	2026-01-16 19:14:27.556+00	1	\N	55	1	\N	30	18	farmacia	258798	2026-01-16 19:14:27.556+00	2026-01-16 19:14:27.556+00	\N
353	entrada	2026-01-16 19:17:35.154+00	1	\N	16	1	\N	30	18	farmacia	PD0504	2026-01-16 19:17:35.154+00	2026-01-16 19:17:35.154+00	\N
354	entrada	2026-01-16 19:19:13.582+00	1	\N	135	1	\N	100	18	farmacia	242048	2026-01-16 19:19:13.582+00	2026-01-16 19:19:13.582+00	\N
355	entrada	2026-01-16 19:20:37.355+00	1	\N	35	1	\N	30	18	farmacia	0670/25M	2026-01-16 19:20:37.355+00	2026-01-16 19:20:37.355+00	\N
356	entrada	2026-01-16 19:22:31.889+00	1	\N	103	1	\N	36	18	farmacia	50508074	2026-01-16 19:22:31.889+00	2026-01-16 19:22:31.889+00	\N
357	entrada	2026-01-16 19:33:24.526+00	1	\N	155	1	\N	2	18	farmacia	24F286	2026-01-16 19:33:24.526+00	2026-01-16 19:33:24.526+00	\N
358	saida	2026-01-16 19:34:03.734+00	1	\N	155	1	\N	1	18	farmacia	24F286	2026-01-16 19:34:03.735+00	2026-01-16 19:34:03.735+00	\N
359	entrada	2026-01-16 19:50:47.544+00	1	\N	89	3	\N	110	36	farmacia	L25H2B6	2026-01-16 19:50:47.544+00	2026-01-16 19:50:47.544+00	\N
360	entrada	2026-01-16 19:53:06.42+00	1	\N	91	1	\N	40	36	farmacia	BLGM24003	2026-01-16 19:53:06.42+00	2026-01-16 19:53:06.42+00	\N
361	entrada	2026-01-16 19:54:33.401+00	1	\N	91	3	\N	10	36	farmacia	912528	2026-01-16 19:54:33.402+00	2026-01-16 19:54:33.402+00	\N
362	saida	2026-01-16 19:55:21.322+00	1	\N	91	1	\N	20	36	farmacia	BLGM24003	2026-01-16 19:55:21.322+00	2026-01-16 19:55:21.322+00	\N
363	saida	2026-01-16 19:56:11.399+00	1	\N	91	3	\N	10	36	farmacia	912528	2026-01-16 19:56:11.4+00	2026-01-16 19:56:11.4+00	\N
364	entrada	2026-01-16 20:04:44.4+00	1	\N	89	3	\N	20	36	farmacia	25H2B8	2026-01-16 20:04:44.4+00	2026-01-16 20:04:44.4+00	\N
365	transferencia	2026-01-16 20:09:55.703+00	1	\N	89	3	\N	20	36	enfermagem	25H2B8	2026-01-16 20:09:55.703+00	2026-01-16 20:09:55.703+00	\N
366	transferencia	2026-01-16 20:12:28.993+00	1	\N	91	3	\N	10	36	enfermagem	912528	2026-01-16 20:12:28.994+00	2026-01-16 20:12:28.994+00	\N
367	transferencia	2026-01-16 20:45:08.306+00	1	\N	119	3	\N	1	20	enfermagem	50030073	2026-01-16 20:45:08.306+00	2026-01-16 20:45:08.306+00	\N
368	entrada	2026-01-16 20:48:51.403+00	1	\N	123	3	\N	23	30	farmacia	50013432	2026-01-16 20:48:51.403+00	2026-01-16 20:48:51.403+00	\N
369	transferencia	2026-01-16 20:51:06.626+00	1	\N	123	3	\N	23	30	enfermagem	50013432	2026-01-16 20:51:06.626+00	2026-01-16 20:51:06.626+00	\N
370	entrada	2026-01-16 20:58:54.773+00	1	\N	64	3	\N	18	20	farmacia	50400733	2026-01-16 20:58:54.773+00	2026-01-16 20:58:54.773+00	\N
371	entrada	2026-01-16 21:00:25.745+00	1	\N	123	3	\N	16	20	farmacia	50308023	2026-01-16 21:00:25.746+00	2026-01-16 21:00:25.746+00	\N
372	entrada	2026-01-16 21:06:32.678+00	1	\N	125	3	\N	15	20	farmacia	5A7170	2026-01-16 21:06:32.678+00	2026-01-16 21:06:32.678+00	\N
373	transferencia	2026-01-16 21:09:03.7+00	1	\N	64	3	\N	18	20	enfermagem	50400733	2026-01-16 21:09:03.7+00	2026-01-16 21:09:03.7+00	\N
374	transferencia	2026-01-16 21:09:57.752+00	1	\N	125	3	\N	15	20	enfermagem	5A7170	2026-01-16 21:09:57.752+00	2026-01-16 21:09:57.752+00	\N
375	transferencia	2026-01-16 21:11:38.848+00	1	\N	123	3	\N	16	20	enfermagem	50308023	2026-01-16 21:11:38.848+00	2026-01-16 21:11:38.848+00	\N
376	transferencia	2026-01-16 21:14:17.352+00	1	\N	87	3	\N	12	8	enfermagem	\N	2026-01-16 21:14:17.352+00	2026-01-16 21:14:17.352+00	\N
377	transferencia	2026-01-16 21:16:21.36+00	1	\N	64	3	\N	15	9	enfermagem	\N	2026-01-16 21:16:21.361+00	2026-01-16 21:16:21.361+00	\N
378	entrada	2026-01-16 21:19:17.814+00	1	\N	123	3	\N	25	9	farmacia	50011722	2026-01-16 21:19:17.814+00	2026-01-16 21:19:17.814+00	\N
379	entrada	2026-01-16 21:21:26.65+00	1	\N	51	3	\N	45	9	farmacia	25070534	2026-01-16 21:21:26.65+00	2026-01-16 21:21:26.65+00	\N
380	transferencia	2026-01-16 21:24:16.02+00	1	\N	51	3	\N	15	9	enfermagem	25070534	2026-01-16 21:24:16.02+00	2026-01-16 21:24:16.02+00	\N
381	transferencia	2026-01-16 21:24:36.531+00	1	\N	51	3	\N	15	9	enfermagem	25070534	2026-01-16 21:24:36.531+00	2026-01-16 21:24:36.531+00	\N
382	transferencia	2026-01-16 21:25:38.814+00	1	\N	123	3	\N	25	9	enfermagem	50011722	2026-01-16 21:25:38.814+00	2026-01-16 21:25:38.814+00	\N
383	transferencia	2026-01-16 21:28:30.414+00	1	\N	71	3	\N	10	29	enfermagem	\N	2026-01-16 21:28:30.414+00	2026-01-16 21:28:30.414+00	\N
384	entrada	2026-01-16 21:37:13.241+00	1	\N	123	3	\N	30	23	farmacia	5B7085	2026-01-16 21:37:13.241+00	2026-01-16 21:37:13.241+00	\N
385	transferencia	2026-01-16 21:41:06.64+00	1	\N	123	3	\N	30	23	enfermagem	5B7085	2026-01-16 21:41:06.64+00	2026-01-16 21:41:06.64+00	\N
386	entrada	2026-01-16 21:43:30.023+00	1	\N	144	3	\N	10	23	farmacia	51411334	2026-01-16 21:43:30.023+00	2026-01-16 21:43:30.023+00	\N
387	entrada	2026-01-16 21:51:23.122+00	1	\N	156	3	\N	15	22	farmacia	41107863	2026-01-16 21:51:23.122+00	2026-01-16 21:51:23.122+00	\N
388	transferencia	2026-01-16 21:54:23.061+00	1	\N	64	1	\N	10	40	enfermagem	25F27T	2026-01-16 21:54:23.062+00	2026-01-16 21:54:23.062+00	\N
389	transferencia	2026-01-16 21:55:20.356+00	1	\N	156	3	\N	15	22	enfermagem	41107863	2026-01-16 21:55:20.356+00	2026-01-16 21:55:20.356+00	\N
390	entrada	2026-01-16 21:59:02.837+00	1	\N	51	3	\N	15	30	farmacia	927429	2026-01-16 21:59:02.837+00	2026-01-16 21:59:02.837+00	\N
391	transferencia	2026-01-16 22:04:29.393+00	1	\N	141	3	\N	10	40	enfermagem	LFKP07577	2026-01-16 22:04:29.393+00	2026-01-16 22:04:29.393+00	\N
392	transferencia	2026-01-16 22:05:26.378+00	1	\N	71	3	\N	14	40	enfermagem	\N	2026-01-16 22:05:26.378+00	2026-01-16 22:05:26.378+00	\N
393	entrada	2026-01-16 22:16:21.392+00	1	\N	158	3	\N	14	35	farmacia	240689	2026-01-16 22:16:21.392+00	2026-01-16 22:16:21.392+00	\N
394	entrada	2026-01-16 22:18:15.576+00	1	\N	157	3	\N	14	36	farmacia	240669	2026-01-16 22:18:15.576+00	2026-01-16 22:18:15.576+00	\N
395	entrada	2026-01-17 13:19:13.295+00	1	\N	24	1	\N	60	39	farmacia		2026-01-17 13:19:13.295+00	2026-01-17 13:19:13.295+00	\N
396	entrada	2026-01-17 13:21:04.736+00	1	\N	149	1	\N	60	\N	farmacia		2026-01-17 13:21:04.736+00	2026-01-17 13:21:04.736+00	\N
397	entrada	2026-01-17 13:24:40.876+00	1	\N	159	1	\N	60	39	farmacia		2026-01-17 13:24:40.876+00	2026-01-17 13:24:40.876+00	\N
398	entrada	2026-01-17 13:25:43.657+00	1	\N	29	1	\N	60	39	farmacia		2026-01-17 13:25:43.657+00	2026-01-17 13:25:43.657+00	\N
399	entrada	2026-01-17 13:26:58.894+00	1	\N	28	1	\N	30	39	farmacia		2026-01-17 13:26:58.894+00	2026-01-17 13:26:58.894+00	\N
400	entrada	2026-01-17 13:35:49.832+00	1	\N	49	1	\N	28	39	farmacia		2026-01-17 13:35:49.832+00	2026-01-17 13:35:49.832+00	\N
401	entrada	2026-01-17 13:38:04.612+00	1	\N	83	1	\N	15	39	farmacia		2026-01-17 13:38:04.612+00	2026-01-17 13:38:04.612+00	\N
402	entrada	2026-01-17 13:39:34.697+00	1	\N	149	1	\N	60	39	farmacia		2026-01-17 13:39:34.697+00	2026-01-17 13:39:34.697+00	\N
403	entrada	2026-01-17 13:41:23.356+00	1	\N	143	1	\N	60	39	farmacia		2026-01-17 13:41:23.356+00	2026-01-17 13:41:23.356+00	\N
404	entrada	2026-01-17 14:03:18.297+00	1	\N	24	1	\N	30	17	farmacia		2026-01-17 14:03:18.297+00	2026-01-17 14:03:18.297+00	\N
405	entrada	2026-01-17 14:04:10.247+00	1	\N	29	1	\N	30	17	farmacia		2026-01-17 14:04:10.247+00	2026-01-17 14:04:10.247+00	\N
406	entrada	2026-01-17 14:06:31.57+00	1	\N	30	2	\N	2	29	farmacia		2026-01-17 14:06:31.57+00	2026-01-17 14:06:31.57+00	\N
407	entrada	2026-01-17 14:10:05.968+00	1	\N	35	1	\N	28	14	farmacia		2026-01-17 14:10:05.968+00	2026-01-17 14:10:05.968+00	\N
408	entrada	2026-01-17 14:12:26.212+00	1	\N	160	1	\N	30	14	farmacia		2026-01-17 14:12:26.213+00	2026-01-17 14:12:26.213+00	\N
409	entrada	2026-01-17 14:13:40.448+00	1	\N	54	1	\N	20	14	farmacia		2026-01-17 14:13:40.448+00	2026-01-17 14:13:40.448+00	\N
410	entrada	2026-01-17 14:31:50.9+00	1	\N	51	3	\N	60	29	farmacia		2026-01-17 14:31:50.9+00	2026-01-17 14:31:50.9+00	\N
411	entrada	2026-01-17 14:35:45.797+00	1	\N	26	1	\N	4	26	farmacia		2026-01-17 14:35:45.797+00	2026-01-17 14:35:45.797+00	\N
412	entrada	2026-01-17 14:38:32.009+00	1	\N	143	1	\N	30	26	farmacia		2026-01-17 14:38:32.01+00	2026-01-17 14:38:32.01+00	\N
413	entrada	2026-01-17 14:42:43.192+00	1	\N	55	1	\N	30	19	farmacia		2026-01-17 14:42:43.192+00	2026-01-17 14:42:43.192+00	\N
414	entrada	2026-01-17 14:45:09.718+00	1	\N	35	1	\N	28	19	farmacia		2026-01-17 14:45:09.718+00	2026-01-17 14:45:09.718+00	\N
415	entrada	2026-01-17 14:48:05.59+00	1	\N	34	2	\N	10	\N	farmacia	0784/25	2026-01-17 14:48:05.59+00	2026-01-17 14:48:05.59+00	\N
416	entrada	2026-01-17 14:49:43.064+00	1	\N	61	1	\N	2	\N	farmacia	114326	2026-01-17 14:49:43.064+00	2026-01-17 14:49:43.064+00	\N
417	transferencia	2026-01-17 14:51:07.705+00	1	\N	61	1	\N	2	5	enfermagem	\N	2026-01-17 14:51:07.705+00	2026-01-17 14:51:07.705+00	\N
418	transferencia	2026-01-17 14:56:45.305+00	1	\N	34	2	\N	4	7	enfermagem	0784/25	2026-01-17 14:56:45.305+00	2026-01-17 14:56:45.305+00	\N
419	entrada	2026-01-17 15:00:41.612+00	1	\N	18	1	\N	30	24	farmacia	25J065	2026-01-17 15:00:41.613+00	2026-01-17 15:00:41.613+00	\N
420	entrada	2026-01-17 15:03:52.819+00	1	\N	35	1	\N	56	28	farmacia		2026-01-17 15:03:52.819+00	2026-01-17 15:03:52.819+00	\N
421	entrada	2026-01-17 15:05:33.653+00	1	\N	143	1	\N	30	28	farmacia	\N	2026-01-17 15:05:33.654+00	2026-01-17 15:05:33.654+00	\N
422	entrada	2026-01-17 15:10:51.622+00	1	\N	35	1	\N	28	4	farmacia	L:0670/25	2026-01-17 15:10:51.622+00	2026-01-17 15:10:51.622+00	\N
423	entrada	2026-01-17 15:12:49.701+00	1	\N	35	1	\N	20	3	farmacia		2026-01-17 15:12:49.701+00	2026-01-17 15:12:49.701+00	\N
424	transferencia	2026-01-17 15:14:41.127+00	1	\N	35	1	\N	20	3	enfermagem		2026-01-17 15:14:41.127+00	2026-01-17 15:14:41.127+00	\N
425	transferencia	2026-01-17 15:15:00.659+00	1	\N	35	1	\N	28	4	enfermagem	L:0670/25	2026-01-17 15:15:00.659+00	2026-01-17 15:15:00.659+00	\N
426	entrada	2026-01-17 15:21:23.969+00	1	\N	161	3	\N	10	11	farmacia	50029446	2026-01-17 15:21:23.969+00	2026-01-17 15:21:23.969+00	\N
427	entrada	2026-01-17 15:52:57.702+00	1	16	\N	6	\N	6	\N	farmacia	862822	2026-01-17 15:52:57.702+00	2026-01-17 15:52:57.702+00	\N
428	entrada	2026-01-17 15:58:26.68+00	1	18	\N	5	\N	24	\N	farmacia	2508010025	2026-01-17 15:58:26.68+00	2026-01-17 15:58:26.68+00	\N
429	entrada	2026-01-19 12:47:30.479+00	1	\N	122	3	\N	10	25	farmacia	2114489	2026-01-19 12:47:30.479+00	2026-01-19 12:47:30.479+00	\N
430	transferencia	2026-01-19 12:49:48.49+00	1	\N	122	1	\N	10	25	enfermagem	\N	2026-01-19 12:49:48.49+00	2026-01-19 12:49:48.49+00	\N
431	saida	2026-01-19 13:02:47.703+00	1	\N	71	6	\N	20	\N	farmacia	\N	2026-01-19 13:02:47.703+00	2026-01-19 13:02:47.703+00	\N
432	entrada	2026-01-19 13:04:06.14+00	1	\N	71	3	\N	20	14	farmacia	C2416778	2026-01-19 13:04:06.14+00	2026-01-19 13:04:06.14+00	\N
433	transferencia	2026-01-19 13:05:14.571+00	1	\N	130	2	\N	1	23	enfermagem	\N	2026-01-19 13:05:14.572+00	2026-01-19 13:05:14.572+00	\N
434	saida	2026-01-19 13:14:02.359+00	1	\N	71	3	\N	10	14	farmacia	C2416778	2026-01-19 13:14:02.359+00	2026-01-19 13:14:02.359+00	\N
435	saida	2026-01-19 13:23:25.453+00	1	\N	71	3	\N	10	25	farmacia	\N	2026-01-19 13:23:25.453+00	2026-01-19 13:23:25.453+00	\N
436	entrada	2026-01-19 13:25:52.1+00	1	\N	64	3	\N	60	25	farmacia	25ES3S	2026-01-19 13:25:52.1+00	2026-01-19 13:25:52.1+00	\N
437	saida	2026-01-19 13:26:26.492+00	1	\N	64	3	\N	20	25	farmacia	25ES3S	2026-01-19 13:26:26.492+00	2026-01-19 13:26:26.492+00	\N
438	entrada	2026-01-19 13:28:11.954+00	1	\N	123	3	\N	30	25	farmacia	50022743	2026-01-19 13:28:11.954+00	2026-01-19 13:28:11.954+00	\N
439	saida	2026-01-19 13:29:04.563+00	1	\N	64	3	\N	30	25	farmacia	25ES3S	2026-01-19 13:29:04.563+00	2026-01-19 13:29:04.563+00	\N
440	saida	2026-01-19 13:48:23.982+00	1	\N	93	1	\N	15	42	farmacia	\N	2026-01-19 13:48:23.982+00	2026-01-19 13:48:23.982+00	\N
441	transferencia	2026-01-19 13:52:14.14+00	1	\N	92	1	\N	15	42	enfermagem	\N	2026-01-19 13:52:14.14+00	2026-01-19 13:52:14.14+00	\N
442	saida	2026-01-19 13:53:42.87+00	1	\N	58	1	\N	20	28	farmacia	\N	2026-01-19 13:53:42.87+00	2026-01-19 13:53:42.87+00	\N
443	saida	2026-01-19 13:54:38.95+00	1	\N	74	1	\N	15	1	farmacia	\N	2026-01-19 13:54:38.95+00	2026-01-19 13:54:38.95+00	\N
444	entrada	2026-01-19 14:26:14.941+00	1	\N	162	3	\N	30	30	farmacia	104790	2026-01-19 14:26:14.941+00	2026-01-19 14:26:14.941+00	\N
445	transferencia	2026-01-19 14:32:25.766+00	1	\N	162	3	\N	10	30	enfermagem	104790	2026-01-19 14:32:25.766+00	2026-01-19 14:32:25.766+00	\N
446	transferencia	2026-01-19 14:49:44.357+00	1	\N	50	6	\N	6	30	enfermagem	900356	2026-01-19 14:49:44.357+00	2026-01-19 14:49:44.357+00	\N
447	transferencia	2026-01-19 14:50:06.418+00	1	\N	50	6	\N	8	30	enfermagem	900356	2026-01-19 14:50:06.418+00	2026-01-19 14:50:06.418+00	\N
448	transferencia	2026-01-19 14:57:34.538+00	1	\N	26	1	\N	5	1	enfermagem	\N	2026-01-19 14:57:34.538+00	2026-01-19 14:57:34.538+00	\N
449	transferencia	2026-01-19 14:59:57.399+00	1	\N	44	1	\N	23	1	enfermagem	\N	2026-01-19 14:59:57.399+00	2026-01-19 14:59:57.399+00	\N
450	entrada	2026-01-19 15:03:53.302+00	1	\N	44	1	\N	30	2	farmacia	17192	2026-01-19 15:03:53.303+00	2026-01-19 15:03:53.303+00	\N
451	transferencia	2026-01-19 15:04:24.619+00	1	\N	44	1	\N	25	2	enfermagem	17192	2026-01-19 15:04:24.619+00	2026-01-19 15:04:24.619+00	\N
452	entrada	2026-01-19 15:09:39.531+00	1	\N	27	1	\N	51	2	farmacia	BR181039	2026-01-19 15:09:39.532+00	2026-01-19 15:09:39.532+00	\N
453	transferencia	2026-01-19 15:13:17.994+00	1	\N	27	1	\N	21	2	enfermagem	BR181039	2026-01-19 15:13:17.994+00	2026-01-19 15:13:17.994+00	\N
454	transferencia	2026-01-19 15:16:39.928+00	1	\N	27	1	\N	15	2	enfermagem	BR181039	2026-01-19 15:16:39.929+00	2026-01-19 15:16:39.929+00	\N
455	transferencia	2026-01-19 15:17:47.464+00	1	\N	27	1	\N	15	3	enfermagem	\N	2026-01-19 15:17:47.464+00	2026-01-19 15:17:47.464+00	\N
456	entrada	2026-01-19 15:22:16.902+00	1	\N	24	1	\N	51	6	farmacia		2026-01-19 15:22:16.903+00	2026-01-19 15:22:16.903+00	\N
457	transferencia	2026-01-19 15:23:21.085+00	1	\N	24	1	\N	11	6	enfermagem		2026-01-19 15:23:21.085+00	2026-01-19 15:23:21.085+00	\N
458	entrada	2026-01-19 15:25:57.304+00	1	\N	24	1	\N	25	7	farmacia		2026-01-19 15:25:57.305+00	2026-01-19 15:25:57.305+00	\N
459	transferencia	2026-01-19 15:26:59.872+00	1	\N	24	1	\N	15	7	enfermagem		2026-01-19 15:26:59.872+00	2026-01-19 15:26:59.872+00	\N
460	entrada	2026-01-19 15:30:38.532+00	1	\N	163	1	\N	64	8	farmacia	4Y9621	2026-01-19 15:30:38.533+00	2026-01-19 15:30:38.533+00	\N
461	transferencia	2026-01-19 15:32:04.86+00	1	\N	163	1	\N	19	8	enfermagem	4Y9621	2026-01-19 15:32:04.86+00	2026-01-19 15:32:04.86+00	\N
462	transferencia	2026-01-19 15:32:49.041+00	1	\N	115	1	\N	1	7	enfermagem	\N	2026-01-19 15:32:49.041+00	2026-01-19 15:32:49.041+00	\N
463	entrada	2026-01-19 15:36:16.873+00	1	\N	44	1	\N	20	9	farmacia		2026-01-19 15:36:16.873+00	2026-01-19 15:36:16.873+00	\N
464	saida	2026-01-19 16:17:46.168+00	1	\N	24	1	\N	23	13	farmacia	\N	2026-01-19 16:17:46.168+00	2026-01-19 16:17:46.168+00	\N
465	transferencia	2026-01-19 16:28:08.474+00	1	\N	58	1	\N	20	26	enfermagem	\N	2026-01-19 16:28:08.474+00	2026-01-19 16:28:08.474+00	\N
466	entrada	2026-01-19 16:33:01.058+00	1	\N	43	1	\N	30	35	farmacia	6H0819	2026-01-19 16:33:01.058+00	2026-01-19 16:33:01.058+00	\N
467	transferencia	2026-01-19 16:35:23.016+00	1	\N	43	1	\N	15	35	enfermagem	6H0819	2026-01-19 16:35:23.017+00	2026-01-19 16:35:23.017+00	\N
468	transferencia	2026-01-19 16:38:20.263+00	1	\N	33	3	\N	15	29	enfermagem	\N	2026-01-19 16:38:20.263+00	2026-01-19 16:38:20.263+00	\N
469	entrada	2026-01-19 19:29:31.439+00	1	\N	73	1	\N	60	2	farmacia	B24J2421	2026-01-19 19:29:31.439+00	2026-01-19 19:29:31.439+00	\N
470	entrada	2026-01-19 19:31:50.159+00	1	\N	74	1	\N	25	2	farmacia	BR176466	2026-01-19 19:31:50.16+00	2026-01-19 19:31:50.16+00	\N
471	entrada	2026-01-19 19:34:27.48+00	1	\N	54	1	\N	20	2	farmacia	1577/24M	2026-01-19 19:34:27.48+00	2026-01-19 19:34:27.48+00	\N
472	entrada	2026-01-19 19:39:46.335+00	1	\N	106	1	\N	60	2	farmacia	50020777	2026-01-19 19:39:46.335+00	2026-01-19 19:39:46.335+00	\N
473	entrada	2026-01-19 19:42:13.394+00	1	\N	18	1	\N	30	2	farmacia	L25J065	2026-01-19 19:42:13.394+00	2026-01-19 19:42:13.394+00	\N
474	entrada	2026-01-19 19:48:36.851+00	1	\N	35	1	\N	56	2	farmacia		2026-01-19 19:48:36.851+00	2026-01-19 19:48:36.851+00	\N
475	entrada	2026-01-19 19:54:49.769+00	1	\N	164	3	\N	6	19	farmacia	2508414	2026-01-19 19:54:49.769+00	2026-01-19 19:54:49.769+00	\N
476	entrada	2026-01-19 19:58:22.602+00	1	\N	140	3	\N	60	19	farmacia	50020767	2026-01-19 19:58:22.602+00	2026-01-19 19:58:22.602+00	\N
477	entrada	2026-01-19 20:00:21.847+00	1	\N	106	1	\N	30	19	farmacia		2026-01-19 20:00:21.848+00	2026-01-19 20:00:21.848+00	\N
478	entrada	2026-01-19 20:03:46.764+00	1	\N	106	1	\N	30	2	farmacia		2026-01-19 20:03:46.765+00	2026-01-19 20:03:46.765+00	\N
479	entrada	2026-01-19 20:09:04.402+00	1	\N	161	4	\N	2	2	farmacia		2026-01-19 20:09:04.402+00	2026-01-19 20:09:04.402+00	\N
480	entrada	2026-01-19 20:09:52.473+00	1	\N	115	1	\N	1	2	farmacia		2026-01-19 20:09:52.473+00	2026-01-19 20:09:52.473+00	\N
481	entrada	2026-01-19 20:11:36.363+00	1	\N	111	3	\N	30	42	farmacia	L25G19J	2026-01-19 20:11:36.363+00	2026-01-19 20:11:36.363+00	\N
482	transferencia	2026-01-19 20:25:45.969+00	1	18	\N	5	\N	12	2	enfermagem	2508010025	2026-01-19 20:25:45.969+00	2026-01-19 20:25:45.969+00	\N
483	entrada	2026-01-19 20:28:17.955+00	1	\N	23	2	\N	1	\N	farmacia	1218422	2026-01-19 20:28:17.955+00	2026-01-19 20:28:17.955+00	\N
484	transferencia	2026-01-19 20:29:36.132+00	1	\N	74	1	\N	25	2	enfermagem	BR176466	2026-01-19 20:29:36.133+00	2026-01-19 20:29:36.133+00	\N
485	entrada	2026-01-19 20:33:11.756+00	1	\N	165	7	\N	28	\N	farmacia	1120070	2026-01-19 20:33:11.756+00	2026-01-19 20:33:11.756+00	\N
486	entrada	2026-01-19 20:34:46.01+00	1	\N	35	6	\N	28	\N	farmacia		2026-01-19 20:34:46.01+00	2026-01-19 20:34:46.01+00	\N
487	transferencia	2026-01-19 20:37:03.644+00	1	\N	35	6	\N	28	11	enfermagem		2026-01-19 20:37:03.644+00	2026-01-19 20:37:03.644+00	\N
488	transferencia	2026-01-20 12:35:49.504+00	1	\N	39	1	\N	14	33	enfermagem	\N	2026-01-20 12:35:49.504+00	2026-01-20 12:35:49.504+00	\N
489	entrada	2026-01-20 12:37:38.884+00	1	\N	144	1	\N	30	38	farmacia	1542/24M	2026-01-20 12:37:38.885+00	2026-01-20 12:37:38.885+00	\N
490	transferencia	2026-01-20 12:44:12.555+00	1	\N	144	1	\N	10	38	enfermagem	1542/24M	2026-01-20 12:44:12.555+00	2026-01-20 12:44:12.555+00	\N
491	entrada	2026-01-20 12:54:15.242+00	1	\N	83	1	\N	30	\N	farmacia	3025371	2026-01-20 12:54:15.243+00	2026-01-20 12:54:15.243+00	\N
492	transferencia	2026-01-20 12:55:22.252+00	1	\N	83	1	\N	15	29	enfermagem	3025371	2026-01-20 12:55:22.252+00	2026-01-20 12:55:22.252+00	\N
493	entrada	2026-01-20 12:59:35.693+00	1	\N	139	3	\N	40	19	farmacia	240370	2026-01-20 12:59:35.693+00	2026-01-20 12:59:35.693+00	\N
494	transferencia	2026-01-20 13:00:01.523+00	1	\N	139	3	\N	20	19	enfermagem	240370	2026-01-20 13:00:01.523+00	2026-01-20 13:00:01.523+00	\N
495	entrada	2026-01-20 13:06:27.932+00	1	\N	125	3	\N	120	38	farmacia	50025076	2026-01-20 13:06:27.932+00	2026-01-20 13:06:27.932+00	\N
496	entrada	2026-01-20 13:35:47.909+00	1	\N	166	7	\N	15	\N	farmacia	25E25V	2026-01-20 13:35:47.909+00	2026-01-20 13:35:47.909+00	\N
497	transferencia	2026-01-20 13:37:00.994+00	1	\N	166	7	\N	15	11	enfermagem	25E25V	2026-01-20 13:37:00.995+00	2026-01-20 13:37:00.995+00	\N
498	transferencia	2026-01-20 13:37:26.577+00	1	\N	166	7	\N	15	8	enfermagem	25E25V	2026-01-20 13:37:26.577+00	2026-01-20 13:37:26.577+00	\N
499	entrada	2026-01-20 13:39:38.167+00	1	\N	160	2	\N	40	\N	farmacia	24I0210	2026-01-20 13:39:38.167+00	2026-01-20 13:39:38.167+00	\N
500	transferencia	2026-01-20 13:40:05.134+00	1	\N	160	2	\N	20	11	enfermagem	24I0210	2026-01-20 13:40:05.134+00	2026-01-20 13:40:05.134+00	\N
501	transferencia	2026-01-20 13:40:47.629+00	1	\N	160	2	\N	20	42	enfermagem	24I0210	2026-01-20 13:40:47.63+00	2026-01-20 13:40:47.63+00	\N
502	transferencia	2026-01-20 13:42:55.609+00	1	\N	76	1	\N	1	11	enfermagem	\N	2026-01-20 13:42:55.61+00	2026-01-20 13:42:55.61+00	\N
503	entrada	2026-01-20 13:44:45.53+00	1	\N	26	1	\N	4	11	farmacia	25002	2026-01-20 13:44:45.53+00	2026-01-20 13:44:45.53+00	\N
504	transferencia	2026-01-20 13:45:08.877+00	1	\N	26	1	\N	4	11	enfermagem	25002	2026-01-20 13:45:08.877+00	2026-01-20 13:45:08.877+00	\N
505	entrada	2026-01-20 14:01:23.362+00	1	\N	155	1	\N	1	\N	farmacia	0031675	2026-01-20 14:01:23.362+00	2026-01-20 14:01:23.362+00	\N
506	entrada	2026-01-20 14:05:03.549+00	1	\N	155	1	\N	2	\N	farmacia	0025880	2026-01-20 14:05:03.549+00	2026-01-20 14:05:03.549+00	\N
507	entrada	2026-01-20 14:09:32.939+00	1	\N	155	1	\N	11	\N	farmacia	DS24I440	2026-01-20 14:09:32.939+00	2026-01-20 14:09:32.939+00	\N
508	entrada	2026-01-20 14:11:58.729+00	1	\N	155	1	\N	10	\N	farmacia	DS24J452	2026-01-20 14:11:58.73+00	2026-01-20 14:11:58.73+00	\N
509	entrada	2026-01-20 14:12:49.858+00	1	\N	155	1	\N	1	\N	farmacia	0025795	2026-01-20 14:12:49.858+00	2026-01-20 14:12:49.858+00	\N
510	entrada	2026-01-20 18:14:58.707+00	1	\N	59	1	\N	20	19	farmacia	250406	2026-01-20 18:14:58.707+00	2026-01-20 18:14:58.707+00	\N
511	transferencia	2026-01-20 18:15:36.509+00	1	\N	59	1	\N	20	19	enfermagem	250406	2026-01-20 18:15:36.509+00	2026-01-20 18:15:36.509+00	\N
512	entrada	2026-01-20 18:19:42.673+00	1	\N	103	3	\N	36	18	farmacia	50508074	2026-01-20 18:19:42.673+00	2026-01-20 18:19:42.673+00	\N
513	transferencia	2026-01-20 18:21:38.788+00	1	\N	90	3	\N	18	26	enfermagem	\N	2026-01-20 18:21:38.788+00	2026-01-20 18:21:38.788+00	\N
514	transferencia	2026-01-20 18:22:04.233+00	1	\N	91	3	\N	20	26	enfermagem	\N	2026-01-20 18:22:04.234+00	2026-01-20 18:22:04.234+00	\N
515	entrada	2026-01-20 18:23:52.677+00	1	\N	103	3	\N	6	14	farmacia	2510824	2026-01-20 18:23:52.677+00	2026-01-20 18:23:52.677+00	\N
516	entrada	2026-01-20 18:25:20.444+00	1	\N	46	2	\N	6	26	farmacia	5C3338	2026-01-20 18:25:20.444+00	2026-01-20 18:25:20.444+00	\N
517	entrada	2026-01-20 18:45:30.063+00	1	\N	55	1	\N	30	24	farmacia	24G09V	2026-01-20 18:45:30.064+00	2026-01-20 18:45:30.064+00	\N
518	transferencia	2026-01-20 18:45:50.221+00	1	\N	55	1	\N	20	24	enfermagem	24G09V	2026-01-20 18:45:50.221+00	2026-01-20 18:45:50.221+00	\N
519	entrada	2026-01-20 18:50:18.64+00	1	\N	149	1	\N	60	20	farmacia	2516635	2026-01-20 18:50:18.641+00	2026-01-20 18:50:18.641+00	\N
520	entrada	2026-01-20 18:54:44.311+00	1	\N	80	1	\N	30	20	farmacia	141835	2026-01-20 18:54:44.311+00	2026-01-20 18:54:44.311+00	\N
521	entrada	2026-01-20 18:55:44.494+00	1	\N	102	1	\N	30	20	farmacia	B25G2207	2026-01-20 18:55:44.494+00	2026-01-20 18:55:44.494+00	\N
522	entrada	2026-01-20 18:56:48.585+00	1	\N	29	1	\N	60	20	farmacia	5C5802	2026-01-20 18:56:48.586+00	2026-01-20 18:56:48.586+00	\N
523	entrada	2026-01-20 18:58:51.054+00	1	\N	16	1	\N	30	20	farmacia	PD0504	2026-01-20 18:58:51.054+00	2026-01-20 18:58:51.054+00	\N
524	entrada	2026-01-20 19:07:06.393+00	1	\N	167	1	\N	30	20	farmacia	M502427	2026-01-20 19:07:06.394+00	2026-01-20 19:07:06.394+00	\N
525	entrada	2026-01-20 19:08:19.914+00	1	\N	64	3	\N	60	20	farmacia	50502483	2026-01-20 19:08:19.914+00	2026-01-20 19:08:19.914+00	\N
526	entrada	2026-01-20 19:09:40.133+00	1	\N	125	1	\N	30	20	farmacia	2111415	2026-01-20 19:09:40.133+00	2026-01-20 19:09:40.133+00	\N
527	entrada	2026-01-20 19:11:16.699+00	1	\N	123	1	\N	30	20	farmacia	EKP14448	2026-01-20 19:11:16.7+00	2026-01-20 19:11:16.7+00	\N
528	entrada	2026-01-20 19:50:42.757+00	1	\N	168	1	\N	10	8	farmacia	3X7039	2026-01-20 19:50:42.758+00	2026-01-20 19:50:42.758+00	\N
529	entrada	2026-01-20 19:52:12.949+00	1	\N	168	1	\N	30	8	farmacia	3Z2601	2026-01-20 19:52:12.949+00	2026-01-20 19:52:12.949+00	\N
530	transferencia	2026-01-20 19:52:47.162+00	1	\N	168	1	\N	10	8	enfermagem	3X7039	2026-01-20 19:52:47.162+00	2026-01-20 19:52:47.162+00	\N
531	entrada	2026-01-20 20:05:15.707+00	1	\N	113	1	\N	30	4	farmacia	5002104	2026-01-20 20:05:15.708+00	2026-01-20 20:05:15.708+00	\N
532	transferencia	2026-01-20 20:05:45.133+00	1	\N	113	1	\N	14	4	enfermagem	5002104	2026-01-20 20:05:45.133+00	2026-01-20 20:05:45.133+00	\N
533	entrada	2026-01-20 20:07:34.536+00	1	\N	125	3	\N	30	4	farmacia	50025076	2026-01-20 20:07:34.536+00	2026-01-20 20:07:34.536+00	\N
534	transferencia	2026-01-20 20:08:22.342+00	1	\N	125	3	\N	14	4	enfermagem	50025076	2026-01-20 20:08:22.343+00	2026-01-20 20:08:22.343+00	\N
535	transferencia	2026-01-20 20:14:33.813+00	1	\N	87	3	\N	13	15	enfermagem	\N	2026-01-20 20:14:33.813+00	2026-01-20 20:14:33.813+00	\N
536	entrada	2026-01-20 20:16:47.078+00	1	\N	64	3	\N	30	15	farmacia		2026-01-20 20:16:47.078+00	2026-01-20 20:16:47.078+00	\N
537	entrada	2026-01-20 20:18:00.244+00	1	\N	119	3	\N	1	15	farmacia	50030073	2026-01-20 20:18:00.244+00	2026-01-20 20:18:00.244+00	\N
538	entrada	2026-01-20 20:49:55.753+00	1	\N	125	3	\N	17	16	farmacia	50018811	2026-01-20 20:49:55.753+00	2026-01-20 20:49:55.753+00	\N
539	transferencia	2026-01-20 20:50:51.857+00	1	\N	125	3	\N	17	16	enfermagem	5000188811	2026-01-20 20:50:51.857+00	2026-01-20 20:50:51.857+00	\N
540	entrada	2026-01-20 20:53:17.03+00	1	\N	111	3	\N	68	17	farmacia	25C45P	2026-01-20 20:53:17.03+00	2026-01-20 20:53:17.03+00	\N
541	transferencia	2026-01-20 20:53:45.943+00	1	\N	111	3	\N	28	17	enfermagem	25C45P	2026-01-20 20:53:45.943+00	2026-01-20 20:53:45.943+00	\N
542	transferencia	2026-01-20 20:57:36.363+00	1	\N	140	3	\N	14	19	enfermagem	50020767	2026-01-20 20:57:36.363+00	2026-01-20 20:57:36.363+00	\N
543	entrada	2026-01-20 21:06:34.555+00	1	\N	125	3	\N	110	24	farmacia	50016175	2026-01-20 21:06:34.555+00	2026-01-20 21:06:34.555+00	\N
544	transferencia	2026-01-20 21:07:10.81+00	1	\N	125	3	\N	23	24	enfermagem	50016175	2026-01-20 21:07:10.81+00	2026-01-20 21:07:10.81+00	\N
545	entrada	2026-01-20 21:12:45.821+00	1	\N	140	3	\N	20	29	farmacia	50023281	2026-01-20 21:12:45.822+00	2026-01-20 21:12:45.822+00	\N
546	transferencia	2026-01-20 21:13:10.84+00	1	\N	140	3	\N	10	29	enfermagem	50023281	2026-01-20 21:13:10.84+00	2026-01-20 21:13:10.84+00	\N
547	transferencia	2026-01-20 21:15:14.573+00	1	\N	64	3	\N	14	29	enfermagem	\N	2026-01-20 21:15:14.573+00	2026-01-20 21:15:14.573+00	\N
548	transferencia	2026-01-20 21:17:44.984+00	1	\N	71	3	\N	14	29	enfermagem	\N	2026-01-20 21:17:44.984+00	2026-01-20 21:17:44.984+00	\N
549	entrada	2026-01-20 21:19:40.606+00	1	\N	51	3	\N	37	29	farmacia	25070534	2026-01-20 21:19:40.606+00	2026-01-20 21:19:40.606+00	\N
550	transferencia	2026-01-20 21:21:25.272+00	1	\N	51	3	\N	22	29	enfermagem		2026-01-20 21:21:25.273+00	2026-01-20 21:21:25.273+00	\N
551	entrada	2026-01-20 21:25:28.705+00	1	\N	100	3	\N	10	34	farmacia	PP0403	2026-01-20 21:25:28.705+00	2026-01-20 21:25:28.705+00	\N
552	transferencia	2026-01-20 21:26:12.472+00	1	\N	100	3	\N	10	34	enfermagem	PP0403	2026-01-20 21:26:12.472+00	2026-01-20 21:26:12.472+00	\N
553	transferencia	2026-01-20 21:26:47.787+00	1	\N	100	3	\N	10	34	enfermagem	\N	2026-01-20 21:26:47.787+00	2026-01-20 21:26:47.787+00	\N
554	entrada	2026-01-20 21:30:26.496+00	1	\N	125	3	\N	69	35	farmacia	50023328A	2026-01-20 21:30:26.496+00	2026-01-20 21:30:26.496+00	\N
555	transferencia	2026-01-20 21:33:13.258+00	1	\N	125	3	\N	21	35	enfermagem	50023328A	2026-01-20 21:33:13.258+00	2026-01-20 21:33:13.258+00	\N
556	entrada	2026-01-20 21:36:19.566+00	1	\N	100	3	\N	36	35	farmacia	PP0403	2026-01-20 21:36:19.566+00	2026-01-20 21:36:19.566+00	\N
557	transferencia	2026-01-20 21:37:00.926+00	1	\N	100	3	\N	16	35	enfermagem	PP0403	2026-01-20 21:37:00.926+00	2026-01-20 21:37:00.926+00	\N
558	transferencia	2026-01-20 21:40:29.059+00	1	\N	91	1	\N	10	36	enfermagem	BLGM24003	2026-01-20 21:40:29.059+00	2026-01-20 21:40:29.059+00	\N
559	transferencia	2026-01-20 21:42:45.683+00	1	\N	64	1	\N	10	40	enfermagem	25F27T	2026-01-20 21:42:45.683+00	2026-01-20 21:42:45.683+00	\N
560	entrada	2026-01-20 21:44:26.853+00	1	\N	156	3	\N	23	40	farmacia	50016416	2026-01-20 21:44:26.853+00	2026-01-20 21:44:26.853+00	\N
561	entrada	2026-01-20 21:45:32.558+00	1	\N	156	3	\N	10	40	farmacia	5A5309	2026-01-20 21:45:32.558+00	2026-01-20 21:45:32.558+00	\N
562	transferencia	2026-01-20 21:45:58.136+00	1	\N	156	3	\N	13	40	enfermagem	50016416	2026-01-20 21:45:58.136+00	2026-01-20 21:45:58.136+00	\N
563	entrada	2026-01-21 13:04:59.765+00	1	\N	40	1	\N	15	27	farmacia	$N8841	2026-01-21 13:04:59.765+00	2026-01-21 13:04:59.765+00	\N
564	transferencia	2026-01-21 13:06:06.041+00	1	\N	40	1	\N	15	27	enfermagem	$N8841	2026-01-21 13:06:06.041+00	2026-01-21 13:06:06.041+00	\N
565	entrada	2026-01-21 13:15:58.247+00	1	\N	169	1	\N	25	39	farmacia		2026-01-21 13:15:58.247+00	2026-01-21 13:15:58.247+00	\N
566	transferencia	2026-01-21 13:16:32.648+00	1	\N	169	1	\N	15	39	enfermagem		2026-01-21 13:16:32.648+00	2026-01-21 13:16:32.648+00	\N
567	entrada	2026-01-21 13:31:14.905+00	1	\N	73	1	\N	12	16	farmacia	B24J2421	2026-01-21 13:31:14.905+00	2026-01-21 13:31:14.905+00	\N
568	transferencia	2026-01-21 13:33:21.678+00	1	\N	73	1	\N	24	2	enfermagem	B24J2421	2026-01-21 13:33:21.678+00	2026-01-21 13:33:21.678+00	\N
569	transferencia	2026-01-21 15:08:16.888+00	1	\N	37	1	\N	28	6	enfermagem	\N	2026-01-21 15:08:16.889+00	2026-01-21 15:08:16.889+00	\N
570	entrada	2026-01-21 15:09:38.553+00	1	\N	37	1	\N	30	6	farmacia	502203	2026-01-21 15:09:38.553+00	2026-01-21 15:09:38.553+00	\N
571	transferencia	2026-01-21 15:11:39.019+00	1	\N	37	1	\N	20	6	enfermagem	502203	2026-01-21 15:11:39.02+00	2026-01-21 15:11:39.02+00	\N
572	transferencia	2026-01-21 16:30:51.94+00	1	\N	115	1	\N	2	8	enfermagem	\N	2026-01-21 16:30:51.94+00	2026-01-21 16:30:51.94+00	\N
573	transferencia	2026-01-21 16:52:06.771+00	1	\N	46	2	\N	1	26	enfermagem	5C3338	2026-01-21 16:52:06.772+00	2026-01-21 16:52:06.772+00	\N
574	entrada	2026-01-21 17:03:33.159+00	1	\N	171	1	\N	10	38	farmacia	0957/25M	2026-01-21 17:03:33.159+00	2026-01-21 17:03:33.159+00	\N
575	entrada	2026-01-21 17:18:34.728+00	1	\N	46	1	\N	1	38	farmacia	5C3338	2026-01-21 17:18:34.728+00	2026-01-21 17:18:34.728+00	\N
576	transferencia	2026-01-21 17:18:55.539+00	1	\N	46	1	\N	1	38	enfermagem	5C3338	2026-01-21 17:18:55.539+00	2026-01-21 17:18:55.539+00	\N
577	entrada	2026-01-21 17:58:25.456+00	1	\N	26	1	\N	4	11	farmacia	25086	2026-01-21 17:58:25.456+00	2026-01-21 17:58:25.456+00	\N
578	entrada	2026-01-21 18:02:12.35+00	1	\N	166	7	\N	28	11	farmacia	B24J0766	2026-01-21 18:02:12.35+00	2026-01-21 18:02:12.35+00	\N
579	entrada	2026-01-21 18:05:21.817+00	1	\N	111	3	\N	90	34	farmacia	25G19J	2026-01-21 18:05:21.818+00	2026-01-21 18:05:21.818+00	\N
580	entrada	2026-01-21 18:15:38.85+00	1	\N	172	1	\N	180	26	farmacia	DFF8251A	2026-01-21 18:15:38.851+00	2026-01-21 18:15:38.851+00	\N
581	entrada	2026-01-21 18:22:08.134+00	1	\N	160	1	\N	60	42	farmacia	1740214	2026-01-21 18:22:08.134+00	2026-01-21 18:22:08.134+00	\N
582	entrada	2026-01-21 18:25:47.503+00	1	\N	172	3	\N	180	19	farmacia	DFF8251A	2026-01-21 18:25:47.503+00	2026-01-21 18:25:47.503+00	\N
583	transferencia	2026-01-21 18:26:10.143+00	1	\N	172	1	\N	55	26	enfermagem	DFF8251A	2026-01-21 18:26:10.143+00	2026-01-21 18:26:10.143+00	\N
584	transferencia	2026-01-21 18:26:21.696+00	1	\N	172	3	\N	55	19	enfermagem	DFF8251A	2026-01-21 18:26:21.696+00	2026-01-21 18:26:21.696+00	\N
585	entrada	2026-01-21 18:40:07.55+00	1	\N	160	1	\N	30	11	farmacia	IT40214	2026-01-21 18:40:07.55+00	2026-01-21 18:40:07.55+00	\N
586	entrada	2026-01-21 18:42:43.503+00	1	\N	32	3	\N	30	24	farmacia	2517054	2026-01-21 18:42:43.503+00	2026-01-21 18:42:43.503+00	\N
587	entrada	2026-01-21 18:44:39.624+00	1	\N	31	3	\N	1	25	farmacia	B25J0093	2026-01-21 18:44:39.624+00	2026-01-21 18:44:39.624+00	\N
588	entrada	2026-01-21 19:46:04.756+00	1	\N	91	3	\N	60	36	farmacia	BLGM24007	2026-01-21 19:46:04.756+00	2026-01-21 19:46:04.756+00	\N
589	entrada	2026-01-21 19:47:37.508+00	1	\N	91	3	\N	180	36	farmacia	BLGM24006	2026-01-21 19:47:37.509+00	2026-01-21 19:47:37.509+00	\N
590	entrada	2026-01-21 19:51:12.683+00	1	\N	89	3	\N	60	36	farmacia	L25H2B8	2026-01-21 19:51:12.683+00	2026-01-21 19:51:12.683+00	\N
591	transferencia	2026-01-21 19:56:16.827+00	1	11	\N	5	\N	2	38	enfermagem	884625	2026-01-21 19:56:16.827+00	2026-01-21 19:56:16.827+00	\N
592	entrada	2026-01-21 19:59:58.61+00	1	\N	173	5	\N	2	\N	farmacia	50030366	2026-01-21 19:59:58.61+00	2026-01-21 19:59:58.61+00	\N
593	transferencia	2026-01-21 20:00:26.784+00	1	\N	173	5	\N	1	21	enfermagem	50030366	2026-01-21 20:00:26.784+00	2026-01-21 20:00:26.784+00	\N
594	entrada	2026-01-21 20:04:47.999+00	1	\N	89	3	\N	60	36	farmacia	L25H66X	2026-01-21 20:04:47.999+00	2026-01-21 20:04:47.999+00	\N
595	entrada	2026-01-21 20:11:25.25+00	1	\N	125	3	\N	120	36	farmacia	2400003	2026-01-21 20:11:25.25+00	2026-01-21 20:11:25.25+00	\N
596	entrada	2026-01-21 20:13:06.932+00	1	\N	125	3	\N	60	36	farmacia	50018813	2026-01-21 20:13:06.932+00	2026-01-21 20:13:06.932+00	\N
597	entrada	2026-01-21 20:14:04.329+00	1	\N	125	3	\N	60	36	farmacia	50025076	2026-01-21 20:14:04.329+00	2026-01-21 20:14:04.329+00	\N
598	entrada	2026-01-21 20:26:04.887+00	1	\N	174	3	\N	320	36	farmacia	00053200	2026-01-21 20:26:04.888+00	2026-01-21 20:26:04.888+00	\N
599	entrada	2026-01-21 20:27:14.061+00	1	\N	174	3	\N	120	36	farmacia	00050863	2026-01-21 20:27:14.062+00	2026-01-21 20:27:14.062+00	\N
600	entrada	2026-01-21 20:29:18.054+00	1	\N	32	3	\N	60	36	farmacia	LFKP 07711	2026-01-21 20:29:18.055+00	2026-01-21 20:29:18.055+00	\N
601	entrada	2026-01-21 20:31:58.026+00	1	\N	134	3	\N	60	36	farmacia	LFKP03695	2026-01-21 20:31:58.026+00	2026-01-21 20:31:58.026+00	\N
602	entrada	2026-01-21 20:35:08.919+00	1	\N	157	3	\N	28	36	farmacia	250715	2026-01-21 20:35:08.921+00	2026-01-21 20:35:08.921+00	\N
603	transferencia	2026-01-21 20:36:21.352+00	1	\N	32	3	\N	15	36	enfermagem	LFKP 07711	2026-01-21 20:36:21.353+00	2026-01-21 20:36:21.353+00	\N
604	entrada	2026-01-21 20:37:50.334+00	1	\N	64	3	\N	30	36	farmacia	L25E935	2026-01-21 20:37:50.334+00	2026-01-21 20:37:50.334+00	\N
605	entrada	2026-01-21 20:45:03.17+00	1	\N	155	1	\N	1	36	farmacia	0025795	2026-01-21 20:45:03.17+00	2026-01-21 20:45:03.17+00	\N
606	entrada	2026-01-21 20:46:04.686+00	1	\N	176	1	\N	1	36	farmacia	2425224	2026-01-21 20:46:04.686+00	2026-01-21 20:46:04.686+00	\N
607	entrada	2026-01-21 20:47:14.035+00	1	\N	175	3	\N	1	36	farmacia	4784D	2026-01-21 20:47:14.035+00	2026-01-21 20:47:14.035+00	\N
608	transferencia	2026-01-21 21:00:58.127+00	1	\N	52	4	\N	1	8	enfermagem	\N	2026-01-21 21:00:58.128+00	2026-01-21 21:00:58.128+00	\N
609	transferencia	2026-01-21 21:06:26.159+00	1	\N	48	2	\N	2	4	enfermagem	\N	2026-01-21 21:06:26.16+00	2026-01-21 21:06:26.16+00	\N
610	transferencia	2026-01-21 21:07:40.843+00	1	\N	29	1	\N	15	18	enfermagem	\N	2026-01-21 21:07:40.843+00	2026-01-21 21:07:40.843+00	\N
611	transferencia	2026-01-21 21:08:12.334+00	1	\N	55	1	\N	20	18	enfermagem	258798	2026-01-21 21:08:12.334+00	2026-01-21 21:08:12.334+00	\N
612	transferencia	2026-01-21 21:10:57.458+00	1	13	\N	4	\N	50	5	enfermagem	\N	2026-01-21 21:10:57.458+00	2026-01-21 21:10:57.458+00	\N
613	transferencia	2026-01-21 21:11:35.197+00	1	18	\N	5	\N	8	5	enfermagem	2508010025	2026-01-21 21:11:35.197+00	2026-01-21 21:11:35.197+00	\N
614	transferencia	2026-01-22 13:20:40.229+00	1	\N	95	1	\N	15	16	enfermagem	2510845	2026-01-22 13:20:40.23+00	2026-01-22 13:20:40.23+00	\N
615	transferencia	2026-01-22 13:21:44.692+00	1	\N	29	1	\N	15	17	enfermagem		2026-01-22 13:21:44.692+00	2026-01-22 13:21:44.692+00	\N
616	transferencia	2026-01-22 13:23:26.202+00	1	\N	83	1	\N	15	18	enfermagem	\N	2026-01-22 13:23:26.202+00	2026-01-22 13:23:26.202+00	\N
617	transferencia	2026-01-22 13:23:53.137+00	1	\N	38	1	\N	15	23	enfermagem	\N	2026-01-22 13:23:53.138+00	2026-01-22 13:23:53.138+00	\N
618	transferencia	2026-01-22 13:24:24.527+00	1	\N	149	1	\N	30	39	enfermagem		2026-01-22 13:24:24.527+00	2026-01-22 13:24:24.527+00	\N
619	entrada	2026-01-22 15:12:32.67+00	1	\N	80	1	\N	10	24	farmacia	120569	2026-01-22 15:12:32.671+00	2026-01-22 15:12:32.671+00	\N
620	entrada	2026-01-22 15:18:25.753+00	1	\N	44	1	\N	20	29	farmacia	17139	2026-01-22 15:18:25.753+00	2026-01-22 15:18:25.753+00	\N
621	transferencia	2026-01-22 15:19:41.827+00	1	\N	80	1	\N	10	24	enfermagem	120569	2026-01-22 15:19:41.827+00	2026-01-22 15:19:41.827+00	\N
622	transferencia	2026-01-22 15:20:00.73+00	1	\N	44	1	\N	20	29	enfermagem	17139	2026-01-22 15:20:00.73+00	2026-01-22 15:20:00.73+00	\N
623	transferencia	2026-01-22 15:21:48.753+00	1	\N	83	1	\N	15	39	enfermagem		2026-01-22 15:21:48.753+00	2026-01-22 15:21:48.753+00	\N
624	transferencia	2026-01-22 15:22:55.869+00	1	\N	49	1	\N	14	39	enfermagem		2026-01-22 15:22:55.869+00	2026-01-22 15:22:55.869+00	\N
625	entrada	2026-01-22 17:30:23.84+00	1	\N	55	1	\N	30	17	farmacia	24G09V	2026-01-22 17:30:23.841+00	2026-01-22 17:30:23.841+00	\N
626	transferencia	2026-01-22 17:32:09.378+00	1	\N	55	1	\N	16	17	enfermagem	24G09V	2026-01-22 17:32:09.379+00	2026-01-22 17:32:09.379+00	\N
627	transferencia	2026-01-22 17:36:39.152+00	1	\N	24	1	\N	16	17	enfermagem		2026-01-22 17:36:39.152+00	2026-01-22 17:36:39.152+00	\N
628	entrada	2026-01-22 17:39:39.839+00	1	\N	28	1	\N	20	17	farmacia		2026-01-22 17:39:39.839+00	2026-01-22 17:39:39.839+00	\N
629	entrada	2026-01-22 17:42:47.94+00	1	\N	123	3	\N	30	3	farmacia		2026-01-22 17:42:47.94+00	2026-01-22 17:42:47.94+00	\N
630	entrada	2026-01-22 17:47:53.576+00	1	\N	80	1	\N	65	18	farmacia	WL0108	2026-01-22 17:47:53.576+00	2026-01-22 17:47:53.576+00	\N
631	transferencia	2026-01-22 17:49:07.607+00	1	\N	80	1	\N	15	18	enfermagem	WL0108	2026-01-22 17:49:07.608+00	2026-01-22 17:49:07.608+00	\N
632	entrada	2026-01-22 17:58:40.353+00	1	\N	28	1	\N	30	18	farmacia	FRA02764|U	2026-01-22 17:58:40.354+00	2026-01-22 17:58:40.354+00	\N
633	transferencia	2026-01-22 18:00:25.774+00	1	\N	28	1	\N	30	18	enfermagem	LFRA027641	2026-01-22 18:00:25.775+00	2026-01-22 18:00:25.775+00	\N
634	transferencia	2026-01-22 18:01:18.339+00	1	\N	35	1	\N	30	18	enfermagem	0670/25M	2026-01-22 18:01:18.339+00	2026-01-22 18:01:18.339+00	\N
635	transferencia	2026-01-22 18:01:56.527+00	1	\N	151	1	\N	15	18	enfermagem	BR180114	2026-01-22 18:01:56.527+00	2026-01-22 18:01:56.527+00	\N
636	entrada	2026-01-22 18:04:55.96+00	1	\N	149	1	\N	20	18	farmacia	2506377	2026-01-22 18:04:55.96+00	2026-01-22 18:04:55.96+00	\N
637	transferencia	2026-01-22 18:06:36.816+00	1	\N	43	1	\N	15	18	enfermagem	505827	2026-01-22 18:06:36.816+00	2026-01-22 18:06:36.816+00	\N
638	transferencia	2026-01-22 18:08:09.647+00	1	\N	24	1	\N	10	19	enfermagem	\N	2026-01-22 18:08:09.647+00	2026-01-22 18:08:09.647+00	\N
639	transferencia	2026-01-22 18:08:40.732+00	1	\N	106	1	\N	10	19	enfermagem		2026-01-22 18:08:40.732+00	2026-01-22 18:08:40.732+00	\N
640	transferencia	2026-01-22 18:10:07.193+00	1	\N	55	1	\N	10	26	enfermagem	\N	2026-01-22 18:10:07.193+00	2026-01-22 18:10:07.193+00	\N
641	transferencia	2026-01-22 18:12:50.208+00	1	\N	95	1	\N	10	26	enfermagem	\N	2026-01-22 18:12:50.209+00	2026-01-22 18:12:50.209+00	\N
642	entrada	2026-01-22 18:16:27.887+00	1	\N	177	1	\N	30	26	farmacia	62957	2026-01-22 18:16:27.887+00	2026-01-22 18:16:27.887+00	\N
643	transferencia	2026-01-22 18:18:18.062+00	1	\N	80	1	\N	10	20	enfermagem	141835	2026-01-22 18:18:18.062+00	2026-01-22 18:18:18.062+00	\N
644	transferencia	2026-01-22 18:19:59.433+00	1	\N	167	1	\N	12	20	enfermagem	M502427	2026-01-22 18:19:59.433+00	2026-01-22 18:19:59.433+00	\N
645	transferencia	2026-01-22 18:21:02.436+00	1	\N	29	1	\N	30	20	enfermagem	5C5802	2026-01-22 18:21:02.437+00	2026-01-22 18:21:02.437+00	\N
646	transferencia	2026-01-22 18:23:10.274+00	1	\N	102	1	\N	15	25	enfermagem	\N	2026-01-22 18:23:10.274+00	2026-01-22 18:23:10.274+00	\N
647	transferencia	2026-01-22 18:24:13.575+00	1	\N	28	1	\N	15	22	enfermagem	\N	2026-01-22 18:24:13.576+00	2026-01-22 18:24:13.576+00	\N
648	transferencia	2026-01-22 18:25:07.184+00	1	\N	26	1	\N	4	23	enfermagem	\N	2026-01-22 18:25:07.185+00	2026-01-22 18:25:07.185+00	\N
649	transferencia	2026-01-22 18:26:01.336+00	1	\N	40	1	\N	10	23	enfermagem	\N	2026-01-22 18:26:01.336+00	2026-01-22 18:26:01.336+00	\N
650	entrada	2026-01-22 18:27:51.049+00	1	\N	44	1	\N	10	24	farmacia		2026-01-22 18:27:51.049+00	2026-01-22 18:27:51.049+00	\N
651	transferencia	2026-01-22 18:28:43.64+00	1	\N	44	1	\N	10	24	enfermagem		2026-01-22 18:28:43.641+00	2026-01-22 18:28:43.641+00	\N
652	entrada	2026-01-22 18:36:17.615+00	1	\N	178	1	\N	60	35	farmacia	309968	2026-01-22 18:36:17.615+00	2026-01-22 18:36:17.615+00	\N
653	transferencia	2026-01-22 18:36:42.157+00	1	\N	178	1	\N	60	35	enfermagem	309968	2026-01-22 18:36:42.158+00	2026-01-22 18:36:42.158+00	\N
654	transferencia	2026-01-22 18:39:00.474+00	1	\N	35	1	\N	28	28	enfermagem		2026-01-22 18:39:00.475+00	2026-01-22 18:39:00.475+00	\N
655	transferencia	2026-01-22 18:39:19.668+00	1	\N	35	1	\N	28	2	enfermagem		2026-01-22 18:39:19.669+00	2026-01-22 18:39:19.669+00	\N
656	transferencia	2026-01-22 18:39:38.992+00	1	\N	35	1	\N	28	19	enfermagem		2026-01-22 18:39:38.993+00	2026-01-22 18:39:38.993+00	\N
657	transferencia	2026-01-22 18:41:03.441+00	1	\N	35	1	\N	10	2	enfermagem		2026-01-22 18:41:03.441+00	2026-01-22 18:41:03.441+00	\N
658	entrada	2026-01-22 19:46:35.912+00	1	\N	179	1	\N	20	1	farmacia	24155	2026-01-22 19:46:35.912+00	2026-01-22 19:46:35.912+00	\N
659	transferencia	2026-01-22 19:47:13.844+00	1	\N	179	1	\N	20	1	enfermagem	24155	2026-01-22 19:47:13.844+00	2026-01-22 19:47:13.844+00	\N
660	entrada	2026-01-22 19:49:21.713+00	1	\N	55	1	\N	40	29	farmacia	24G09V	2026-01-22 19:49:21.713+00	2026-01-22 19:49:21.713+00	\N
661	transferencia	2026-01-22 19:50:17.662+00	1	\N	55	1	\N	10	29	enfermagem	24G09V	2026-01-22 19:50:17.662+00	2026-01-22 19:50:17.662+00	\N
662	entrada	2026-01-22 19:55:44.783+00	1	\N	24	1	\N	45	29	farmacia	BR18000	2026-01-22 19:55:44.783+00	2026-01-22 19:55:44.783+00	\N
663	transferencia	2026-01-22 19:57:37.765+00	1	\N	24	1	\N	15	29	enfermagem	BR18000	2026-01-22 19:57:37.765+00	2026-01-22 19:57:37.765+00	\N
664	entrada	2026-01-22 20:06:11.568+00	1	\N	180	1	\N	20	29	farmacia	2503126	2026-01-22 20:06:11.568+00	2026-01-22 20:06:11.568+00	\N
665	transferencia	2026-01-22 20:07:44.738+00	1	\N	180	1	\N	20	29	enfermagem	2503126	2026-01-22 20:07:44.738+00	2026-01-22 20:07:44.738+00	\N
666	entrada	2026-01-22 20:10:21.365+00	1	\N	49	1	\N	20	29	farmacia	FJA25003A	2026-01-22 20:10:21.365+00	2026-01-22 20:10:21.365+00	\N
667	transferencia	2026-01-22 20:11:08.779+00	1	\N	49	1	\N	10	29	enfermagem	FJA25003A	2026-01-22 20:11:08.779+00	2026-01-22 20:11:08.779+00	\N
668	entrada	2026-01-22 20:14:29.594+00	1	\N	84	1	\N	10	29	farmacia	0424001	2026-01-22 20:14:29.594+00	2026-01-22 20:14:29.594+00	\N
669	transferencia	2026-01-22 20:15:01.033+00	1	\N	84	1	\N	10	29	enfermagem	0424001	2026-01-22 20:15:01.033+00	2026-01-22 20:15:01.033+00	\N
670	entrada	2026-01-22 20:18:04.672+00	1	\N	129	1	\N	27	35	farmacia	24040014	2026-01-22 20:18:04.672+00	2026-01-22 20:18:04.672+00	\N
671	entrada	2026-01-22 20:21:50.824+00	1	\N	74	1	\N	30	35	farmacia	M50772	2026-01-22 20:21:50.824+00	2026-01-22 20:21:50.824+00	\N
672	entrada	2026-01-22 20:24:41.915+00	1	\N	24	1	\N	45	35	farmacia		2026-01-22 20:24:41.916+00	2026-01-22 20:24:41.916+00	\N
673	transferencia	2026-01-22 20:28:56.512+00	1	\N	80	1	\N	10	35	enfermagem	120835	2026-01-22 20:28:56.512+00	2026-01-22 20:28:56.512+00	\N
674	transferencia	2026-01-22 20:29:57.585+00	1	\N	27	1	\N	15	35	enfermagem	BR183391	2026-01-22 20:29:57.585+00	2026-01-22 20:29:57.585+00	\N
675	transferencia	2026-01-22 20:31:09.035+00	1	\N	74	1	\N	15	35	enfermagem	M50772	2026-01-22 20:31:09.035+00	2026-01-22 20:31:09.035+00	\N
676	transferencia	2026-01-22 20:32:00.321+00	1	\N	39	1	\N	14	35	enfermagem	\N	2026-01-22 20:32:00.322+00	2026-01-22 20:32:00.322+00	\N
677	transferencia	2026-01-22 20:32:41.151+00	1	\N	129	1	\N	9	35	enfermagem	24040014	2026-01-22 20:32:41.151+00	2026-01-22 20:32:41.151+00	\N
678	transferencia	2026-01-22 20:33:31.644+00	1	\N	102	1	\N	15	38	enfermagem	\N	2026-01-22 20:33:31.645+00	2026-01-22 20:33:31.645+00	\N
679	transferencia	2026-01-22 20:34:20.541+00	1	\N	143	1	\N	30	39	enfermagem		2026-01-22 20:34:20.542+00	2026-01-22 20:34:20.542+00	\N
680	transferencia	2026-01-22 20:34:47.213+00	1	\N	24	1	\N	20	39	enfermagem		2026-01-22 20:34:47.213+00	2026-01-22 20:34:47.213+00	\N
681	transferencia	2026-01-22 20:35:19.045+00	1	\N	17	1	\N	10	40	enfermagem	17135Y	2026-01-22 20:35:19.045+00	2026-01-22 20:35:19.045+00	\N
682	entrada	2026-01-22 20:47:40.137+00	1	\N	103	3	\N	36	14	farmacia	5D0211	2026-01-22 20:47:40.137+00	2026-01-22 20:47:40.137+00	\N
683	entrada	2026-01-22 20:48:48.351+00	1	\N	64	3	\N	30	14	farmacia	50701426	2026-01-22 20:48:48.352+00	2026-01-22 20:48:48.352+00	\N
684	entrada	2026-01-22 21:22:28.491+00	1	\N	139	3	\N	60	19	farmacia	240368	2026-01-22 21:22:28.491+00	2026-01-22 21:22:28.491+00	\N
685	entrada	2026-01-22 21:24:33.633+00	1	\N	139	3	\N	60	22	farmacia	240368	2026-01-22 21:24:33.633+00	2026-01-22 21:24:33.633+00	\N
686	entrada	2026-01-22 21:31:07.889+00	1	\N	34	1	\N	6	13	farmacia	0784/25	2026-01-22 21:31:07.889+00	2026-01-22 21:31:07.889+00	\N
687	entrada	2026-01-22 21:32:22.952+00	1	\N	36	1	\N	30	13	farmacia	2515602	2026-01-22 21:32:22.952+00	2026-01-22 21:32:22.952+00	\N
688	entrada	2026-01-22 21:34:06.974+00	1	\N	54	1	\N	20	13	farmacia	1577/24M	2026-01-22 21:34:06.974+00	2026-01-22 21:34:06.974+00	\N
689	entrada	2026-01-22 21:37:12.018+00	1	\N	143	1	\N	30	38	farmacia	4W4964	2026-01-22 21:37:12.018+00	2026-01-22 21:37:12.018+00	\N
690	entrada	2026-01-22 21:41:07.278+00	1	\N	144	1	\N	90	38	farmacia	1486/24M	2026-01-22 21:41:07.278+00	2026-01-22 21:41:07.278+00	\N
691	entrada	2026-01-22 21:46:35.011+00	1	\N	110	3	\N	4	2	farmacia	25H837	2026-01-22 21:46:35.012+00	2026-01-22 21:46:35.012+00	\N
692	entrada	2026-01-22 21:50:05.051+00	1	\N	31	3	\N	3	7	farmacia	B25J0093	2026-01-22 21:50:05.051+00	2026-01-22 21:50:05.051+00	\N
693	entrada	2026-01-22 21:52:39.063+00	1	\N	83	1	\N	30	39	farmacia	3026002	2026-01-22 21:52:39.063+00	2026-01-22 21:52:39.063+00	\N
694	entrada	2026-01-22 21:55:45.144+00	1	\N	17	1	\N	30	29	farmacia		2026-01-22 21:55:45.144+00	2026-01-22 21:55:45.144+00	\N
695	entrada	2026-01-22 22:00:09.945+00	1	\N	16	1	\N	30	15	farmacia	PD0504	2026-01-22 22:00:09.946+00	2026-01-22 22:00:09.946+00	\N
696	entrada	2026-01-22 22:02:32.812+00	1	\N	17	1	\N	30	35	farmacia	17192	2026-01-22 22:02:32.812+00	2026-01-22 22:02:32.812+00	\N
697	entrada	2026-01-22 22:07:56.295+00	1	\N	55	1	\N	60	3	farmacia	258798	2026-01-22 22:07:56.296+00	2026-01-22 22:07:56.296+00	\N
698	entrada	2026-01-22 22:10:06.503+00	1	\N	36	1	\N	30	3	farmacia	2515602	2026-01-22 22:10:06.504+00	2026-01-22 22:10:06.504+00	\N
699	entrada	2026-01-22 22:13:37.618+00	1	\N	74	1	\N	25	29	farmacia	BR176466	2026-01-22 22:13:37.618+00	2026-01-22 22:13:37.618+00	\N
700	entrada	2026-01-22 22:15:29.74+00	1	\N	37	1	\N	60	6	farmacia	4R5214	2026-01-22 22:15:29.74+00	2026-01-22 22:15:29.74+00	\N
701	entrada	2026-01-22 22:17:14.587+00	1	\N	16	1	\N	30	6	farmacia	PD0504	2026-01-22 22:17:14.587+00	2026-01-22 22:17:14.587+00	\N
702	entrada	2026-01-22 22:19:33.972+00	1	\N	59	1	\N	30	6	farmacia	260405	2026-01-22 22:19:33.973+00	2026-01-22 22:19:33.973+00	\N
703	transferencia	2026-01-23 11:48:47.669+00	1	\N	45	1	\N	20	12	enfermagem	\N	2026-01-23 11:48:47.67+00	2026-01-23 11:48:47.67+00	\N
704	transferencia	2026-01-23 11:49:44.389+00	1	\N	58	1	\N	20	1	enfermagem	\N	2026-01-23 11:49:44.389+00	2026-01-23 11:49:44.389+00	\N
705	transferencia	2026-01-23 11:50:33.468+00	1	\N	113	3	\N	20	2	enfermagem	\N	2026-01-23 11:50:33.468+00	2026-01-23 11:50:33.468+00	\N
706	entrada	2026-01-23 12:02:19.848+00	1	\N	120	3	\N	2	20	farmacia	0952/25	2026-01-23 12:02:19.848+00	2026-01-23 12:02:19.848+00	\N
707	entrada	2026-01-23 12:07:18.667+00	1	\N	95	1	\N	30	20	farmacia	42901016	2026-01-23 12:07:18.667+00	2026-01-23 12:07:18.667+00	\N
708	transferencia	2026-01-23 13:14:07.723+00	1	\N	32	3	\N	15	36	enfermagem	LFKP 07711	2026-01-23 13:14:07.723+00	2026-01-23 13:14:07.723+00	\N
709	transferencia	2026-01-23 13:15:41.669+00	1	\N	89	3	\N	10	36	enfermagem	25H2B8	2026-01-23 13:15:41.669+00	2026-01-23 13:15:41.669+00	\N
710	transferencia	2026-01-23 13:17:44.079+00	1	\N	91	1	\N	10	36	enfermagem	BLGM24003	2026-01-23 13:17:44.079+00	2026-01-23 13:17:44.079+00	\N
711	transferencia	2026-01-23 13:20:51.044+00	1	\N	64	3	\N	20	36	enfermagem	L25E935	2026-01-23 13:20:51.044+00	2026-01-23 13:20:51.044+00	\N
712	transferencia	2026-01-23 13:22:31.114+00	1	\N	157	3	\N	14	36	enfermagem	250715	2026-01-23 13:22:31.115+00	2026-01-23 13:22:31.115+00	\N
713	transferencia	2026-01-23 13:24:30.311+00	1	\N	125	3	\N	20	36	enfermagem	2400003	2026-01-23 13:24:30.311+00	2026-01-23 13:24:30.311+00	\N
714	transferencia	2026-01-23 13:26:21.296+00	1	\N	101	3	\N	1	38	enfermagem	\N	2026-01-23 13:26:21.297+00	2026-01-23 13:26:21.297+00	\N
715	transferencia	2026-01-23 13:29:19.389+00	1	\N	125	3	\N	20	38	enfermagem	50025076	2026-01-23 13:29:19.389+00	2026-01-23 13:29:19.389+00	\N
716	transferencia	2026-01-23 13:31:06.668+00	1	\N	141	3	\N	10	40	enfermagem	LFKP07577	2026-01-23 13:31:06.668+00	2026-01-23 13:31:06.668+00	\N
717	transferencia	2026-01-23 13:32:45.673+00	1	\N	64	1	\N	10	40	enfermagem	25F27T	2026-01-23 13:32:45.674+00	2026-01-23 13:32:45.674+00	\N
718	entrada	2026-01-23 13:34:25.022+00	1	\N	111	3	\N	20	40	farmacia	952541	2026-01-23 13:34:25.023+00	2026-01-23 13:34:25.023+00	\N
719	transferencia	2026-01-23 13:35:55.777+00	1	\N	111	3	\N	10	40	enfermagem	952541	2026-01-23 13:35:55.777+00	2026-01-23 13:35:55.777+00	\N
720	transferencia	2026-01-23 13:38:43.821+00	1	\N	111	3	\N	15	42	enfermagem	L25G19J	2026-01-23 13:38:43.822+00	2026-01-23 13:38:43.822+00	\N
721	transferencia	2026-01-23 13:41:31.888+00	1	\N	139	3	\N	20	22	enfermagem	240368	2026-01-23 13:41:31.888+00	2026-01-23 13:41:31.888+00	\N
722	transferencia	2026-01-23 13:45:08.494+00	1	\N	64	3	\N	15	9	enfermagem	\N	2026-01-23 13:45:08.494+00	2026-01-23 13:45:08.494+00	\N
723	entrada	2026-01-23 13:47:10.118+00	1	\N	123	3	\N	40	9	farmacia	50011722	2026-01-23 13:47:10.118+00	2026-01-23 13:47:10.118+00	\N
724	transferencia	2026-01-23 13:48:58.559+00	1	\N	123	3	\N	20	9	enfermagem	50011722	2026-01-23 13:48:58.559+00	2026-01-23 13:48:58.559+00	\N
725	transferencia	2026-01-23 13:50:58.38+00	1	\N	51	3	\N	15	9	enfermagem	25070534	2026-01-23 13:50:58.38+00	2026-01-23 13:50:58.38+00	\N
726	transferencia	2026-01-23 13:53:20.096+00	1	\N	111	3	\N	15	13	enfermagem	\N	2026-01-23 13:53:20.097+00	2026-01-23 13:53:20.097+00	\N
727	transferencia	2026-01-23 13:54:44.378+00	1	\N	71	3	\N	10	14	enfermagem	C2416778	2026-01-23 13:54:44.379+00	2026-01-23 13:54:44.379+00	\N
728	transferencia	2026-01-23 13:55:45.892+00	1	\N	103	3	\N	12	14	enfermagem	5D0211	2026-01-23 13:55:45.892+00	2026-01-23 13:55:45.892+00	\N
729	transferencia	2026-01-23 13:58:03.286+00	1	\N	134	1	\N	10	18	enfermagem	LFK06420	2026-01-23 13:58:03.286+00	2026-01-23 13:58:03.286+00	\N
730	transferencia	2026-01-23 14:01:11.58+00	1	\N	89	3	\N	15	19	enfermagem	50300038	2026-01-23 14:01:11.581+00	2026-01-23 14:01:11.581+00	\N
731	transferencia	2026-01-23 14:04:51.039+00	1	\N	64	3	\N	15	20	enfermagem	50502483	2026-01-23 14:04:51.039+00	2026-01-23 14:04:51.039+00	\N
732	transferencia	2026-01-23 14:07:31.354+00	1	\N	123	3	\N	15	20	enfermagem	50308023	2026-01-23 14:07:31.355+00	2026-01-23 14:07:31.355+00	\N
733	transferencia	2026-01-23 14:14:26.65+00	1	\N	125	3	\N	10	20	enfermagem	5A7170	2026-01-23 14:14:26.65+00	2026-01-23 14:14:26.65+00	\N
734	entrada	2026-01-23 14:24:19.624+00	1	20	\N	5	\N	5000	\N	farmacia	AUX3780	2026-01-23 14:24:19.624+00	2026-01-23 14:24:19.624+00	\N
735	transferencia	2026-01-23 14:26:10.312+00	1	20	\N	5	\N	2600	\N	enfermagem	AUX3780	2026-01-23 14:26:10.312+00	2026-01-23 14:26:10.312+00	armário da enfermagem
736	entrada	2026-01-23 14:31:20.15+00	1	\N	181	1	\N	60	12	farmacia	2CV95RX5GAWR2	2026-01-23 14:31:20.15+00	2026-01-23 14:31:20.15+00	\N
737	entrada	2026-01-23 14:32:24.211+00	1	\N	155	1	\N	1	12	farmacia	DS24F286	2026-01-23 14:32:24.211+00	2026-01-23 14:32:24.211+00	\N
738	entrada	2026-01-23 14:33:49.295+00	1	\N	35	1	\N	17	12	farmacia	1686/24M	2026-01-23 14:33:49.295+00	2026-01-23 14:33:49.295+00	\N
739	entrada	2026-01-23 14:36:01.965+00	1	\N	28	1	\N	30	12	farmacia	B24K2721	2026-01-23 14:36:01.965+00	2026-01-23 14:36:01.965+00	\N
740	entrada	2026-01-23 14:37:04.288+00	1	\N	28	1	\N	30	12	farmacia	B24L0279	2026-01-23 14:37:04.289+00	2026-01-23 14:37:04.289+00	\N
741	entrada	2026-01-23 14:38:11.514+00	1	\N	28	1	\N	60	12	farmacia	FRA02530	2026-01-23 14:38:11.514+00	2026-01-23 14:38:11.514+00	\N
742	entrada	2026-01-23 14:43:28.397+00	1	21	\N	5	\N	31	\N	farmacia	1097	2026-01-23 14:43:28.397+00	2026-01-23 14:43:28.397+00	\N
743	entrada	2026-01-23 14:44:04.219+00	1	21	\N	5	\N	1	\N	farmacia	0538	2026-01-23 14:44:04.22+00	2026-01-23 14:44:04.22+00	\N
744	transferencia	2026-01-23 14:44:29.514+00	1	21	\N	5	\N	1	\N	enfermagem	0538	2026-01-23 14:44:29.514+00	2026-01-23 14:44:29.514+00	Enfermagem
745	transferencia	2026-01-23 14:44:42.172+00	1	21	\N	5	\N	1	\N	enfermagem	1097	2026-01-23 14:44:42.173+00	2026-01-23 14:44:42.173+00	Enfermagem
746	transferencia	2026-01-23 14:45:25.413+00	1	\N	181	1	\N	60	12	enfermagem	2CV95RX5GAWR2	2026-01-23 14:45:25.414+00	2026-01-23 14:45:25.414+00	\N
747	transferencia	2026-01-23 14:45:34.951+00	1	\N	155	1	\N	1	12	enfermagem	DS24F286	2026-01-23 14:45:34.951+00	2026-01-23 14:45:34.951+00	\N
748	transferencia	2026-01-23 16:49:15.407+00	1	\N	71	3	\N	10	25	enfermagem	\N	2026-01-23 16:49:15.407+00	2026-01-23 16:49:15.407+00	\N
749	transferencia	2026-01-23 16:51:47.512+00	1	\N	123	3	\N	30	25	enfermagem	50022743	2026-01-23 16:51:47.512+00	2026-01-23 16:51:47.512+00	\N
750	entrada	2026-01-23 16:55:53.633+00	1	\N	58	1	\N	20	26	farmacia	1034378	2026-01-23 16:55:53.633+00	2026-01-23 16:55:53.633+00	\N
751	transferencia	2026-01-23 16:56:35.588+00	1	\N	58	1	\N	20	26	enfermagem	1034378	2026-01-23 16:56:35.588+00	2026-01-23 16:56:35.588+00	\N
752	transferencia	2026-01-23 16:58:14.383+00	1	\N	22	1	\N	1	26	enfermagem	\N	2026-01-23 16:58:14.383+00	2026-01-23 16:58:14.383+00	\N
753	entrada	2026-01-23 17:03:09.038+00	1	\N	71	3	\N	120	14	farmacia	CNP5L005	2026-01-23 17:03:09.038+00	2026-01-23 17:03:09.038+00	\N
754	entrada	2026-01-23 17:06:13.947+00	1	\N	71	3	\N	30	34	farmacia	4S3328	2026-01-23 17:06:13.948+00	2026-01-23 17:06:13.948+00	\N
755	transferencia	2026-01-23 17:11:49.267+00	1	\N	71	3	\N	10	34	enfermagem	4S3328	2026-01-23 17:11:49.267+00	2026-01-23 17:11:49.267+00	\N
756	transferencia	2026-01-23 18:25:22.382+00	1	\N	161	3	\N	2	11	enfermagem	50029446	2026-01-23 18:25:22.382+00	2026-01-23 18:25:22.382+00	\N
757	transferencia	2026-01-23 18:27:23.52+00	1	\N	110	4	\N	2	13	enfermagem	\N	2026-01-23 18:27:23.52+00	2026-01-23 18:27:23.52+00	\N
758	entrada	2026-01-23 18:29:23.59+00	1	\N	182	4	\N	30	\N	farmacia	B25D2719	2026-01-23 18:29:23.59+00	2026-01-23 18:29:23.59+00	\N
759	entrada	2026-01-23 18:40:46.58+00	1	\N	125	3	\N	60	24	farmacia	50025076	2026-01-23 18:40:46.58+00	2026-01-23 18:40:46.58+00	\N
760	entrada	2026-01-23 18:42:15.883+00	1	\N	125	3	\N	60	2	farmacia	50025076	2026-01-23 18:42:15.883+00	2026-01-23 18:42:15.883+00	\N
761	entrada	2026-01-23 18:44:14.261+00	1	\N	126	3	\N	60	19	farmacia	50025995	2026-01-23 18:44:14.261+00	2026-01-23 18:44:14.261+00	\N
762	entrada	2026-01-23 18:46:35.55+00	1	\N	125	3	\N	90	4	farmacia	24100007	2026-01-23 18:46:35.55+00	2026-01-23 18:46:35.55+00	\N
763	entrada	2026-01-23 18:50:42.604+00	1	\N	183	3	\N	28	25	farmacia	250466V	2026-01-23 18:50:42.605+00	2026-01-23 18:50:42.605+00	\N
764	entrada	2026-01-23 18:52:45.775+00	1	\N	123	3	\N	30	25	farmacia	50025322	2026-01-23 18:52:45.775+00	2026-01-23 18:52:45.775+00	\N
765	entrada	2026-01-23 18:53:34.534+00	1	\N	123	3	\N	60	25	farmacia	50026239	2026-01-23 18:53:34.535+00	2026-01-23 18:53:34.535+00	\N
766	entrada	2026-01-23 18:54:40.939+00	1	\N	125	3	\N	30	25	farmacia	24100007	2026-01-23 18:54:40.939+00	2026-01-23 18:54:40.939+00	\N
767	entrada	2026-01-23 18:55:33.608+00	1	\N	125	3	\N	60	25	farmacia	50025076	2026-01-23 18:55:33.608+00	2026-01-23 18:55:33.608+00	\N
768	entrada	2026-01-23 18:59:27.399+00	1	\N	123	3	\N	120	3	farmacia	50026239	2026-01-23 18:59:27.399+00	2026-01-23 18:59:27.399+00	\N
769	entrada	2026-01-23 19:02:39.007+00	1	\N	125	3	\N	90	3	farmacia	50025076	2026-01-23 19:02:39.007+00	2026-01-23 19:02:39.007+00	\N
770	entrada	2026-01-23 19:04:56.025+00	1	\N	138	3	\N	90	35	farmacia	50026937	2026-01-23 19:04:56.025+00	2026-01-23 19:04:56.025+00	\N
771	entrada	2026-01-23 19:08:01.128+00	1	\N	158	3	\N	28	35	farmacia	250216	2026-01-23 19:08:01.129+00	2026-01-23 19:08:01.129+00	\N
772	entrada	2026-01-23 19:10:03.372+00	1	\N	126	3	\N	30	35	farmacia	50023334	2026-01-23 19:10:03.372+00	2026-01-23 19:10:03.372+00	\N
773	entrada	2026-01-23 19:14:37.266+00	1	\N	123	3	\N	120	16	farmacia	50026239	2026-01-23 19:14:37.266+00	2026-01-23 19:14:37.266+00	\N
774	entrada	2026-01-23 19:15:30.382+00	1	\N	125	3	\N	120	16	farmacia	24100007	2026-01-23 19:15:30.382+00	2026-01-23 19:15:30.382+00	\N
775	entrada	2026-01-23 19:18:52.334+00	1	\N	58	1	\N	20	26	farmacia	1034382	2026-01-23 19:18:52.334+00	2026-01-23 19:18:52.334+00	\N
776	entrada	2026-01-23 19:21:40.327+00	1	\N	184	1	\N	6	11	farmacia	4Y5971	2026-01-23 19:21:40.327+00	2026-01-23 19:21:40.327+00	\N
777	entrada	2026-01-23 19:39:48.996+00	1	\N	80	1	\N	30	29	farmacia	WL0108	2026-01-23 19:39:48.997+00	2026-01-23 19:39:48.997+00	\N
778	entrada	2026-01-23 19:41:14.979+00	1	\N	138	3	\N	60	29	farmacia	50026937	2026-01-23 19:41:14.979+00	2026-01-23 19:41:14.979+00	\N
779	entrada	2026-01-23 19:43:49.384+00	1	\N	64	3	\N	60	29	farmacia	25E935	2026-01-23 19:43:49.384+00	2026-01-23 19:43:49.384+00	\N
780	entrada	2026-01-23 19:51:05.266+00	1	\N	80	1	\N	30	18	farmacia	WL0108	2026-01-23 19:51:05.266+00	2026-01-23 19:51:05.266+00	\N
781	entrada	2026-01-23 20:28:56.25+00	1	\N	24	1	\N	90	29	farmacia	25K845	2026-01-23 20:28:56.25+00	2026-01-23 20:28:56.25+00	\N
782	entrada	2026-01-23 20:31:27.569+00	1	\N	29	1	\N	60	29	farmacia	B25F1215	2026-01-23 20:31:27.569+00	2026-01-23 20:31:27.569+00	\N
783	entrada	2026-01-23 20:32:56.099+00	1	\N	28	1	\N	30	29	farmacia	0B1562	2026-01-23 20:32:56.099+00	2026-01-23 20:32:56.099+00	\N
784	entrada	2026-01-23 20:37:25.764+00	1	\N	30	1	\N	30	29	farmacia	E0341E2	2026-01-23 20:37:25.764+00	2026-01-23 20:37:25.764+00	\N
785	entrada	2026-01-23 20:41:19.101+00	1	\N	26	1	\N	4	20	farmacia	4X0901	2026-01-23 20:41:19.101+00	2026-01-23 20:41:19.101+00	\N
786	entrada	2026-01-23 20:43:58.975+00	1	\N	24	1	\N	30	42	farmacia	25I53S	2026-01-23 20:43:58.975+00	2026-01-23 20:43:58.975+00	\N
787	entrada	2026-01-23 20:45:09.296+00	1	\N	143	1	\N	30	42	farmacia	4K1826	2026-01-23 20:45:09.296+00	2026-01-23 20:45:09.296+00	\N
788	entrada	2026-01-23 20:46:56.689+00	1	\N	24	1	\N	30	9	farmacia	25K174	2026-01-23 20:46:56.69+00	2026-01-23 20:46:56.69+00	\N
789	entrada	2026-01-23 20:51:11.695+00	1	\N	29	1	\N	30	9	farmacia	B25F1215	2026-01-23 20:51:11.695+00	2026-01-23 20:51:11.695+00	\N
790	entrada	2026-01-23 20:54:24.018+00	1	\N	81	1	\N	1	4	farmacia	12251046A	2026-01-23 20:54:24.018+00	2026-01-23 20:54:24.018+00	\N
791	entrada	2026-01-23 20:57:41.372+00	1	\N	82	1	\N	2	4	farmacia	1420394	2026-01-23 20:57:41.372+00	2026-01-23 20:57:41.372+00	\N
792	entrada	2026-01-23 20:59:59.177+00	1	\N	24	1	\N	30	14	farmacia	25K845	2026-01-23 20:59:59.177+00	2026-01-23 20:59:59.177+00	\N
793	entrada	2026-01-23 21:01:18.783+00	1	\N	16	1	\N	30	14	farmacia	PL4709	2026-01-23 21:01:18.783+00	2026-01-23 21:01:18.783+00	\N
794	entrada	2026-01-23 21:06:51.099+00	1	\N	82	2	\N	2	39	farmacia	1420394	2026-01-23 21:06:51.099+00	2026-01-23 21:06:51.099+00	\N
795	entrada	2026-01-23 21:08:27.49+00	1	\N	81	2	\N	1	39	farmacia	12251046A	2026-01-23 21:08:27.49+00	2026-01-23 21:08:27.49+00	\N
796	entrada	2026-01-23 21:13:44.366+00	1	\N	82	1	\N	2	6	farmacia	1420394	2026-01-23 21:13:44.366+00	2026-01-23 21:13:44.366+00	\N
797	entrada	2026-01-26 11:48:48.648+00	1	\N	80	1	\N	30	11	farmacia	61718	2026-01-26 11:48:48.648+00	2026-01-26 11:48:48.648+00	\N
798	transferencia	2026-01-26 11:49:30.287+00	1	\N	80	1	\N	10	11	enfermagem	61718	2026-01-26 11:49:30.288+00	2026-01-26 11:49:30.288+00	\N
799	transferencia	2026-01-26 11:50:31.234+00	1	\N	85	1	\N	15	15	enfermagem	\N	2026-01-26 11:50:31.235+00	2026-01-26 11:50:31.235+00	\N
800	transferencia	2026-01-26 11:51:23.628+00	1	\N	40	1	\N	15	23	enfermagem	\N	2026-01-26 11:51:23.628+00	2026-01-26 11:51:23.628+00	\N
801	transferencia	2026-01-26 11:52:33.459+00	1	\N	58	1	\N	20	28	enfermagem	\N	2026-01-26 11:52:33.459+00	2026-01-26 11:52:33.459+00	\N
802	transferencia	2026-01-26 11:53:39.893+00	1	\N	144	1	\N	20	38	enfermagem	1542/24M	2026-01-26 11:53:39.893+00	2026-01-26 11:53:39.893+00	\N
803	entrada	2026-01-26 11:55:33.401+00	1	\N	16	1	\N	15	39	farmacia	NW7852	2026-01-26 11:55:33.401+00	2026-01-26 11:55:33.401+00	\N
804	transferencia	2026-01-26 11:56:02.476+00	1	\N	16	1	\N	15	39	enfermagem	NW7852	2026-01-26 11:56:02.476+00	2026-01-26 11:56:02.476+00	\N
805	entrada	2026-01-26 11:57:44.419+00	1	\N	75	1	\N	10	24	farmacia	25F0275	2026-01-26 11:57:44.42+00	2026-01-26 11:57:44.42+00	\N
806	transferencia	2026-01-26 11:58:09.164+00	1	\N	75	1	\N	4	24	enfermagem	25F0275	2026-01-26 11:58:09.164+00	2026-01-26 11:58:09.164+00	\N
807	transferencia	2026-01-26 11:59:20.585+00	1	\N	125	3	\N	13	16	enfermagem	5000188811	2026-01-26 11:59:20.585+00	2026-01-26 11:59:20.585+00	\N
808	entrada	2026-01-26 12:00:57.957+00	1	\N	125	3	\N	7	16	farmacia	50018811	2026-01-26 12:00:57.957+00	2026-01-26 12:00:57.957+00	\N
809	transferencia	2026-01-26 12:01:21.46+00	1	\N	125	3	\N	7	16	enfermagem	50018811	2026-01-26 12:01:21.46+00	2026-01-26 12:01:21.46+00	\N
810	transferencia	2026-01-26 12:02:59.997+00	1	\N	33	3	\N	15	29	enfermagem	50306956	2026-01-26 12:02:59.998+00	2026-01-26 12:02:59.998+00	\N
811	transferencia	2026-01-26 12:03:48.237+00	1	\N	140	3	\N	10	29	enfermagem	50023281	2026-01-26 12:03:48.237+00	2026-01-26 12:03:48.237+00	\N
812	entrada	2026-01-26 12:06:34.471+00	1	\N	111	3	\N	30	29	farmacia	25092W	2026-01-26 12:06:34.472+00	2026-01-26 12:06:34.472+00	\N
813	transferencia	2026-01-26 12:07:04.332+00	1	\N	111	3	\N	20	29	enfermagem	25092W	2026-01-26 12:07:04.332+00	2026-01-26 12:07:04.332+00	\N
814	transferencia	2026-01-26 12:08:35.445+00	1	\N	111	3	\N	60	34	enfermagem	25G19J	2026-01-26 12:08:35.445+00	2026-01-26 12:08:35.445+00	\N
815	entrada	2026-01-26 12:11:37.276+00	1	\N	138	3	\N	60	35	farmacia	50024823	2026-01-26 12:11:37.276+00	2026-01-26 12:11:37.276+00	\N
816	transferencia	2026-01-26 12:12:01.77+00	1	\N	138	3	\N	20	35	enfermagem	50024823	2026-01-26 12:12:01.77+00	2026-01-26 12:12:01.77+00	\N
817	entrada	2026-01-26 12:55:53.497+00	1	\N	43	1	\N	60	27	farmacia	5A0215	2026-01-26 12:55:53.497+00	2026-01-26 12:55:53.497+00	\N
818	entrada	2026-01-26 12:57:10.501+00	1	\N	24	1	\N	30	27	farmacia	25K4G4	2026-01-26 12:57:10.501+00	2026-01-26 12:57:10.501+00	\N
819	entrada	2026-01-26 12:58:10.021+00	1	\N	143	1	\N	30	27	farmacia	4V8282	2026-01-26 12:58:10.021+00	2026-01-26 12:58:10.021+00	\N
820	entrada	2026-01-26 12:59:09.908+00	1	\N	39	1	\N	28	27	farmacia	2501536	2026-01-26 12:59:09.908+00	2026-01-26 12:59:09.908+00	\N
821	entrada	2026-01-26 13:01:22.502+00	1	\N	185	1	\N	30	27	farmacia	4Z9312	2026-01-26 13:01:22.502+00	2026-01-26 13:01:22.502+00	\N
822	entrada	2026-01-26 13:03:22.241+00	1	\N	186	1	\N	30	27	farmacia	4T9964	2026-01-26 13:03:22.241+00	2026-01-26 13:03:22.241+00	\N
823	entrada	2026-01-26 13:07:23.545+00	1	\N	34	1	\N	1	27	farmacia	25G27B	2026-01-26 13:07:23.546+00	2026-01-26 13:07:23.546+00	\N
824	entrada	2026-01-26 13:09:40.32+00	1	\N	18	1	\N	20	27	farmacia	25G27B	2026-01-26 13:09:40.32+00	2026-01-26 13:09:40.32+00	\N
825	entrada	2026-01-26 13:10:36.35+00	1	\N	119	3	\N	1	27	farmacia	50030073	2026-01-26 13:10:36.35+00	2026-01-26 13:10:36.35+00	\N
826	entrada	2026-01-26 13:25:49.913+00	1	\N	61	1	\N	7	27	farmacia	064207	2026-01-26 13:25:49.914+00	2026-01-26 13:25:49.914+00	\N
827	entrada	2026-01-26 13:26:45.734+00	1	\N	34	1	\N	3	27	farmacia	0784/25	2026-01-26 13:26:45.734+00	2026-01-26 13:26:45.734+00	\N
828	saida	2026-01-26 13:29:33.77+00	1	13	\N	4	\N	50	5	enfermagem	\N	2026-01-26 13:29:33.77+00	2026-01-26 13:29:33.77+00	\N
829	entrada	2026-01-26 13:30:52.66+00	1	\N	35	1	\N	20	\N	farmacia	1686/24M	2026-01-26 13:30:52.66+00	2026-01-26 13:30:52.66+00	\N
830	entrada	2026-01-26 13:32:19.985+00	1	\N	22	1	\N	1	27	farmacia	XH9J	2026-01-26 13:32:19.985+00	2026-01-26 13:32:19.985+00	\N
831	transferencia	2026-01-26 13:32:48.749+00	1	\N	22	1	\N	1	27	enfermagem	XH9J	2026-01-26 13:32:48.749+00	2026-01-26 13:32:48.749+00	\N
832	entrada	2026-01-26 13:36:24.684+00	1	\N	188	4	\N	30	\N	farmacia	251189	2026-01-26 13:36:24.684+00	2026-01-26 13:36:24.684+00	\N
833	saida	2026-01-26 13:38:15.445+00	1	\N	188	4	\N	1	\N	farmacia	251189	2026-01-26 13:38:15.445+00	2026-01-26 13:38:15.445+00	\N
834	saida	2026-01-26 13:39:15.683+00	1	20	\N	5	\N	100	\N	farmacia	AUX3780	2026-01-26 13:39:15.683+00	2026-01-26 13:39:15.683+00	\N
835	transferencia	2026-01-26 13:51:33.449+00	1	\N	161	3	\N	1	11	enfermagem	50029446	2026-01-26 13:51:33.449+00	2026-01-26 13:51:33.449+00	\N
836	transferencia	2026-01-26 13:52:40.577+00	1	\N	110	3	\N	1	2	enfermagem	25H837	2026-01-26 13:52:40.577+00	2026-01-26 13:52:40.577+00	\N
837	entrada	2026-01-26 14:30:03.906+00	1	\N	123	3	\N	90	25	farmacia	50026239	2026-01-26 14:30:03.907+00	2026-01-26 14:30:03.907+00	\N
838	entrada	2026-01-26 14:30:59.612+00	1	\N	125	3	\N	90	25	farmacia	50025076	2026-01-26 14:30:59.612+00	2026-01-26 14:30:59.612+00	\N
839	entrada	2026-01-26 14:40:45.835+00	1	\N	125	3	\N	10	2	farmacia	50012707	2026-01-26 14:40:45.835+00	2026-01-26 14:40:45.835+00	\N
840	entrada	2026-01-26 14:44:43.615+00	1	\N	125	3	\N	20	2	farmacia	50016393	2026-01-26 14:44:43.616+00	2026-01-26 14:44:43.616+00	\N
841	entrada	2026-01-26 14:46:03.35+00	1	\N	125	3	\N	60	2	farmacia	50018811	2026-01-26 14:46:03.35+00	2026-01-26 14:46:03.35+00	\N
842	entrada	2026-01-26 14:47:05.974+00	1	\N	125	3	\N	30	2	farmacia	24100003	2026-01-26 14:47:05.974+00	2026-01-26 14:47:05.974+00	\N
843	entrada	2026-01-26 14:51:00.979+00	1	\N	125	3	\N	30	3	farmacia	50025076	2026-01-26 14:51:00.98+00	2026-01-26 14:51:00.98+00	\N
844	entrada	2026-01-26 14:51:43.399+00	1	\N	125	3	\N	60	3	farmacia	24100003	2026-01-26 14:51:43.399+00	2026-01-26 14:51:43.399+00	\N
845	entrada	2026-01-26 14:53:47.22+00	1	\N	125	3	\N	10	3	farmacia	50016392	2026-01-26 14:53:47.22+00	2026-01-26 14:53:47.22+00	\N
846	entrada	2026-01-26 14:54:58.408+00	1	\N	125	3	\N	90	3	farmacia	50018813	2026-01-26 14:54:58.408+00	2026-01-26 14:54:58.408+00	\N
847	entrada	2026-01-26 14:55:53.375+00	1	\N	125	3	\N	71	3	farmacia	50018814	2026-01-26 14:55:53.375+00	2026-01-26 14:55:53.375+00	\N
848	entrada	2026-01-26 14:58:45.703+00	1	\N	123	3	\N	10	3	farmacia	50016074	2026-01-26 14:58:45.703+00	2026-01-26 14:58:45.703+00	\N
849	entrada	2026-01-26 14:59:44.271+00	1	\N	123	3	\N	30	3	farmacia	50017919	2026-01-26 14:59:44.272+00	2026-01-26 14:59:44.272+00	\N
850	entrada	2026-01-26 15:00:38.487+00	1	\N	123	3	\N	60	3	farmacia	50022743	2026-01-26 15:00:38.487+00	2026-01-26 15:00:38.487+00	\N
851	entrada	2026-01-26 15:06:57.849+00	1	\N	123	4	\N	90	3	farmacia	50026239	2026-01-26 15:06:57.849+00	2026-01-26 15:06:57.849+00	\N
852	entrada	2026-01-26 15:07:49.498+00	1	\N	123	4	\N	30	3	farmacia	50025322	2026-01-26 15:07:49.499+00	2026-01-26 15:07:49.499+00	\N
853	entrada	2026-01-26 15:09:33.237+00	1	\N	125	3	\N	60	24	farmacia	24100007	2026-01-26 15:09:33.237+00	2026-01-26 15:09:33.237+00	\N
854	entrada	2026-01-26 15:13:52.296+00	1	\N	125	3	\N	10	24	farmacia	50016392	2026-01-26 15:13:52.296+00	2026-01-26 15:13:52.296+00	\N
855	entrada	2026-01-26 15:14:49.326+00	1	\N	125	3	\N	80	24	farmacia	50018813	2026-01-26 15:14:49.326+00	2026-01-26 15:14:49.326+00	\N
856	entrada	2026-01-26 15:19:10.864+00	1	\N	125	3	\N	20	16	farmacia	50012725	2026-01-26 15:19:10.864+00	2026-01-26 15:19:10.864+00	\N
857	entrada	2026-01-26 15:20:01.815+00	1	\N	125	3	\N	90	16	farmacia	50016176	2026-01-26 15:20:01.815+00	2026-01-26 15:20:01.815+00	\N
858	entrada	2026-01-26 15:21:57.205+00	1	\N	125	3	\N	90	16	farmacia	24100007	2026-01-26 15:21:57.205+00	2026-01-26 15:21:57.205+00	\N
859	entrada	2026-01-26 15:23:08.344+00	1	\N	125	3	\N	30	16	farmacia	24100003	2026-01-26 15:23:08.344+00	2026-01-26 15:23:08.344+00	\N
860	entrada	2026-01-26 15:24:21.26+00	1	\N	123	3	\N	90	16	farmacia	50026239	2026-01-26 15:24:21.26+00	2026-01-26 15:24:21.26+00	\N
861	entrada	2026-01-26 15:25:12.003+00	1	\N	123	3	\N	30	16	farmacia	50025322	2026-01-26 15:25:12.004+00	2026-01-26 15:25:12.004+00	\N
862	entrada	2026-01-26 16:45:19.848+00	1	\N	125	3	\N	120	4	farmacia	50018811	2026-01-26 16:45:19.848+00	2026-01-26 16:45:19.848+00	\N
863	entrada	2026-01-26 16:54:51.869+00	1	\N	125	3	\N	100	38	farmacia	50016392	2026-01-26 16:54:51.869+00	2026-01-26 16:54:51.869+00	\N
864	entrada	2026-01-26 16:55:58.508+00	1	\N	125	3	\N	90	38	farmacia	50018814	2026-01-26 16:55:58.508+00	2026-01-26 16:55:58.508+00	\N
865	entrada	2026-01-26 16:57:02.174+00	1	\N	125	3	\N	60	38	farmacia	50018811	2026-01-26 16:57:02.174+00	2026-01-26 16:57:02.174+00	\N
866	entrada	2026-01-26 16:57:52.778+00	1	\N	125	3	\N	30	38	farmacia	50018814	2026-01-26 16:57:52.778+00	2026-01-26 16:57:52.778+00	\N
867	entrada	2026-01-26 16:58:40.063+00	1	\N	125	3	\N	30	38	farmacia	24100007	2026-01-26 16:58:40.064+00	2026-01-26 16:58:40.064+00	\N
868	entrada	2026-01-26 17:19:20.027+00	1	\N	125	3	\N	20	35	farmacia	50016795	2026-01-26 17:19:20.027+00	2026-01-26 17:19:20.027+00	\N
869	entrada	2026-01-26 17:20:26.253+00	1	\N	125	3	\N	50	35	farmacia	50021599A	2026-01-26 17:20:26.253+00	2026-01-26 17:20:26.253+00	\N
870	entrada	2026-01-26 17:23:22.004+00	1	\N	126	3	\N	100	35	farmacia	24060014	2026-01-26 17:23:22.004+00	2026-01-26 17:23:22.004+00	\N
871	entrada	2026-01-26 17:33:37.827+00	1	\N	138	3	\N	60	35	farmacia	50022825	2026-01-26 17:33:37.828+00	2026-01-26 17:33:37.828+00	\N
872	entrada	2026-01-26 17:35:05.394+00	1	\N	138	3	\N	30	35	farmacia	50022818	2026-01-26 17:35:05.394+00	2026-01-26 17:35:05.394+00	\N
873	entrada	2026-01-26 17:36:43.583+00	1	\N	126	3	\N	30	35	farmacia	50021599	2026-01-26 17:36:43.583+00	2026-01-26 17:36:43.583+00	\N
874	entrada	2026-01-26 18:27:21.174+00	1	\N	189	8	\N	30	\N	farmacia	552027	2026-01-26 18:27:21.174+00	2026-01-26 18:27:21.174+00	\N
875	transferencia	2026-01-26 19:00:10.338+00	1	\N	23	1	\N	1	39	enfermagem	\N	2026-01-26 19:00:10.338+00	2026-01-26 19:00:10.338+00	\N
876	transferencia	2026-01-26 19:12:04.517+00	1	\N	22	1	\N	1	39	enfermagem	07643327	2026-01-26 19:12:04.517+00	2026-01-26 19:12:04.517+00	\N
877	transferencia	2026-01-26 19:13:39.845+00	1	\N	46	2	\N	1	26	enfermagem	L:5C3338	2026-01-26 19:13:39.845+00	2026-01-26 19:13:39.845+00	\N
878	entrada	2026-01-26 19:43:05.654+00	1	\N	28	1	\N	30	12	farmacia	B24K2721	2026-01-26 19:43:05.655+00	2026-01-26 19:43:05.655+00	\N
879	transferencia	2026-01-26 19:46:27.121+00	1	\N	106	1	\N	10	2	enfermagem		2026-01-26 19:46:27.122+00	2026-01-26 19:46:27.122+00	\N
880	entrada	2026-01-26 19:49:34.482+00	1	\N	22	2	\N	1	4	farmacia	07643252	2026-01-26 19:49:34.482+00	2026-01-26 19:49:34.482+00	\N
881	transferencia	2026-01-26 19:49:58.906+00	1	\N	22	2	\N	1	4	enfermagem	07643252	2026-01-26 19:49:58.906+00	2026-01-26 19:49:58.906+00	\N
882	entrada	2026-01-26 19:51:46.862+00	1	\N	81	2	\N	1	4	farmacia	12250728A	2026-01-26 19:51:46.863+00	2026-01-26 19:51:46.863+00	\N
883	entrada	2026-01-26 19:59:51.319+00	1	14	\N	5	\N	25	\N	farmacia	10824181	2026-01-26 19:59:51.319+00	2026-01-26 19:59:51.319+00	\N
884	saida	2026-01-26 21:27:30.323+00	1	\N	182	4	\N	1	\N	farmacia	B25D2719	2026-01-26 21:27:30.323+00	2026-01-26 21:27:30.323+00	\N
885	transferencia	2026-01-26 21:29:42.942+00	1	18	\N	5	\N	4	\N	enfermagem	2508010025	2026-01-26 21:29:42.942+00	2026-01-26 21:29:42.942+00	Enfermagem
886	transferencia	2026-01-26 21:42:07.966+00	1	\N	105	3	\N	3	33	enfermagem	\N	2026-01-26 21:42:07.967+00	2026-01-26 21:42:07.967+00	\N
887	entrada	2026-01-27 11:50:03.105+00	1	\N	190	3	\N	90	8	farmacia	25040284	2026-01-27 11:50:03.105+00	2026-01-27 11:50:03.105+00	\N
888	transferencia	2026-01-27 11:50:27.998+00	1	\N	190	3	\N	15	8	enfermagem	25040284	2026-01-27 11:50:27.998+00	2026-01-27 11:50:27.998+00	\N
889	entrada	2026-01-27 11:54:10.237+00	1	\N	71	3	\N	20	29	farmacia	C2416778	2026-01-27 11:54:10.237+00	2026-01-27 11:54:10.237+00	\N
890	transferencia	2026-01-27 11:54:50.456+00	1	\N	71	3	\N	10	29	enfermagem	C2416778	2026-01-27 11:54:50.457+00	2026-01-27 11:54:50.457+00	\N
891	transferencia	2026-01-27 12:00:32.257+00	1	\N	58	1	\N	20	26	enfermagem	1034382	2026-01-27 12:00:32.258+00	2026-01-27 12:00:32.258+00	\N
892	entrada	2026-01-27 12:05:03.633+00	1	\N	149	1	\N	20	20	farmacia	2506377	2026-01-27 12:05:03.633+00	2026-01-27 12:05:03.633+00	\N
893	entrada	2026-01-27 12:05:52.879+00	1	\N	149	1	\N	20	20	farmacia	2407472	2026-01-27 12:05:52.879+00	2026-01-27 12:05:52.879+00	\N
894	entrada	2026-01-27 12:06:56.71+00	1	\N	149	1	\N	60	20	farmacia	2513066	2026-01-27 12:06:56.71+00	2026-01-27 12:06:56.71+00	\N
895	transferencia	2026-01-27 12:07:51.095+00	1	\N	149	1	\N	20	20	enfermagem	2506377	2026-01-27 12:07:51.095+00	2026-01-27 12:07:51.095+00	\N
896	transferencia	2026-01-27 12:08:06.29+00	1	\N	149	1	\N	20	20	enfermagem	2407472	2026-01-27 12:08:06.29+00	2026-01-27 12:08:06.29+00	\N
897	transferencia	2026-01-27 12:09:26.91+00	1	\N	185	1	\N	10	27	enfermagem	4Z9312	2026-01-27 12:09:26.91+00	2026-01-27 12:09:26.91+00	\N
898	transferencia	2026-01-27 12:10:15.711+00	1	\N	95	1	\N	10	20	enfermagem	42901016	2026-01-27 12:10:15.711+00	2026-01-27 12:10:15.711+00	\N
899	entrada	2026-01-27 12:40:34.402+00	1	\N	71	3	\N	30	40	farmacia	4S3328	2026-01-27 12:40:34.403+00	2026-01-27 12:40:34.403+00	\N
900	entrada	2026-01-27 12:42:10.744+00	1	\N	35	1	\N	40	40	farmacia	0670/25M	2026-01-27 12:42:10.744+00	2026-01-27 12:42:10.744+00	\N
901	transferencia	2026-01-27 16:12:42.577+00	1	\N	71	3	\N	10	40	enfermagem	4S3328	2026-01-27 16:12:42.578+00	2026-01-27 16:12:42.578+00	\N
902	transferencia	2026-01-27 16:13:50.131+00	1	\N	35	1	\N	10	40	enfermagem	0670/25M	2026-01-27 16:13:50.131+00	2026-01-27 16:13:50.131+00	\N
903	entrada	2026-01-27 17:34:10.309+00	1	22	\N	6	\N	7	\N	farmacia	D43-1	2026-01-27 17:34:10.309+00	2026-01-27 17:34:10.309+00	\N
904	entrada	2026-01-27 17:42:38.613+00	1	23	\N	6	\N	2	\N	farmacia		2026-01-27 17:42:38.613+00	2026-01-27 17:42:38.613+00	\N
905	entrada	2026-01-27 17:48:48.041+00	1	\N	182	4	\N	2	\N	farmacia	4Y6625	2026-01-27 17:48:48.041+00	2026-01-27 17:48:48.041+00	\N
906	entrada	2026-01-27 17:50:56.202+00	1	\N	191	4	\N	1	\N	farmacia	25052304	2026-01-27 17:50:56.202+00	2026-01-27 17:50:56.202+00	\N
907	entrada	2026-01-27 17:53:43.017+00	1	24	\N	6	\N	4	\N	farmacia	2532245	2026-01-27 17:53:43.017+00	2026-01-27 17:53:43.017+00	\N
908	transferencia	2026-01-27 17:56:08.595+00	1	23	\N	6	\N	2	11	enfermagem		2026-01-27 17:56:08.595+00	2026-01-27 17:56:08.595+00	\N
909	transferencia	2026-01-27 17:56:57.688+00	1	\N	191	4	\N	1	11	enfermagem	25052304	2026-01-27 17:56:57.689+00	2026-01-27 17:56:57.689+00	\N
910	entrada	2026-01-27 17:58:45.944+00	1	\N	192	4	\N	1	11	farmacia		2026-01-27 17:58:45.944+00	2026-01-27 17:58:45.944+00	\N
911	transferencia	2026-01-27 17:59:18.292+00	1	\N	192	4	\N	1	11	enfermagem		2026-01-27 17:59:18.292+00	2026-01-27 17:59:18.292+00	\N
912	entrada	2026-01-27 18:05:51.455+00	1	\N	193	5	\N	1	\N	farmacia	0344232511	2026-01-27 18:05:51.456+00	2026-01-27 18:05:51.456+00	\N
913	entrada	2026-01-27 18:06:47.771+00	1	\N	182	4	\N	1	\N	farmacia	2504806	2026-01-27 18:06:47.771+00	2026-01-27 18:06:47.771+00	\N
914	entrada	2026-01-27 18:10:39.032+00	1	\N	194	4	\N	2	\N	farmacia	2531928	2026-01-27 18:10:39.032+00	2026-01-27 18:10:39.032+00	\N
915	entrada	2026-01-27 18:13:40.78+00	1	25	\N	5	\N	2	\N	farmacia	20230030	2026-01-27 18:13:40.78+00	2026-01-27 18:13:40.78+00	\N
916	entrada	2026-01-27 18:16:46.944+00	1	26	\N	5	\N	1	\N	farmacia	25385422B1	2026-01-27 18:16:46.944+00	2026-01-27 18:16:46.944+00	\N
917	entrada	2026-01-27 18:20:13.508+00	1	27	\N	5	\N	3	\N	farmacia	72043	2026-01-27 18:20:13.508+00	2026-01-27 18:20:13.508+00	\N
918	transferencia	2026-01-27 18:21:52.701+00	1	27	\N	5	\N	1	\N	enfermagem	72043	2026-01-27 18:21:52.702+00	2026-01-27 18:21:52.702+00	enfermagem
919	entrada	2026-01-27 18:38:04.748+00	1	28	\N	6	\N	32	\N	farmacia	23020475	2026-01-27 18:38:04.748+00	2026-01-27 18:38:04.748+00	\N
920	entrada	2026-01-27 19:55:26.713+00	1	29	\N	5	\N	15	\N	farmacia	15E23	2026-01-27 19:55:26.714+00	2026-01-27 19:55:26.714+00	\N
921	transferencia	2026-01-27 19:57:00.309+00	1	29	\N	5	\N	4	\N	enfermagem	15E23	2026-01-27 19:57:00.31+00	2026-01-27 19:57:00.31+00	enfermagem
922	entrada	2026-01-27 20:08:06.276+00	1	\N	39	1	\N	28	12	farmacia	983437	2026-01-27 20:08:06.276+00	2026-01-27 20:08:06.276+00	\N
923	transferencia	2026-01-27 20:13:09.218+00	1	\N	39	1	\N	14	12	enfermagem	983437	2026-01-27 20:13:09.218+00	2026-01-27 20:13:09.218+00	\N
924	entrada	2026-01-27 20:17:30.978+00	1	\N	142	1	\N	25	5	farmacia	BR173864	2026-01-27 20:17:30.978+00	2026-01-27 20:17:30.978+00	\N
925	transferencia	2026-01-27 20:23:42.706+00	1	\N	27	1	\N	15	2	enfermagem	BR181039	2026-01-27 20:23:42.706+00	2026-01-27 20:23:42.706+00	\N
926	transferencia	2026-01-27 20:26:11.711+00	1	\N	36	1	\N	28	4	enfermagem	2515609	2026-01-27 20:26:11.711+00	2026-01-27 20:26:11.711+00	\N
927	entrada	2026-01-27 20:54:48.393+00	1	\N	179	1	\N	72	1	farmacia	2426271	2026-01-27 20:54:48.393+00	2026-01-27 20:54:48.393+00	\N
928	transferencia	2026-01-27 20:55:40.232+00	1	\N	179	1	\N	32	1	enfermagem	2426271	2026-01-27 20:55:40.233+00	2026-01-27 20:55:40.233+00	\N
929	transferencia	2026-01-27 20:58:53.276+00	1	\N	125	3	\N	20	2	enfermagem	50025076	2026-01-27 20:58:53.276+00	2026-01-27 20:58:53.276+00	\N
930	transferencia	2026-01-27 21:02:40.324+00	1	\N	123	3	\N	10	3	enfermagem	50016074	2026-01-27 21:02:40.324+00	2026-01-27 21:02:40.324+00	\N
931	transferencia	2026-01-27 21:03:35.927+00	1	\N	123	3	\N	10	3	enfermagem	50017919	2026-01-27 21:03:35.928+00	2026-01-27 21:03:35.928+00	\N
932	transferencia	2026-01-27 21:05:26.121+00	1	\N	123	3	\N	30	3	enfermagem		2026-01-27 21:05:26.121+00	2026-01-27 21:05:26.121+00	\N
933	transferencia	2026-01-27 21:08:35.358+00	1	\N	138	3	\N	15	8	enfermagem	ME25814	2026-01-27 21:08:35.358+00	2026-01-27 21:08:35.358+00	\N
934	transferencia	2026-01-27 21:12:17.578+00	1	\N	71	3	\N	10	14	enfermagem	CNP5L005	2026-01-27 21:12:17.578+00	2026-01-27 21:12:17.578+00	\N
935	entrada	2026-01-27 21:15:15.703+00	1	\N	64	3	\N	20	14	farmacia	25E371	2026-01-27 21:15:15.703+00	2026-01-27 21:15:15.703+00	\N
936	transferencia	2026-01-27 21:16:09.529+00	1	\N	64	3	\N	10	14	enfermagem	25E371	2026-01-27 21:16:09.529+00	2026-01-27 21:16:09.529+00	\N
937	transferencia	2026-01-27 21:18:51.886+00	1	\N	139	3	\N	20	19	enfermagem	240370	2026-01-27 21:18:51.886+00	2026-01-27 21:18:51.886+00	\N
938	transferencia	2026-01-27 21:20:13.278+00	1	\N	140	3	\N	10	19	enfermagem	50020767	2026-01-27 21:20:13.279+00	2026-01-27 21:20:13.279+00	\N
939	transferencia	2026-01-27 21:22:11.225+00	1	\N	126	3	\N	10	19	enfermagem	50023326A	2026-01-27 21:22:11.225+00	2026-01-27 21:22:11.225+00	\N
940	transferencia	2026-01-27 21:23:35.737+00	1	\N	126	3	\N	10	19	enfermagem	50025995	2026-01-27 21:23:35.737+00	2026-01-27 21:23:35.737+00	\N
941	entrada	2026-01-27 21:34:39.762+00	1	\N	22	2	\N	2	26	farmacia	14250394	2026-01-27 21:34:39.762+00	2026-01-27 21:34:39.762+00	\N
942	transferencia	2026-01-27 21:35:25.185+00	1	\N	22	2	\N	1	26	enfermagem	14250394	2026-01-27 21:35:25.185+00	2026-01-27 21:35:25.185+00	\N
943	transferencia	2026-01-27 21:44:42.691+00	1	\N	162	3	\N	10	30	enfermagem	104790	2026-01-27 21:44:42.692+00	2026-01-27 21:44:42.692+00	\N
944	transferencia	2026-01-27 21:46:19.892+00	1	\N	64	3	\N	10	29	enfermagem	25E935	2026-01-27 21:46:19.893+00	2026-01-27 21:46:19.893+00	\N
945	transferencia	2026-01-28 13:26:34.63+00	1	\N	18	1	\N	20	2	enfermagem	L25J065	2026-01-28 13:26:34.631+00	2026-01-28 13:26:34.631+00	\N
946	transferencia	2026-01-28 13:27:13.24+00	1	\N	73	1	\N	12	2	enfermagem	B24J2421	2026-01-28 13:27:13.241+00	2026-01-28 13:27:13.241+00	\N
947	entrada	2026-01-28 13:29:26.69+00	1	\N	28	1	\N	18	6	farmacia	2502069	2026-01-28 13:29:26.69+00	2026-01-28 13:29:26.69+00	\N
948	transferencia	2026-01-28 13:29:55.839+00	1	\N	28	1	\N	18	6	enfermagem	2502069	2026-01-28 13:29:55.839+00	2026-01-28 13:29:55.839+00	\N
949	entrada	2026-01-28 13:31:38.987+00	1	\N	83	1	\N	15	29	farmacia	3025731	2026-01-28 13:31:38.987+00	2026-01-28 13:31:38.987+00	\N
950	transferencia	2026-01-28 13:32:10.388+00	1	\N	83	1	\N	15	29	enfermagem	3025731	2026-01-28 13:32:10.388+00	2026-01-28 13:32:10.388+00	\N
951	entrada	2026-01-28 13:34:45.938+00	1	\N	121	1	\N	10	3	farmacia	ORC.198513/1	2026-01-28 13:34:45.938+00	2026-01-28 13:34:45.938+00	\N
952	transferencia	2026-01-28 13:43:26.088+00	1	\N	188	4	\N	3	\N	enfermagem	251189	2026-01-28 13:43:26.088+00	2026-01-28 13:43:26.088+00	\N
953	transferencia	2026-01-28 13:45:09.698+00	1	\N	34	2	\N	4	\N	enfermagem	0784/25	2026-01-28 13:45:09.698+00	2026-01-28 13:45:09.698+00	\N
954	entrada	2026-01-28 14:16:23.533+00	1	\N	83	1	\N	30	35	farmacia	3024726	2026-01-28 14:16:23.533+00	2026-01-28 14:16:23.533+00	\N
955	entrada	2026-01-28 14:44:30.827+00	1	\N	110	4	\N	2	28	farmacia	25H837	2026-01-28 14:44:30.827+00	2026-01-28 14:44:30.827+00	\N
956	entrada	2026-01-28 14:47:17.518+00	1	15	\N	6	\N	120	21	farmacia		2026-01-28 14:47:17.518+00	2026-01-28 14:47:17.518+00	\N
957	transferencia	2026-01-28 14:48:04.045+00	1	15	\N	6	\N	120	21	enfermagem		2026-01-28 14:48:04.045+00	2026-01-28 14:48:04.045+00	\N
958	entrada	2026-01-28 14:51:21.281+00	1	\N	27	6	\N	60	\N	farmacia	BR180753	2026-01-28 14:51:21.282+00	2026-01-28 14:51:21.282+00	\N
959	entrada	2026-01-28 15:06:35.733+00	1	\N	143	1	\N	30	39	farmacia	4B5549	2026-01-28 15:06:35.733+00	2026-01-28 15:06:35.733+00	\N
960	entrada	2026-01-28 15:08:19.63+00	1	\N	143	6	\N	30	\N	farmacia	4V8282	2026-01-28 15:08:19.63+00	2026-01-28 15:08:19.63+00	\N
961	entrada	2026-01-28 15:17:46.974+00	1	\N	195	1	\N	30	39	farmacia	4R5256	2026-01-28 15:17:46.974+00	2026-01-28 15:17:46.974+00	\N
962	entrada	2026-01-28 15:20:53.551+00	1	\N	51	3	\N	60	9	farmacia	25070534	2026-01-28 15:20:53.551+00	2026-01-28 15:20:53.551+00	\N
963	entrada	2026-01-28 19:07:27.174+00	1	30	\N	5	\N	2	\N	farmacia	2503457	2026-01-28 19:07:27.174+00	2026-01-28 19:07:27.174+00	\N
964	entrada	2026-01-28 19:09:32.608+00	1	31	\N	2	\N	1	\N	farmacia	107414	2026-01-28 19:09:32.608+00	2026-01-28 19:09:32.608+00	\N
965	entrada	2026-01-28 19:10:14.007+00	1	\N	196	4	\N	1	\N	farmacia		2026-01-28 19:10:14.008+00	2026-01-28 19:10:14.008+00	\N
966	transferencia	2026-01-28 19:11:53.672+00	1	\N	196	4	\N	1	30	enfermagem	\N	2026-01-28 19:11:53.672+00	2026-01-28 19:11:53.672+00	\N
967	entrada	2026-01-28 20:39:42.167+00	1	\N	46	2	\N	3	25	farmacia	5C3338	2026-01-28 20:39:42.167+00	2026-01-28 20:39:42.167+00	\N
968	transferencia	2026-01-28 20:43:20.562+00	1	\N	46	2	\N	1	25	enfermagem	5C3338	2026-01-28 20:43:20.562+00	2026-01-28 20:43:20.562+00	\N
969	entrada	2026-01-28 20:49:37.694+00	1	\N	55	1	\N	30	5	farmacia	25B798	2026-01-28 20:49:37.694+00	2026-01-28 20:49:37.694+00	\N
970	entrada	2026-01-28 20:53:17.581+00	1	\N	44	1	\N	30	42	farmacia	471921	2026-01-28 20:53:17.582+00	2026-01-28 20:53:17.582+00	\N
971	entrada	2026-01-28 20:58:06.97+00	1	\N	113	3	\N	60	4	farmacia	50022104	2026-01-28 20:58:06.97+00	2026-01-28 20:58:06.97+00	\N
972	entrada	2026-01-28 21:01:35.931+00	1	\N	111	1	\N	90	17	farmacia	25G19J	2026-01-28 21:01:35.931+00	2026-01-28 21:01:35.931+00	\N
973	entrada	2026-01-28 21:03:48.1+00	1	\N	161	4	\N	10	11	farmacia	50029446	2026-01-28 21:03:48.101+00	2026-01-28 21:03:48.101+00	\N
974	transferencia	2026-01-28 21:43:33.494+00	1	\N	64	3	\N	10	25	enfermagem	25E935	2026-01-28 21:43:33.494+00	2026-01-28 21:43:33.494+00	\N
975	transferencia	2026-01-28 21:44:37.724+00	1	\N	123	3	\N	20	25	enfermagem	50022743	2026-01-28 21:44:37.724+00	2026-01-28 21:44:37.724+00	\N
976	transferencia	2026-01-28 21:46:44.735+00	1	\N	32	3	\N	30	24	enfermagem	2517054	2026-01-28 21:46:44.735+00	2026-01-28 21:46:44.735+00	\N
977	entrada	2026-01-28 21:56:51.664+00	1	\N	134	3	\N	20	22	farmacia	2412726	2026-01-28 21:56:51.665+00	2026-01-28 21:56:51.665+00	\N
978	transferencia	2026-01-28 21:57:24.201+00	1	\N	134	3	\N	20	22	enfermagem	2412726	2026-01-28 21:57:24.202+00	2026-01-28 21:57:24.202+00	\N
979	transferencia	2026-01-28 21:59:39.6+00	1	\N	51	3	\N	15	33	enfermagem	927429	2026-01-28 21:59:39.601+00	2026-01-28 21:59:39.601+00	\N
980	entrada	2026-01-28 22:00:46.93+00	1	\N	51	3	\N	30	33	farmacia	25010243	2026-01-28 22:00:46.93+00	2026-01-28 22:00:46.93+00	\N
981	transferencia	2026-01-28 22:04:29.803+00	1	\N	100	3	\N	10	34	enfermagem	561616	2026-01-28 22:04:29.803+00	2026-01-28 22:04:29.803+00	\N
982	transferencia	2026-01-28 22:05:10.793+00	1	\N	71	3	\N	10	34	enfermagem	4S3328	2026-01-28 22:05:10.794+00	2026-01-28 22:05:10.794+00	\N
983	entrada	2026-01-28 22:06:35.914+00	1	\N	185	1	\N	8	42	farmacia	4U9458	2026-01-28 22:06:35.914+00	2026-01-28 22:06:35.914+00	\N
984	transferencia	2026-01-28 22:07:59.178+00	1	\N	185	1	\N	8	42	enfermagem	4U9458	2026-01-28 22:07:59.178+00	2026-01-28 22:07:59.178+00	\N
985	transferencia	2026-01-28 22:09:21.923+00	1	\N	142	1	\N	25	5	enfermagem	BR173864	2026-01-28 22:09:21.923+00	2026-01-28 22:09:21.923+00	\N
986	transferencia	2026-01-28 22:10:54.227+00	1	\N	55	1	\N	20	5	enfermagem	25B798	2026-01-28 22:10:54.227+00	2026-01-28 22:10:54.227+00	\N
987	transferencia	2026-01-28 22:12:31.672+00	1	20	\N	5	\N	200	\N	enfermagem	AUX3780	2026-01-28 22:12:31.673+00	2026-01-28 22:12:31.673+00	enfermagem
988	transferencia	2026-01-28 22:19:08.133+00	1	18	\N	5	\N	4	\N	enfermagem	2508010025	2026-01-28 22:19:08.133+00	2026-01-28 22:19:08.133+00	enfermagem
1021	transferencia	2026-01-29 11:57:57.027+00	1	\N	39	1	\N	14	27	enfermagem	2501536	2026-01-29 11:57:57.027+00	2026-01-29 11:57:57.027+00	\N
1022	transferencia	2026-01-29 11:58:43.746+00	1	\N	45	1	\N	20	23	enfermagem	\N	2026-01-29 11:58:43.746+00	2026-01-29 11:58:43.746+00	\N
1023	transferencia	2026-01-29 12:01:50.86+00	1	\N	29	1	\N	30	18	enfermagem	B25E042	2026-01-29 12:01:50.861+00	2026-01-29 12:01:50.861+00	\N
1024	entrada	2026-01-29 12:03:55.068+00	1	\N	16	1	\N	20	15	farmacia	40303748	2026-01-29 12:03:55.068+00	2026-01-29 12:03:55.068+00	\N
1025	transferencia	2026-01-29 12:04:17.021+00	1	\N	16	1	\N	20	15	enfermagem	40303748	2026-01-29 12:04:17.022+00	2026-01-29 12:04:17.022+00	\N
1026	transferencia	2026-01-29 12:32:18.631+00	1	\N	111	3	\N	15	17	enfermagem	25C45P	2026-01-29 12:32:18.632+00	2026-01-29 12:32:18.632+00	\N
1027	transferencia	2026-01-29 12:34:25.617+00	1	\N	87	3	\N	10	8	enfermagem	MPA250158	2026-01-29 12:34:25.617+00	2026-01-29 12:34:25.617+00	\N
1028	entrada	2026-01-29 13:16:08.251+00	1	\N	28	1	\N	30	19	farmacia	B25H1712	2026-01-29 13:16:08.251+00	2026-01-29 13:16:08.251+00	\N
1029	transferencia	2026-01-29 13:17:11.827+00	1	\N	28	1	\N	30	19	enfermagem	B25H1712	2026-01-29 13:17:11.828+00	2026-01-29 13:17:11.828+00	\N
\.


--
-- Data for Name: notificacao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notificacao (id, medicamento_id, residente_id, destino, data_prevista, criado_por, status, visto, "createdAt", "updatedAt") FROM stdin;
3	46	26	sus	2026-02-04	1	sent	f	2026-01-07 13:49:30.039+00	2026-01-07 13:49:43.043+00
4	47	3	sus	2026-02-05	1	sent	f	2026-01-07 13:54:13.003+00	2026-01-07 13:55:16.031+00
5	48	4	sus	2026-02-06	1	sent	f	2026-01-07 15:07:29.222+00	2026-01-07 15:07:37.354+00
6	51	9	sus	2026-01-09	1	sent	f	2026-01-07 16:57:49.909+00	2026-01-07 16:57:52.776+00
7	36	35	sus	2026-01-09	1	sent	f	2026-01-07 16:58:39.649+00	2026-01-07 16:58:42.543+00
17	71	40	sus	2026-02-06	1	pending	f	2026-01-07 21:52:35.658+00	2026-01-07 21:52:35.658+00
9	36	35	sus	2026-01-09	1	sent	t	2026-01-07 17:00:04.817+00	2026-01-09 13:08:20.624+00
18	52	35	sus	2026-02-09	1	pending	f	2026-01-09 13:24:13.12+00	2026-01-09 13:24:13.12+00
19	26	5	sus	2026-02-09	1	pending	f	2026-01-09 13:37:09.018+00	2026-01-09 13:37:09.018+00
20	35	26	sus	2026-02-09	1	pending	f	2026-01-09 13:53:49.05+00	2026-01-09 13:53:49.05+00
21	80	29	sus	2026-02-08	1	pending	f	2026-01-09 13:57:36.021+00	2026-01-09 13:57:36.021+00
22	25	38	sus	2026-02-08	1	pending	f	2026-01-09 13:59:29.059+00	2026-01-09 13:59:29.059+00
23	27	3	sus	2026-02-08	1	pending	f	2026-01-09 14:07:20.574+00	2026-01-09 14:07:20.574+00
24	24	13	sus	2026-02-08	1	pending	f	2026-01-09 14:11:03.5+00	2026-01-09 14:11:03.5+00
30	45	19	sus	2026-01-31	1	pending	f	2026-01-09 14:32:10.041+00	2026-01-09 14:32:10.041+00
8	51	9	sus	2026-01-09	1	sent	t	2026-01-07 16:59:32.421+00	2026-01-15 13:24:25.584+00
12	58	26	sus	2026-01-09	1	sent	t	2026-01-07 17:02:15.729+00	2026-01-15 13:24:32.674+00
13	59	2	sus	2026-01-09	1	sent	t	2026-01-07 17:02:57.428+00	2026-01-15 13:24:41.453+00
10	35	26	sus	2026-01-09	1	cancelled	t	2026-01-07 17:00:47.867+00	2026-01-19 19:22:45.623+00
15	35	5	sus	2026-01-09	1	cancelled	t	2026-01-07 17:04:16.757+00	2026-01-19 19:22:48.735+00
14	20	2	sus	2026-01-09	1	sent	t	2026-01-07 17:03:39.414+00	2026-01-19 19:22:58.265+00
16	26	5	sus	2026-01-09	1	sent	t	2026-01-07 17:04:52.519+00	2026-01-19 19:22:59.849+00
11	54	26	sus	2026-01-09	1	sent	t	2026-01-07 17:01:32.854+00	2026-01-19 19:23:02.3+00
31	74	2	sus	2026-02-19	1	pending	f	2026-01-19 19:50:41.049+00	2026-01-19 19:50:41.049+00
32	164	19	sus	2026-03-04	1	pending	f	2026-01-19 20:06:08.158+00	2026-01-19 20:06:08.158+00
33	140	19	sus	2026-02-18	1	pending	f	2026-01-19 20:07:13.639+00	2026-01-19 20:07:13.639+00
28	25	42	sus	2026-01-23	1	pending	t	2026-01-09 14:25:35.492+00	2026-01-23 11:38:34.767+00
25	27	29	sus	2026-01-23	1	pending	t	2026-01-09 14:20:27.089+00	2026-01-23 11:38:34.779+00
29	29	9	sus	2026-01-23	1	pending	t	2026-01-09 14:28:17.833+00	2026-01-23 11:38:34.848+00
26	81	4	sus	2026-01-23	1	pending	t	2026-01-09 14:22:01.169+00	2026-01-23 11:38:34.868+00
27	82	39	sus	2026-01-23	1	pending	t	2026-01-09 14:24:49.729+00	2026-01-23 11:38:34.875+00
\.


--
-- Data for Name: residente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.residente (num_casela, nome) FROM stdin;
4	Maria Elena Ribeiro
42	Carolina Pedro
29	Maria Helena Sousa
9	Antonio Ienco
26	Cleonice Gonçalves Ferreira
39	Maria das Mercês Monteiro
24	Lyrio Baptista da Silva
3	Araci de Almeida Cunha
6	Venina Zillah Mendes
10	Angela Chinfini
23	Maria Eugênia Morotti
12	Lázara S. Bacchini
1	Waldemar Alves Viana
2	Antonia Rodrigues
7	Vilma Tedesco
8	Fátima Ap. Lopes da Silva
11	Miguel Gianotti
13	Ophélia Gonçalvez
14	Benedicta S. de Moraes
15	Ana Pereira
16	Célia Bellini
17	Olga de Fátima Nunes
18	Maria Benedita S. Nobre
19	Aparecida F. de Araújo
20	Otília Barboza da Silva
21	Sandra Maria Camargo
22	Juraci Jesus Carvalho
25	Adail Aparecido Domingos
27	Aurelino M. do Nascimento
28	Alcino Amaral
30	José de Almeida Bispo
33	Walfredo Ursino Cruz
34	Maura Ramos da Magri
35	Sophia Castilho
38	Maria Conceição Ignácio
40	Conceição Sanesi Rother
36	Ana Maria Ricci
5	Lázaro de Paula
\.


--
-- Name: categoria_armario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categoria_armario_id_seq', 9, true);


--
-- Name: categoria_gaveta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categoria_gaveta_id_seq', 8, true);


--
-- Name: estoque_insumo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estoque_insumo_id_seq', 83, true);


--
-- Name: estoque_medicamento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estoque_medicamento_id_seq', 812, true);


--
-- Name: insumo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.insumo_id_seq', 31, true);


--
-- Name: login_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.login_id_seq', 2, true);


--
-- Name: medicamento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.medicamento_id_seq', 196, true);


--
-- Name: movimentacao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.movimentacao_id_seq', 1029, true);


--
-- Name: notificacao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notificacao_id_seq', 33, true);


--
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- Name: armario armario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.armario
    ADD CONSTRAINT armario_pkey PRIMARY KEY (num_armario);


--
-- Name: categoria_armario categoria_armario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria_armario
    ADD CONSTRAINT categoria_armario_pkey PRIMARY KEY (id);


--
-- Name: categoria_gaveta categoria_gaveta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria_gaveta
    ADD CONSTRAINT categoria_gaveta_pkey PRIMARY KEY (id);


--
-- Name: estoque_insumo estoque_insumo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque_insumo
    ADD CONSTRAINT estoque_insumo_pkey PRIMARY KEY (id);


--
-- Name: estoque_medicamento estoque_medicamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque_medicamento
    ADD CONSTRAINT estoque_medicamento_pkey PRIMARY KEY (id);


--
-- Name: gaveta gaveta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gaveta
    ADD CONSTRAINT gaveta_pkey PRIMARY KEY (num_gaveta);


--
-- Name: insumo insumo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.insumo
    ADD CONSTRAINT insumo_pkey PRIMARY KEY (id);


--
-- Name: login login_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login
    ADD CONSTRAINT login_login_key UNIQUE (login);


--
-- Name: login login_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login
    ADD CONSTRAINT login_pkey PRIMARY KEY (id);


--
-- Name: medicamento medicamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicamento
    ADD CONSTRAINT medicamento_pkey PRIMARY KEY (id);


--
-- Name: movimentacao movimentacao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movimentacao
    ADD CONSTRAINT movimentacao_pkey PRIMARY KEY (id);


--
-- Name: notificacao notificacao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notificacao
    ADD CONSTRAINT notificacao_pkey PRIMARY KEY (id);


--
-- Name: residente residente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.residente
    ADD CONSTRAINT residente_pkey PRIMARY KEY (num_casela);


--
-- Name: idx_armario_categoria_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_armario_categoria_id ON public.armario USING btree (categoria_id);


--
-- Name: idx_estoque_insumo_armario_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_insumo_armario_id ON public.estoque_insumo USING btree (armario_id);


--
-- Name: idx_estoque_insumo_casela_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_insumo_casela_id ON public.estoque_insumo USING btree (casela_id);


--
-- Name: idx_estoque_insumo_composite_lookup; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_insumo_composite_lookup ON public.estoque_insumo USING btree (insumo_id, armario_id, gaveta_id, validade, tipo, casela_id, lote);


--
-- Name: idx_estoque_insumo_gaveta_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_insumo_gaveta_id ON public.estoque_insumo USING btree (gaveta_id);


--
-- Name: idx_estoque_insumo_insumo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_insumo_insumo_id ON public.estoque_insumo USING btree (insumo_id);


--
-- Name: idx_estoque_insumo_setor; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_insumo_setor ON public.estoque_insumo USING btree (setor);


--
-- Name: idx_estoque_insumo_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_insumo_status ON public.estoque_insumo USING btree (status);


--
-- Name: idx_estoque_insumo_tipo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_insumo_tipo ON public.estoque_insumo USING btree (tipo);


--
-- Name: idx_estoque_insumo_tipo_setor; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_insumo_tipo_setor ON public.estoque_insumo USING btree (tipo, setor);


--
-- Name: idx_estoque_insumo_validade; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_insumo_validade ON public.estoque_insumo USING btree (validade);


--
-- Name: idx_estoque_medicamento_armario_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_medicamento_armario_id ON public.estoque_medicamento USING btree (armario_id);


--
-- Name: idx_estoque_medicamento_casela_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_medicamento_casela_id ON public.estoque_medicamento USING btree (casela_id);


--
-- Name: idx_estoque_medicamento_composite_lookup; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_medicamento_composite_lookup ON public.estoque_medicamento USING btree (medicamento_id, armario_id, gaveta_id, validade, tipo, casela_id, origem, lote);


--
-- Name: idx_estoque_medicamento_gaveta_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_medicamento_gaveta_id ON public.estoque_medicamento USING btree (gaveta_id);


--
-- Name: idx_estoque_medicamento_medicamento_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_medicamento_medicamento_id ON public.estoque_medicamento USING btree (medicamento_id);


--
-- Name: idx_estoque_medicamento_setor; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_medicamento_setor ON public.estoque_medicamento USING btree (setor);


--
-- Name: idx_estoque_medicamento_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_medicamento_status ON public.estoque_medicamento USING btree (status);


--
-- Name: idx_estoque_medicamento_tipo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_medicamento_tipo ON public.estoque_medicamento USING btree (tipo);


--
-- Name: idx_estoque_medicamento_tipo_setor; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_medicamento_tipo_setor ON public.estoque_medicamento USING btree (tipo, setor);


--
-- Name: idx_estoque_medicamento_validade; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_estoque_medicamento_validade ON public.estoque_medicamento USING btree (validade);


--
-- Name: idx_gaveta_categoria_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_gaveta_categoria_id ON public.gaveta USING btree (categoria_id);


--
-- Name: idx_login_refresh_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_login_refresh_token ON public.login USING btree (refresh_token);


--
-- Name: idx_medicamento_nome; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medicamento_nome ON public.medicamento USING btree (nome);


--
-- Name: idx_medicamento_principio_ativo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medicamento_principio_ativo ON public.medicamento USING btree (principio_ativo);


--
-- Name: idx_movimentacao_armario_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movimentacao_armario_id ON public.movimentacao USING btree (armario_id);


--
-- Name: idx_movimentacao_casela_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movimentacao_casela_id ON public.movimentacao USING btree (casela_id);


--
-- Name: idx_movimentacao_data; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movimentacao_data ON public.movimentacao USING btree (data);


--
-- Name: idx_movimentacao_gaveta_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movimentacao_gaveta_id ON public.movimentacao USING btree (gaveta_id);


--
-- Name: idx_movimentacao_insumo_data; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movimentacao_insumo_data ON public.movimentacao USING btree (insumo_id, data);


--
-- Name: idx_movimentacao_insumo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movimentacao_insumo_id ON public.movimentacao USING btree (insumo_id);


--
-- Name: idx_movimentacao_login_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movimentacao_login_id ON public.movimentacao USING btree (login_id);


--
-- Name: idx_movimentacao_medicamento_data; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movimentacao_medicamento_data ON public.movimentacao USING btree (medicamento_id, data);


--
-- Name: idx_movimentacao_medicamento_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movimentacao_medicamento_id ON public.movimentacao USING btree (medicamento_id);


--
-- Name: idx_movimentacao_setor; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movimentacao_setor ON public.movimentacao USING btree (setor);


--
-- Name: idx_movimentacao_tipo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movimentacao_tipo ON public.movimentacao USING btree (tipo);


--
-- Name: idx_movimentacao_tipo_data; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movimentacao_tipo_data ON public.movimentacao USING btree (tipo, data);


--
-- Name: idx_notificacao_criado_por; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notificacao_criado_por ON public.notificacao USING btree (criado_por);


--
-- Name: idx_notificacao_data_prevista; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notificacao_data_prevista ON public.notificacao USING btree (data_prevista);


--
-- Name: idx_notificacao_medicamento_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notificacao_medicamento_id ON public.notificacao USING btree (medicamento_id);


--
-- Name: idx_notificacao_residente_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notificacao_residente_id ON public.notificacao USING btree (residente_id);


--
-- Name: idx_notificacao_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notificacao_status ON public.notificacao USING btree (status);


--
-- Name: idx_notificacao_status_data_prevista; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notificacao_status_data_prevista ON public.notificacao USING btree (status, data_prevista);


--
-- Name: idx_notificacao_visto; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notificacao_visto ON public.notificacao USING btree (visto);


--
-- Name: uniq_insumo_nome; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uniq_insumo_nome ON public.insumo USING btree (nome);


--
-- Name: uniq_medicamento_nome_principio_dosagem; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uniq_medicamento_nome_principio_dosagem ON public.medicamento USING btree (nome, principio_ativo, dosagem, unidade_medida);


--
-- Name: armario armario_categoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.armario
    ADD CONSTRAINT armario_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES public.categoria_armario(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: estoque_insumo estoque_insumo_armario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque_insumo
    ADD CONSTRAINT estoque_insumo_armario_id_fkey FOREIGN KEY (armario_id) REFERENCES public.armario(num_armario) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: estoque_insumo estoque_insumo_casela_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque_insumo
    ADD CONSTRAINT estoque_insumo_casela_id_fkey FOREIGN KEY (casela_id) REFERENCES public.residente(num_casela) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: estoque_insumo estoque_insumo_insumo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque_insumo
    ADD CONSTRAINT estoque_insumo_insumo_id_fkey FOREIGN KEY (insumo_id) REFERENCES public.insumo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: estoque_medicamento estoque_medicamento_armario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque_medicamento
    ADD CONSTRAINT estoque_medicamento_armario_id_fkey FOREIGN KEY (armario_id) REFERENCES public.armario(num_armario) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: estoque_medicamento estoque_medicamento_casela_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque_medicamento
    ADD CONSTRAINT estoque_medicamento_casela_id_fkey FOREIGN KEY (casela_id) REFERENCES public.residente(num_casela) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: estoque_medicamento estoque_medicamento_medicamento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoque_medicamento
    ADD CONSTRAINT estoque_medicamento_medicamento_id_fkey FOREIGN KEY (medicamento_id) REFERENCES public.medicamento(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gaveta gaveta_categoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gaveta
    ADD CONSTRAINT gaveta_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES public.categoria_gaveta(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: movimentacao movimentacao_armario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movimentacao
    ADD CONSTRAINT movimentacao_armario_id_fkey FOREIGN KEY (armario_id) REFERENCES public.armario(num_armario) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: movimentacao movimentacao_casela_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movimentacao
    ADD CONSTRAINT movimentacao_casela_id_fkey FOREIGN KEY (casela_id) REFERENCES public.residente(num_casela) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: movimentacao movimentacao_insumo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movimentacao
    ADD CONSTRAINT movimentacao_insumo_id_fkey FOREIGN KEY (insumo_id) REFERENCES public.insumo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: movimentacao movimentacao_login_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movimentacao
    ADD CONSTRAINT movimentacao_login_id_fkey FOREIGN KEY (login_id) REFERENCES public.login(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: movimentacao movimentacao_medicamento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movimentacao
    ADD CONSTRAINT movimentacao_medicamento_id_fkey FOREIGN KEY (medicamento_id) REFERENCES public.medicamento(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notificacao notificacao_criado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notificacao
    ADD CONSTRAINT notificacao_criado_por_fkey FOREIGN KEY (criado_por) REFERENCES public.login(id) ON UPDATE CASCADE;


--
-- Name: notificacao notificacao_medicamento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notificacao
    ADD CONSTRAINT notificacao_medicamento_id_fkey FOREIGN KEY (medicamento_id) REFERENCES public.medicamento(id) ON UPDATE CASCADE;


--
-- Name: notificacao notificacao_residente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notificacao
    ADD CONSTRAINT notificacao_residente_id_fkey FOREIGN KEY (residente_id) REFERENCES public.residente(num_casela) ON UPDATE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 1fzgmxtUx6qh4wImpdpYr98kboS1NPfEv3hAhZO0qOAOWCL3H53GTIaMgY5h7yW

